import React, { useState } from 'react';
import {
  History,
  Calendar,
  X,
  Search,
  FileSpreadsheet,
  MessageSquare,
  Trash2,
  Inbox,
  Clock,
  User,
  Gauge,
  CalendarDays,
  TableProperties
} from 'lucide-react';
import { ShiftReport } from '../types/report';
import { exportReportsToCSV } from '../utils/calculations';

interface ReportTableProps {
  reports: ShiftReport[];
  selectedDate: string;
  onDateChange: (date: string) => void;
  onOpenZalo: (report: ShiftReport) => void;
  onRequestDelete: (id: string | number) => void;
  onShowToast: (message: string, isError?: boolean) => void;
  onOpenDailySummary?: () => void;
  onEditReport?: (report: ShiftReport) => void;
}

export const ReportTable: React.FC<ReportTableProps> = ({
  reports,
  selectedDate,
  onDateChange,
  onOpenZalo,
  onRequestDelete,
  onShowToast,
  onOpenDailySummary,
  onEditReport
}) => {
  const [search, setSearch] = useState('');
  const [stageFilter, setStageFilter] = useState<'ALL' | 'BOS' | 'EOS'>('ALL');

  const filteredReports = reports.filter((r) => {
    const q = search.toLowerCase().trim();
    const matchesSearch =
      !q ||
      r.line.toLowerCase().includes(q) ||
      r.model.toLowerCase().includes(q) ||
      r.jobCS.toLowerCase().includes(q) ||
      r.jobUN.toLowerCase().includes(q) ||
      r.leader.toLowerCase().includes(q) ||
      r.date.includes(q);

    const matchesDate = !selectedDate || r.date === selectedDate;
    const matchesStage =
      stageFilter === 'ALL' ||
      (stageFilter === 'EOS' ? r.reportStage === 'EOS' : r.reportStage !== 'EOS');

    return matchesSearch && matchesDate && matchesStage;
  });

  const handleExport = () => {
    if (filteredReports.length === 0) {
      onShowToast('Không có dữ liệu để xuất Excel!', true);
      return;
    }
    const success = exportReportsToCSV(filteredReports);
    if (success) {
      onShowToast(`Đã xuất ${filteredReports.length} báo cáo ra file Excel (.CSV)!`);
    }
  };

  return (
    <section className="bg-white rounded-2xl shadow-sm border border-slate-200 overflow-hidden">
      {/* Table Controls */}
      <div className="p-4 bg-slate-50 border-b border-slate-200 flex flex-wrap items-center justify-between gap-3 no-print">
        <div className="flex items-center space-x-2">
          <h2 className="font-bold text-slate-800 text-sm flex items-center gap-2">
            <History className="w-4 h-4 text-sky-600" />
            Nhật Ký Báo Cáo Ca
          </h2>
          <span className="bg-slate-200 text-slate-700 text-xs px-2.5 py-0.5 rounded-full font-bold">
            {filteredReports.length}
          </span>
        </div>

        {/* Filter Controls */}
        <div className="flex flex-wrap items-center gap-2">
          {/* Date Filter */}
          <div className="flex items-center gap-1.5 bg-white border border-slate-300 rounded-lg px-2.5 py-1.5 shadow-xs">
            <Calendar className="w-3.5 h-3.5 text-slate-400" />
            <input
              type="date"
              value={selectedDate}
              onChange={(e) => onDateChange(e.target.value)}
              className="text-xs text-slate-700 bg-transparent focus:outline-none"
              title="Lọc theo ngày sản xuất"
            />
            {selectedDate && (
              <button
                type="button"
                onClick={() => onDateChange('')}
                className="text-slate-400 hover:text-slate-600 p-0.5 cursor-pointer"
                title="Xóa lọc ngày"
              >
                <X className="w-3.5 h-3.5" />
              </button>
            )}
          </div>

          {/* Search Filter */}
          <div className="relative">
            <Search className="w-3.5 h-3.5 text-slate-400 absolute left-2.5 top-1/2 -translate-y-1/2 pointer-events-none" />
            <input
              type="text"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder="Tìm Line, Model, Job..."
              className="bg-white border border-slate-300 text-xs rounded-lg pl-8 pr-2.5 py-1.5 focus:outline-none focus:ring-2 focus:ring-sky-500 w-36 sm:w-44 shadow-xs"
            />
            {search && (
              <button
                type="button"
                onClick={() => setSearch('')}
                className="text-slate-400 hover:text-slate-600 absolute right-2 top-1/2 -translate-y-1/2 p-0.5 cursor-pointer"
              >
                <X className="w-3 h-3" />
              </button>
            )}
          </div>

          {/* Stage Filter Buttons (Tất cả / BOS / EOS) */}
          <div className="inline-flex rounded-lg bg-slate-200/80 p-0.5 text-xs font-bold">
            <button
              type="button"
              onClick={() => setStageFilter('ALL')}
              className={`px-2 py-1 rounded-md transition-all cursor-pointer ${
                stageFilter === 'ALL'
                  ? 'bg-white text-slate-900 shadow-2xs font-black'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              Tất cả
            </button>
            <button
              type="button"
              onClick={() => setStageFilter('BOS')}
              className={`px-2 py-1 rounded-md transition-all cursor-pointer flex items-center gap-1 ${
                stageFilter === 'BOS'
                  ? 'bg-sky-600 text-white shadow-2xs font-black'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
              title="Chỉ xem báo cáo đầu ca (BOS)"
            >
              <span>☀️</span> BOS
            </button>
            <button
              type="button"
              onClick={() => setStageFilter('EOS')}
              className={`px-2 py-1 rounded-md transition-all cursor-pointer flex items-center gap-1 ${
                stageFilter === 'EOS'
                  ? 'bg-emerald-600 text-white shadow-2xs font-black'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
              title="Chỉ xem báo cáo cuối ca (EOS)"
            >
              <span>🏁</span> EOS
            </button>
          </div>

          {/* Báo Cáo Tổng Hợp Format Chuẩn Xưởng */}
          {onOpenDailySummary && (
            <button
              type="button"
              onClick={onOpenDailySummary}
              className="px-3 py-1.5 bg-sky-800 hover:bg-sky-700 text-white rounded-lg text-xs font-bold flex items-center gap-1.5 shadow-sm transition-all cursor-pointer"
              title="Tổng hợp tất cả các line trong ngày, các chuyền không chạy đánh dấu No plan"
            >
              <TableProperties className="w-3.5 h-3.5 text-amber-300" /> Báo Cáo Tổng Hợp Các Line
            </button>
          )}

          {/* Export to CSV */}
          <button
            type="button"
            onClick={handleExport}
            className="px-3 py-1.5 bg-emerald-600 hover:bg-emerald-700 text-white rounded-lg text-xs font-bold flex items-center gap-1.5 shadow-sm transition-all cursor-pointer"
          >
            <FileSpreadsheet className="w-3.5 h-3.5" /> Xuất Excel
          </button>
        </div>
      </div>

      {/* Table Container */}
      <div className="overflow-x-auto max-h-[700px] overflow-y-auto">
        <table className="w-full text-left border-collapse text-xs">
          <thead className="bg-slate-100 text-slate-600 font-bold sticky top-0 z-10 border-b border-slate-200 uppercase tracking-wider text-[10px]">
            <tr>
              <th className="p-3">Line & Ngày</th>
              <th className="p-3">Model & Chi Tiết 2 Job</th>
              <th className="p-3 text-center">Điểm Danh Nhân Sự</th>
              <th className="p-3 text-center">Tổng Sản Lượng</th>
              <th className="p-3 text-center">Hiệu Suất (EFF)</th>
              <th className="p-3 text-center no-print">Thao Tác</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-100">
            {filteredReports.map((r) => {
              const isNight = r.shiftType === 'night';
              const isEffMet = r.effRate >= 105;
              const isEos = r.reportStage === 'EOS';

              return (
                <tr
                  key={r.id}
                  className={`hover:bg-slate-50 transition-colors border-b border-slate-200/70 border-l-4 ${
                    isEos ? 'border-l-emerald-500 bg-emerald-50/15' : 'border-l-sky-500 bg-sky-50/15'
                  }`}
                >
                  {/* Line & Ngày & Nhận diện BOS / EOS */}
                  <td className="p-3 font-medium align-top">
                    <div className="flex items-center gap-1.5 flex-wrap mb-1.5">
                      <div className="inline-flex items-center gap-1 px-2 py-0.5 bg-slate-900 text-white rounded-md font-black text-xs shadow-2xs">
                        <span>{r.line}</span>
                        <span>{isNight ? '🌙' : '☀️'}</span>
                      </div>
                      {isEos ? (
                        <span
                          className="inline-flex items-center gap-1 px-2 py-0.5 bg-gradient-to-r from-emerald-600 to-teal-600 text-white text-[10px] font-black uppercase rounded-md shadow-2xs tracking-wide"
                          title="Báo Cáo Thực Tế Cuối Ca (EOS - Actual)"
                        >
                          🏁 Cuối Ca (EOS)
                        </span>
                      ) : (
                        <span
                          className="inline-flex items-center gap-1 px-2 py-0.5 bg-gradient-to-r from-sky-600 to-blue-600 text-white text-[10px] font-black uppercase rounded-md shadow-2xs tracking-wide"
                          title="Báo Cáo Kế Hoạch Đầu Ca (BOS - Estimate)"
                        >
                          📋 Đầu Ca (BOS)
                        </span>
                      )}
                    </div>
                    <div className="text-[11px] text-slate-500 flex items-center gap-1">
                      <CalendarDays className="w-3 h-3 text-slate-400" /> {r.date}
                    </div>
                    <div className="text-[11px] text-slate-500 flex items-center gap-1 mt-0.5">
                      <User className="w-3 h-3 text-slate-400" /> {r.leader || 'Line Leader'}
                    </div>
                  </td>

                  {/* Model & Chi Tiết 2 Job xen kẽ số lượng */}
                  <td className="p-3 align-top min-w-[240px]">
                    <div className="font-extrabold text-slate-900 text-sm mb-1.5 flex items-center justify-between">
                      <span>Model: {r.model}</span>
                    </div>

                    <div className="space-y-1.5 mb-2">
                      {/* Job CS Badge & Numbers */}
                      <div className="bg-sky-50/80 border border-sky-200/80 rounded-lg p-1.5 text-[11px]">
                        <div className="flex items-center justify-between text-sky-950 font-bold mb-0.5">
                          <span className="flex items-center gap-1">
                            <span className="w-1.5 h-1.5 rounded-full bg-sky-500"></span>
                            Job CS:
                          </span>
                          <span className="font-mono text-[10px] font-medium text-slate-600 truncate max-w-[130px]" title={r.jobCS}>
                            {r.jobCS || '—'}
                          </span>
                        </div>
                        <div className="flex items-center justify-between text-[10px] text-sky-900 pt-0.5 border-t border-sky-200/60">
                          <span>Kế hoạch: <strong>{r.planOutputCS !== undefined ? r.planOutputCS.toLocaleString() : '—'}</strong></span>
                          <span>
                            {isEos ? 'Actual: ' : 'Est: '}
                            <strong className={isEos ? 'text-emerald-700 font-black' : 'text-sky-950 font-bold'}>
                              {r.estimateOutputCS !== undefined ? r.estimateOutputCS.toLocaleString() : '—'}
                            </strong>
                          </span>
                        </div>
                        {r.qcLineCS !== undefined && r.qcLineCS !== null && (
                          <div className="text-[10px] text-sky-700 font-medium pt-0.5">
                            QC Line: <strong className="text-sky-950">{r.qcLineCS} người</strong>
                          </div>
                        )}
                      </div>

                      {/* Job UN Badge & Numbers */}
                      <div className="bg-indigo-50/80 border border-indigo-200/80 rounded-lg p-1.5 text-[11px]">
                        <div className="flex items-center justify-between text-indigo-950 font-bold mb-0.5">
                          <span className="flex items-center gap-1">
                            <span className="w-1.5 h-1.5 rounded-full bg-indigo-500"></span>
                            Job UN:
                          </span>
                          <span className="font-mono text-[10px] font-medium text-slate-600 truncate max-w-[130px]" title={r.jobUN}>
                            {r.jobUN || '—'}
                          </span>
                        </div>
                        <div className="flex items-center justify-between text-[10px] text-indigo-900 pt-0.5 border-t border-indigo-200/60">
                          <span>Kế hoạch: <strong>{r.planOutputUN !== undefined ? r.planOutputUN.toLocaleString() : '—'}</strong></span>
                          <span>
                            {isEos ? 'Actual: ' : 'Est: '}
                            <strong className={isEos ? 'text-emerald-700 font-black' : 'text-indigo-950 font-bold'}>
                              {r.estimateOutputUN !== undefined ? r.estimateOutputUN.toLocaleString() : '—'}
                            </strong>
                          </span>
                        </div>
                        {r.qcLineUN !== undefined && r.qcLineUN !== null && (
                          <div className="text-[10px] text-indigo-700 font-medium pt-0.5">
                            QC Line: <strong className="text-indigo-950">{r.qcLineUN} người</strong>
                          </div>
                        )}
                      </div>
                    </div>

                    <div className="space-y-0.5 text-[11px] pt-0.5">
                      <div className="text-slate-600 font-semibold flex items-center gap-1">
                        <Gauge className="w-3 h-3 text-sky-600" /> UPH: {r.uph}
                      </div>
                      <div className="text-amber-700 font-bold flex items-center gap-1">
                        <Clock className="w-3 h-3 text-amber-600" />
                        <span>
                          STD: <strong>{r.stdHour}</strong>
                          {(r.stdHourCS || r.stdHourUN) && (
                            <span className="text-[10px] text-amber-800 font-normal ml-1">
                              (CS:{r.stdHourCS || '0h'} + UN:{r.stdHourUN || '0h'})
                            </span>
                          )}
                          {' '}| Actual: {r.actualLine}
                        </span>
                      </div>
                    </div>
                  </td>

                  {/* Điểm Danh Nhân Sự */}
                  <td className="p-3 text-center align-top">
                    <div className="text-sm font-extrabold text-slate-800">
                      Hiện Diện:{' '}
                      <span className="text-emerald-600 font-black">{r.presentHC}</span> /{' '}
                      <span className="text-slate-700">{r.totalHC}</span>
                    </div>
                    <div className="text-[11px] text-slate-500 mt-0.5">
                      Plan: {r.planHC}{r.planHCCS !== undefined || r.planHCUN !== undefined ? ` (CS:${r.planHCCS || 0}, UN:${r.planHCUN || 0})` : ''} | Routing: {r.routingHC}{r.routingHCCS !== undefined || r.routingHCUN !== undefined ? ` (CS:${r.routingHCCS || 0}, UN:${r.routingHCUN || 0})` : ''}
                    </div>
                    <div className="text-[11px] text-slate-600 mt-0.5">
                      Vắng: <span className="font-bold text-rose-600">{r.totalLeaveHC}</span>{' '}
                      <span className="text-slate-400 text-[10px]">
                        (AL:{r.leaveAL}, SL:{r.leaveSL}, UP:{r.leaveUP}, UPP:{r.leaveUPP}, K:{r.leaveOther})
                      </span>
                    </div>
                    {r.lateHC > 0 && (
                      <div className="text-[11px] text-amber-700 font-medium mt-0.5">
                        Vào Trễ: {r.lateHC}
                      </div>
                    )}
                    <div
                      className={`text-[11px] font-bold mt-0.5 ${
                        r.diffHCText.includes('+')
                          ? 'text-emerald-600'
                          : r.diffHCText.includes('-')
                          ? 'text-rose-600'
                          : 'text-slate-600'
                      }`}
                    >
                      Thiếu/Đủ: {r.diffHCText}
                    </div>
                  </td>

                  {/* Tổng Sản Lượng & Tiến Độ */}
                  <td className="p-3 text-center align-top">
                    <div className="text-[10px] font-bold uppercase tracking-wider mb-0.5">
                      {isEos ? (
                        <span className="text-emerald-800 bg-emerald-100 border border-emerald-300 px-1.5 py-0.2 rounded font-black">
                          Actual (Cuối Ca)
                        </span>
                      ) : (
                        <span className="text-sky-800 bg-sky-100 border border-sky-300 px-1.5 py-0.2 rounded font-bold">
                          Estimate (Đầu Ca)
                        </span>
                      )}
                    </div>
                    <div className={`text-xl font-black leading-tight mb-0.5 ${isEos ? 'text-emerald-950' : 'text-sky-900'}`}>
                      {r.estimateOutput.toLocaleString()}
                    </div>
                    <div className="text-[11px] text-slate-500">
                      Tổng Kế Hoạch: {r.planOutput.toLocaleString()}
                    </div>
                    <div className="text-[11px] font-bold text-purple-700 mt-1">
                      {isEos ? 'ATT Hoàn Thành:' : 'Estimate ATT:'}
                    </div>
                    <div className="text-xs font-black text-purple-800">{r.estimateAtt}</div>
                    <div className="text-[10px] text-slate-400 mt-0.5">
                      Giờ Plan: {r.planHours}h {r.actualHours ? `| Giờ TT: ${r.actualHours}h` : ''}
                    </div>
                  </td>

                  {/* Hiệu Suất (EFF) */}
                  <td className="p-3 text-center align-top">
                    <div
                      className={`inline-block px-2.5 py-1 rounded-md font-black text-xs mb-1 ${
                        isEffMet ? 'bg-emerald-100 text-emerald-800' : 'bg-amber-100 text-amber-800'
                      }`}
                    >
                      EFF: {r.effExcludingLoss ?? r.effRate}%
                    </div>
                    {r.effIncludingLoss !== undefined && (r.qcLineCS || r.qcLineUN) ? (
                      <div className="text-[10px] text-blue-700 font-semibold" title="EFF Including Loss: Plan / [(HC routing + QC line) * Giờ TT]">
                        Inc-loss: {r.effIncludingLoss}%
                      </div>
                    ) : null}
                    <div className="text-xs font-semibold text-slate-700 mt-1">Attendance:</div>
                    <div className="text-xs font-bold text-slate-800">{r.attRate}%</div>
                  </td>

                  {/* Thao Tác */}
                  <td className="p-3 text-center align-top no-print">
                    <div className="flex items-center justify-center gap-1.5 flex-wrap">
                      {onEditReport && (
                        <button
                          type="button"
                          onClick={() => onEditReport(r)}
                          className="px-2 py-1 bg-amber-500 hover:bg-amber-600 text-white text-xs font-bold rounded-lg transition-all shadow-xs flex items-center gap-1 cursor-pointer"
                          title="Chỉnh sửa chi tiết trong Bản Tính Toán"
                        >
                          <span>✏️ Sửa</span>
                        </button>
                      )}
                      <button
                        type="button"
                        onClick={() => onOpenZalo(r)}
                        className="px-2.5 py-1 bg-sky-600 hover:bg-sky-700 text-white text-xs font-bold rounded-lg transition-all shadow-xs flex items-center gap-1 cursor-pointer"
                        title="Xem & Sao Chép Tin Nhắn Zalo"
                      >
                        <MessageSquare className="w-3.5 h-3.5" /> Zalo
                      </button>
                      <button
                        type="button"
                        onClick={() => onRequestDelete(r.id)}
                        className="p-1.5 bg-rose-50 text-rose-600 hover:bg-rose-100 border border-rose-200 rounded-lg transition-all cursor-pointer"
                        title="Xóa Báo Cáo (Cần PIN)"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>

                    {r.note && (
                      <div className="mt-2 text-[10px] text-slate-500 italic max-w-[140px] mx-auto truncate" title={r.note}>
                        📝 {r.note}
                      </div>
                    )}
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>

      {/* Empty State */}
      {filteredReports.length === 0 && (
        <div className="py-12 text-center text-slate-400 space-y-3">
          <div className="w-12 h-12 bg-slate-100 rounded-full flex items-center justify-center mx-auto text-slate-400">
            <Inbox className="w-6 h-6" />
          </div>
          <div>
            <p className="text-sm font-semibold text-slate-600">Không tìm thấy báo cáo nào</p>
            <p className="text-xs text-slate-400 mt-0.5">
              Hãy điều chỉnh lại bộ lọc tìm kiếm hoặc nhập báo cáo ở tab Bản Nhập Liệu & Tính Toán.
            </p>
          </div>
        </div>
      )}
    </section>
  );
};
