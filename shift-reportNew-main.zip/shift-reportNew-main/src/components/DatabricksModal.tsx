import React, { useState } from 'react';
import {
  Database,
  X,
  CheckCircle2,
  AlertCircle,
  RefreshCw,
  ExternalLink,
  ShieldCheck,
  Table,
  UploadCloud,
  Zap,
  Info
} from 'lucide-react';
import { DatabricksConfig } from '../types/databricks';
import {
  testDatabricksConnection,
  ensureDatabricksTable,
  syncReportsToDatabricks
} from '../utils/databricks';
import { ShiftReport } from '../types/report';

interface DatabricksModalProps {
  isOpen: boolean;
  onClose: () => void;
  config: DatabricksConfig;
  onSaveConfig: (newConfig: DatabricksConfig) => void;
  reports: ShiftReport[];
  onShowToast: (message: string, isError?: boolean) => void;
}

export const DatabricksModal: React.FC<DatabricksModalProps> = ({
  isOpen,
  onClose,
  config,
  onSaveConfig,
  reports,
  onShowToast
}) => {
  const [formData, setFormData] = useState<DatabricksConfig>(config);
  const [testing, setTesting] = useState(false);
  const [syncing, setSyncing] = useState(false);
  const [testResult, setTestResult] = useState<{ success: boolean; message: string } | null>(null);

  if (!isOpen) return null;

  const handleChange = (field: keyof DatabricksConfig, value: any) => {
    setFormData((prev) => ({ ...prev, [field]: value }));
    setTestResult(null);
  };

  const handleSave = () => {
    onSaveConfig(formData);
    onShowToast('Đã lưu cấu hình kết nối Databricks!');
  };

  const handleTestConnection = async () => {
    setTesting(true);
    setTestResult(null);
    try {
      const res = await testDatabricksConnection(formData);
      setTestResult(res);
      if (res.success) {
        onShowToast('Kết nối Databricks REST API thành công!');
      } else {
        onShowToast(`Kết nối thất bại: ${res.message}`, true);
      }
    } catch (e: any) {
      setTestResult({ success: false, message: e.message || 'Lỗi kiểm tra kết nối' });
      onShowToast(e.message || 'Lỗi kết nối Databricks', true);
    } finally {
      setTesting(false);
    }
  };

  const handleInitTable = async () => {
    setTesting(true);
    try {
      const res = await ensureDatabricksTable(formData);
      setTestResult(res);
      if (res.success) {
        onShowToast(res.message);
      } else {
        onShowToast(res.message, true);
      }
    } catch (e: any) {
      onShowToast(e.message, true);
    } finally {
      setTesting(false);
    }
  };

  const handleSyncAll = async () => {
    if (reports.length === 0) {
      onShowToast('Chưa có báo cáo nào trong hệ thống để đồng bộ!', true);
      return;
    }
    setSyncing(true);
    try {
      const res = await syncReportsToDatabricks(formData, reports);
      if (res.success) {
        onShowToast(res.message);
        setTestResult(res);
      } else {
        onShowToast(`Lỗi đồng bộ: ${res.message}`, true);
        setTestResult(res);
      }
    } catch (e: any) {
      onShowToast(`Lỗi: ${e.message}`, true);
    } finally {
      setSyncing(false);
    }
  };

  const isConfigured = Boolean(
    formData.workspaceUrl && formData.token && formData.warehouseId
  );

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-slate-900/70 backdrop-blur-xs overflow-y-auto">
      <div className="bg-white rounded-2xl shadow-2xl max-w-xl w-full border border-slate-200 overflow-hidden my-auto animate-in fade-in zoom-in-95 duration-150">
        {/* Modal Header */}
        <div className="bg-gradient-to-r from-red-600 via-rose-700 to-slate-900 text-white p-4 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="p-2 bg-white/10 rounded-xl">
              <Database className="w-5 h-5 text-red-200" />
            </div>
            <div>
              <h3 className="font-extrabold text-sm sm:text-base tracking-tight flex items-center gap-1.5">
                Kết Nối Databricks REST API
              </h3>
              <p className="text-[11px] text-red-100/80">
                Đồng bộ dữ liệu báo cáo sản xuất (BOS / EOS) vào Databricks Delta Lake
              </p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="p-1.5 text-white/80 hover:text-white hover:bg-white/10 rounded-lg transition-colors cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Modal Body */}
        <div className="p-4 sm:p-5 space-y-4 max-h-[75vh] overflow-y-auto text-xs">
          {/* Status badge */}
          <div className={`p-3 rounded-xl border flex items-start gap-2.5 ${
            isConfigured
              ? 'bg-emerald-50/80 border-emerald-200 text-emerald-950'
              : 'bg-amber-50/80 border-amber-200 text-amber-950'
          }`}>
            {isConfigured ? (
              <ShieldCheck className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
            ) : (
              <AlertCircle className="w-4 h-4 text-amber-600 shrink-0 mt-0.5" />
            )}
            <div className="text-[11px] leading-relaxed">
              <strong>Trạng thái: </strong>
              {isConfigured ? (
                <span>Đã thiết lập thông số kết nối Databricks. Bạn có thể kiểm tra kết nối hoặc đẩy dữ liệu ngay.</span>
              ) : (
                <span>Chưa nhập đủ thông số kết nối. Hãy điền Workspace URL, Token và SQL Warehouse ID bên dưới.</span>
              )}
            </div>
          </div>

          {/* Form fields */}
          <div className="space-y-3">
            {/* Workspace URL */}
            <div>
              <label className="block text-[11px] font-bold text-slate-700 mb-1">
                Databricks Workspace URL <span className="text-rose-500">*</span>
              </label>
              <input
                type="text"
                placeholder="https://adb-xxxxxx.azuredatabricks.net hoặc https://xxxx.cloud.databricks.com"
                value={formData.workspaceUrl}
                onChange={(e) => handleChange('workspaceUrl', e.target.value)}
                className="w-full bg-slate-50 border border-slate-300 rounded-lg px-3 py-2 text-xs font-mono text-slate-800 focus:outline-none focus:ring-2 focus:ring-red-500"
              />
              <span className="text-[10px] text-slate-400 mt-0.5 block">
                URL workspace Databricks của bạn (không cần dấu gạch chéo ở cuối)
              </span>
            </div>

            {/* Personal Access Token */}
            <div>
              <label className="block text-[11px] font-bold text-slate-700 mb-1">
                Personal Access Token (PAT) <span className="text-rose-500">*</span>
              </label>
              <input
                type="password"
                placeholder="dapi1a2b3c4d5e6f..."
                value={formData.token}
                onChange={(e) => handleChange('token', e.target.value)}
                className="w-full bg-slate-50 border border-slate-300 rounded-lg px-3 py-2 text-xs font-mono text-slate-800 focus:outline-none focus:ring-2 focus:ring-red-500"
              />
              <span className="text-[10px] text-slate-400 mt-0.5 block">
                Tạo tại <em>User Settings → Developer → Access tokens</em> trong Databricks
              </span>
            </div>

            {/* SQL Warehouse ID */}
            <div>
              <label className="block text-[11px] font-bold text-slate-700 mb-1">
                SQL Warehouse ID / Endpoint <span className="text-rose-500">*</span>
              </label>
              <input
                type="text"
                placeholder="Vd: 1a2b3c4d5e6f7a8b"
                value={formData.warehouseId}
                onChange={(e) => handleChange('warehouseId', e.target.value)}
                className="w-full bg-slate-50 border border-slate-300 rounded-lg px-3 py-2 text-xs font-mono text-slate-800 focus:outline-none focus:ring-2 focus:ring-red-500"
              />
              <span className="text-[10px] text-slate-400 mt-0.5 block">
                ID của SQL Warehouse (lấy trong mục <em>SQL Warehouses → Connection details → HTTP Path / Warehouse ID</em>)
              </span>
            </div>

            {/* Catalog, Schema & Table */}
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5 pt-1">
              <div>
                <label className="block text-[10px] font-bold text-slate-600 mb-1">Catalog (Unity)</label>
                <input
                  type="text"
                  placeholder="hive_metastore"
                  value={formData.catalog}
                  onChange={(e) => handleChange('catalog', e.target.value)}
                  className="w-full bg-slate-50 border border-slate-300 rounded-lg px-2.5 py-1.5 text-xs font-mono text-slate-800 focus:outline-none focus:ring-2 focus:ring-red-500"
                />
              </div>
              <div>
                <label className="block text-[10px] font-bold text-slate-600 mb-1">Database / Schema</label>
                <input
                  type="text"
                  placeholder="default"
                  value={formData.schema}
                  onChange={(e) => handleChange('schema', e.target.value)}
                  className="w-full bg-slate-50 border border-slate-300 rounded-lg px-2.5 py-1.5 text-xs font-mono text-slate-800 focus:outline-none focus:ring-2 focus:ring-red-500"
                />
              </div>
              <div>
                <label className="block text-[10px] font-bold text-slate-600 mb-1">Tên Bảng (Table)</label>
                <input
                  type="text"
                  placeholder="production_shift_reports"
                  value={formData.tableName}
                  onChange={(e) => handleChange('tableName', e.target.value)}
                  className="w-full bg-slate-50 border border-slate-300 rounded-lg px-2.5 py-1.5 text-xs font-mono text-slate-800 focus:outline-none focus:ring-2 focus:ring-red-500"
                />
              </div>
            </div>

            {/* Direct database storage mode */}
            <label className="flex items-start gap-2.5 p-3 bg-red-50/70 border border-red-200 rounded-xl cursor-pointer hover:bg-red-50 transition-colors">
              <input
                type="checkbox"
                checked={formData.useDatabricksAsPrimaryStorage}
                onChange={(e) => handleChange('useDatabricksAsPrimaryStorage', e.target.checked)}
                className="w-4 h-4 text-red-600 rounded border-slate-300 focus:ring-red-500 cursor-pointer mt-0.5"
              />
              <div>
                <span className="text-[11px] font-bold text-slate-800 block">
                  🌟 Lưu trữ & Tải trực tiếp dữ liệu từ Database Databricks (Cloud Data Mode)
                </span>
                <span className="text-[10px] text-slate-600 leading-relaxed block mt-0.5">
                  Khi bật, ứng dụng sẽ lấy và hiển thị dữ liệu tập trung trực tiếp từ bảng Databricks Delta table. Mọi thiết bị (điện thoại, máy tính) của các ca trưởng sẽ cùng thấy chung một cơ sở dữ liệu thời gian thực.
                </span>
              </div>
            </label>

            {/* Auto sync checkbox */}
            <label className="flex items-center gap-2.5 p-2.5 bg-slate-50 border border-slate-200 rounded-xl cursor-pointer hover:bg-slate-100 transition-colors">
              <input
                type="checkbox"
                checked={formData.autoSync}
                onChange={(e) => handleChange('autoSync', e.target.checked)}
                className="w-4 h-4 text-red-600 rounded border-slate-300 focus:ring-red-500 cursor-pointer"
              />
              <span className="text-[11px] font-semibold text-slate-700">
                Tự động đồng bộ lên Databricks mỗi khi Lưu Báo Cáo mới (Auto-Sync)
              </span>
            </label>
          </div>

          {/* Test connection result notice */}
          {testResult && (
            <div className={`p-3 rounded-xl border flex items-start gap-2 ${
              testResult.success
                ? 'bg-emerald-50 border-emerald-300 text-emerald-900'
                : 'bg-rose-50 border-rose-300 text-rose-900'
            }`}>
              {testResult.success ? (
                <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
              ) : (
                <AlertCircle className="w-4 h-4 text-rose-600 shrink-0 mt-0.5" />
              )}
              <div className="text-[11px] break-words">
                <div className="font-bold">{testResult.success ? 'Thành công:' : 'Lỗi kết nối:'}</div>
                <div>{testResult.message}</div>
              </div>
            </div>
          )}

          {/* Quick guide */}
          <div className="p-3 bg-slate-50 rounded-xl border border-slate-200 space-y-1.5 text-slate-600 text-[11px]">
            <div className="font-bold text-slate-800 flex items-center gap-1.5">
              <Info className="w-3.5 h-3.5 text-sky-600" /> Hướng dẫn đồng bộ vào Delta Lake:
            </div>
            <ul className="list-disc list-inside space-y-1 text-slate-600 pl-1">
              <li>API sử dụng <strong>Databricks SQL Statement Execution REST API</strong> (`/api/2.0/sql/statements`).</li>
              <li>Dữ liệu được lưu dạng <strong>Delta Table</strong> với lệnh <code>MERGE INTO</code>, tự động cập nhật khi trùng Line, Ngày, Ca và Giai đoạn (BOS/EOS).</li>
              <li>Bấm <strong>Khởi Tạo Bảng Delta</strong> để tự động tạo schema đầy đủ 40 cột (Sản lượng, HC, EFF, Loss, Giờ làm việc, Remark).</li>
            </ul>
          </div>
        </div>

        {/* Modal Actions */}
        <div className="bg-slate-50 border-t border-slate-200 p-3 sm:p-4 flex flex-wrap items-center justify-between gap-2">
          <div className="flex items-center gap-2 flex-wrap">
            <button
              type="button"
              disabled={testing || !isConfigured}
              onClick={handleTestConnection}
              className="px-3 py-1.5 bg-slate-200 hover:bg-slate-300 text-slate-800 rounded-lg text-xs font-bold transition-all flex items-center gap-1.5 disabled:opacity-50 cursor-pointer"
            >
              <RefreshCw className={`w-3.5 h-3.5 ${testing ? 'animate-spin' : ''}`} />
              Kiểm Tra Kết Nối
            </button>
            <button
              type="button"
              disabled={testing || !isConfigured}
              onClick={handleInitTable}
              className="px-3 py-1.5 bg-indigo-50 hover:bg-indigo-100 text-indigo-700 border border-indigo-200 rounded-lg text-xs font-bold transition-all flex items-center gap-1.5 disabled:opacity-50 cursor-pointer"
              title="Chạy lệnh CREATE TABLE IF NOT EXISTS trên Databricks"
            >
              <Table className="w-3.5 h-3.5" />
              Khởi Tạo Bảng Delta
            </button>
          </div>

          <div className="flex items-center gap-2">
            <button
              type="button"
              disabled={syncing || !isConfigured || reports.length === 0}
              onClick={handleSyncAll}
              className="px-3 py-1.5 bg-rose-600 hover:bg-rose-700 text-white rounded-lg text-xs font-bold transition-all flex items-center gap-1.5 disabled:opacity-50 cursor-pointer shadow-xs"
              title={`Đẩy toàn bộ ${reports.length} báo cáo hiện có lên Databricks`}
            >
              <UploadCloud className={`w-3.5 h-3.5 ${syncing ? 'animate-bounce' : ''}`} />
              Đồng Bộ {reports.length} Báo Cáo
            </button>
            <button
              type="button"
              onClick={handleSave}
              className="px-4 py-1.5 bg-slate-900 hover:bg-slate-800 text-white rounded-lg text-xs font-black transition-all cursor-pointer shadow-xs"
            >
              Lưu Cấu Hình
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
