import React, { useState, useMemo } from 'react';
import {
  PenSquare,
  Users,
  TrendingUp,
  Save,
  RotateCcw,
  Layers,
  Box,
  CircleHelp,
  CheckCircle2,
  Calendar,
  Clock,
  ArrowRight
} from 'lucide-react';
import { ShiftReport } from '../types/report';
import { getSmartShiftDate, detectShift, parseNumber } from '../utils/calculations';

interface ReportFormProps {
  onSaveReport: (report: ShiftReport) => void;
  onShowToast: (message: string, isError?: boolean) => void;
  reports?: ShiftReport[];
  initialLine?: string;
  initialStage?: 'BOS' | 'EOS';
  onBackToReport?: () => void;
}

export const ReportForm: React.FC<ReportFormProps> = ({
  onSaveReport,
  onShowToast,
  reports = [],
  initialLine,
  initialStage,
  onBackToReport
}) => {
  // 2 Tab riêng biệt: BOS (Đầu Ca - Estimate) và EOS (Cuối Ca - Actual)
  const [reportStage, setReportStage] = useState<'BOS' | 'EOS'>(initialStage || 'BOS');

  const [line, setLine] = useState(initialLine || '');
  const [totalHC, setTotalHC] = useState<string>('');
  const [leaveAL, setLeaveAL] = useState<string>('');
  const [leaveSL, setLeaveSL] = useState<string>('');
  const [leaveUP, setLeaveUP] = useState<string>('');
  const [leaveUPP, setLeaveUPP] = useState<string>('');
  const [leaveOther, setLeaveOther] = useState<string>('');
  const [lateHC, setLateHC] = useState<string>('');
  const [planHCCS, setPlanHCCS] = useState<string>('');
  const [planHCUN, setPlanHCUN] = useState<string>('');
  const [routingHCCS, setRoutingHCCS] = useState<string>('');
  const [routingHCUN, setRoutingHCUN] = useState<string>('');

  const [model, setModel] = useState('');

  // Job CS & its quantity
  const [jobCS, setJobCS] = useState('');
  const [qcLineCS, setQcLineCS] = useState('');
  const [planOutputCS, setPlanOutputCS] = useState<string>('');
  const [estimateOutputCS, setEstimateOutputCS] = useState<string>('');

  // Job UN & its quantity
  const [jobUN, setJobUN] = useState('');
  const [qcLineUN, setQcLineUN] = useState('');
  const [planOutputUN, setPlanOutputUN] = useState<string>('');
  const [estimateOutputUN, setEstimateOutputUN] = useState<string>('');

  const [planHours, setPlanHours] = useState('');
  const [actualHours, setActualHours] = useState('');
  const [uph, setUph] = useState<string>('');
  const [reportDate, setReportDate] = useState(getSmartShiftDate());
  const [leaderName, setLeaderName] = useState('');
  const [note, setNote] = useState('');

  // Extended fields for Daily Summary format
  const [remarkFailAtt, setRemarkFailAtt] = useState('');
  const [jobPending, setJobPending] = useState('');
  const [reason, setReason] = useState('');
  const [dueDate, setDueDate] = useState('');
  const [showExtendedFields, setShowExtendedFields] = useState(false);

  // Shift detection
  const detectedShift = detectShift(line);

  // Helper tìm mã base line (bỏ LINE, N, D)
  const getLineBase = (str: string) => {
    return str.replace(/^LINE\s*/i, '').replace(/[ND]$/i, '').trim().toUpperCase();
  };

  // Tìm báo cáo BOS của Line hiện tại trong ngày và ca này
  const currentLineBase = getLineBase(line);
  const matchedBosReport = useMemo(() => {
    if (!reports || reports.length === 0 || !currentLineBase) return null;
    return (
      reports.find((r) => {
        const rBase = getLineBase(r.line);
        const matchesDate = !reportDate || r.date === reportDate;
        const matchesShift = r.shiftType === detectedShift.shift;
        const isBos = r.reportStage !== 'EOS';
        return rBase === currentLineBase && matchesDate && matchesShift && isBos;
      }) || null
    );
  }, [reports, currentLineBase, reportDate, detectedShift.shift]);

  // Danh sách các báo cáo BOS có sẵn hôm nay để gợi ý nạp nhanh
  const todayBosReports = useMemo(() => {
    if (!reports) return [];
    return reports.filter((r) => {
      const matchesDate = !reportDate || r.date === reportDate;
      const isBos = r.reportStage !== 'EOS';
      return matchesDate && isBos;
    });
  }, [reports, reportDate]);

  // Hàm tự động nạp dữ liệu từ báo cáo BOS sang tab EOS
  // Dữ liệu đầu ca sẽ tự động fill, TRỪ các ô như Estimate/Actual sẽ để người dùng tự điền vào
  const fillFromBosReport = (bos: ShiftReport, notify = true) => {
    setLine(bos.line);
    setReportDate(bos.date);
    setLeaderName(bos.leader && bos.leader !== 'Line Leader' ? bos.leader : (bos.leader || ''));
    setModel(bos.model || '');
    setJobCS(bos.jobCS || '');
    setQcLineCS(bos.qcLineCS !== undefined && bos.qcLineCS !== null ? String(bos.qcLineCS) : '');
    setPlanOutputCS(bos.planOutputCS !== undefined ? String(bos.planOutputCS) : '');
    setJobUN(bos.jobUN || '');
    setQcLineUN(bos.qcLineUN !== undefined && bos.qcLineUN !== null ? String(bos.qcLineUN) : '');
    setPlanOutputUN(bos.planOutputUN !== undefined ? String(bos.planOutputUN) : '');
    setUph(bos.uph ? String(bos.uph) : '');
    setPlanHours(bos.planHours || '');
    setTotalHC(bos.totalHC ? String(bos.totalHC) : '');
    setLeaveAL(bos.leaveAL ? String(bos.leaveAL) : '');
    setLeaveSL(bos.leaveSL ? String(bos.leaveSL) : '');
    setLeaveUP(bos.leaveUP ? String(bos.leaveUP) : '');
    setLeaveUPP(bos.leaveUPP ? String(bos.leaveUPP) : '');
    setLeaveOther(bos.leaveOther ? String(bos.leaveOther) : '');
    setLateHC(bos.lateHC ? String(bos.lateHC) : '');
    setPlanHCCS(bos.planHCCS ? String(bos.planHCCS) : '');
    setPlanHCUN(bos.planHCUN ? String(bos.planHCUN) : '');
    setRoutingHCCS(bos.routingHCCS ? String(bos.routingHCCS) : '');
    setRoutingHCUN(bos.routingHCUN ? String(bos.routingHCUN) : '');
    if (bos.remarkFailAtt) setRemarkFailAtt(bos.remarkFailAtt);
    if (bos.jobPending) setJobPending(bos.jobPending);
    if (bos.reason) setReason(bos.reason);
    if (bos.dueDate) setDueDate(bos.dueDate);

    // TRỪ CÁC Ô SẢN LƯỢNG THỰC TẾ (ACTUAL) VÀ KẾT QUẢ CUỐI CA ĐỂ NGƯỜI DÙNG ĐIỀN VÀO:
    setEstimateOutputCS('');
    setEstimateOutputUN('');
    setActualHours('');
    setNote('');

    if (notify) {
      onShowToast(`Đã tự động nạp dữ liệu nền từ BOS của Line ${bos.line}! Hãy điền sản lượng Thực Tế (Actual).`);
    }
  };

  // Xử lý chuyển đổi giữa Tab BOS và Tab EOS
  const handleSwitchTab = (newTab: 'BOS' | 'EOS') => {
    setReportStage(newTab);
    if (newTab === 'EOS') {
      if (matchedBosReport) {
        fillFromBosReport(matchedBosReport);
      } else if (todayBosReports.length > 0 && !line) {
        fillFromBosReport(todayBosReports[0]);
      } else {
        // Nếu chuyển sang EOS mà chưa có BOS cho line hiện tại, xóa ô Actual để nhập mới
        setEstimateOutputCS('');
        setEstimateOutputUN('');
        setActualHours('');
      }
    }
  };

  // Xử lý khi người dùng chọn Line (từ chip hoặc nhập tay)
  const handleSelectLine = (targetLine: string) => {
    setLine(targetLine);
    if (reportStage === 'EOS') {
      const targetBase = getLineBase(targetLine);
      const targetShift = targetLine.endsWith('N') ? 'night' : 'day';
      const matched = reports.find((r) => {
        const rBase = getLineBase(r.line);
        const matchesDate = !reportDate || r.date === reportDate;
        const matchesShift = r.shiftType === targetShift;
        const isBos = r.reportStage !== 'EOS';
        return rBase === targetBase && matchesDate && matchesShift && isBos;
      });

      if (matched) {
        fillFromBosReport(matched);
      } else {
        setEstimateOutputCS('');
        setEstimateOutputUN('');
        setActualHours('');
      }
    }
  };

  // HC Calculations
  const numTotalHC = parseNumber(totalHC);
  const numAL = parseNumber(leaveAL);
  const numSL = parseNumber(leaveSL);
  const numUP = parseNumber(leaveUP);
  const numUPP = parseNumber(leaveUPP);
  const numOther = parseNumber(leaveOther);
  const totalLeave = numAL + numSL + numUP + numUPP + numOther;

  const numLateHC = parseNumber(lateHC);
  const numPlanHCCS = parseNumber(planHCCS);
  const numPlanHCUN = parseNumber(planHCUN);
  const totalPlanHC = numPlanHCCS + numPlanHCUN;

  const numRoutingHCCS = parseNumber(routingHCCS);
  const numRoutingHCUN = parseNumber(routingHCUN);
  const totalRoutingHC = numRoutingHCCS + numRoutingHCUN;

  const presentHC = Math.max(0, numTotalHC - totalLeave);
  const diffHC = presentHC - totalRoutingHC;

  let diffText = '0 (Đủ)';
  let diffClass = 'bg-emerald-50 text-emerald-800 border-emerald-300';
  if (diffHC > 0) {
    diffText = `+${diffHC} (Thừa)`;
    diffClass = 'bg-emerald-100 text-emerald-800 border-emerald-300';
  } else if (diffHC < 0) {
    diffText = `${diffHC} (Thiếu)`;
    diffClass = 'bg-rose-100 text-rose-800 border-rose-300';
  }

  const attRate = numTotalHC > 0 ? Math.round((presentHC / numTotalHC) * 1000) / 10 : 0;

  // Job Quantities
  const numPlanCS = parseNumber(planOutputCS);
  const numEstCS = parseNumber(estimateOutputCS);
  const numPlanUN = parseNumber(planOutputUN);
  const numEstUN = parseNumber(estimateOutputUN);

  // Total Plan and Actual/Estimate across both jobs
  const totalPlanOutput = numPlanCS + numPlanUN;
  const totalEstimateOutput = numEstCS + numEstUN;

  // Production & Eff Calculations
  const numPlanHours = parseNumber(planHours);
  const numActualHours = parseNumber(actualHours);
  const numUPH = parseNumber(uph);

  const actualOutputCS = numEstCS > 0 ? numEstCS : numPlanCS;
  const actualOutputUN = numEstUN > 0 ? numEstUN : numPlanUN;
  const actualOutput = totalEstimateOutput > 0 ? totalEstimateOutput : totalPlanOutput;

  // STD của CS = (HC Plan CS * Sản lượng CS) / UPH
  const stdHourCSNum =
    numUPH > 0 && numPlanHCCS > 0 && actualOutputCS > 0
      ? (numPlanHCCS * actualOutputCS) / numUPH
      : 0;

  // STD của UN = (HC Plan UN * Sản lượng UN) / UPH
  const stdHourUNNum =
    numUPH > 0 && numPlanHCUN > 0 && actualOutputUN > 0
      ? (numPlanHCUN * actualOutputUN) / numUPH
      : 0;

  // STD Hour tiêu chuẩn = STD của CS + STD UN (dựa theo HC của CS và UN)
  const stdHourNum =
    numPlanHCCS > 0 || numPlanHCUN > 0
      ? stdHourCSNum + stdHourUNNum
      : numUPH > 0 && totalPlanHC > 0 && actualOutput > 0
      ? (totalPlanHC * actualOutput) / numUPH
      : 0;

  const actualHC = totalRoutingHC;
  const actualHoursNum = numActualHours > 0 ? numActualHours : 0;

  // Thực tế excluding loss (bữa giờ) = HC routing * Giờ thực tế
  const actualLineNum = actualHC > 0 && actualHoursNum > 0 ? actualHC * actualHoursNum : 0;

  // Plan = HC plan * sản lượng (estimate hoặc actual nếu là EOS) / UPH (= stdHourNum)
  // EFF excluding loss = Plan / Thực tế (bữa giờ)
  const effExcludingLoss = actualLineNum > 0 ? Math.round((stdHourNum / actualLineNum) * 1000) / 10 : 0;

  // Tổng QC Line = QC Line CS + QC Line UN
  const totalQCLine = parseNumber(qcLineCS) + parseNumber(qcLineUN);

  // Thực tế including loss = (HC routing + QC line) * Giờ thực tế
  const actualHCWithQC = actualHC + totalQCLine;
  const actualLineWithQC = actualHCWithQC > 0 && actualHoursNum > 0 ? actualHCWithQC * actualHoursNum : 0;

  // EFF including loss = Plan / Thực tế = Plan / [(HC routing + QC line) * Giờ thực tế]
  const effIncludingLoss =
    actualLineWithQC > 0
      ? Math.round((stdHourNum / actualLineWithQC) * 1000) / 10
      : effExcludingLoss;

  const effRate = effExcludingLoss; // Số EFF chuẩn bữa giờ
  const estimateAtt = totalPlanOutput > 0 ? Math.round((totalEstimateOutput / totalPlanOutput) * 1000) / 10 : 0;

  const handleReset = () => {
    setLine('');
    setTotalHC('');
    setLeaveAL('');
    setLeaveSL('');
    setLeaveUP('');
    setLeaveUPP('');
    setLeaveOther('');
    setLateHC('');
    setPlanHCCS('');
    setPlanHCUN('');
    setRoutingHCCS('');
    setRoutingHCUN('');
    setModel('');
    setJobCS('');
    setQcLineCS('');
    setPlanOutputCS('');
    setEstimateOutputCS('');
    setJobUN('');
    setQcLineUN('');
    setPlanOutputUN('');
    setEstimateOutputUN('');
    setPlanHours('');
    setActualHours('');
    setUph('');
    setLeaderName('');
    setNote('');
    setRemarkFailAtt('');
    setJobPending('');
    setReason('');
    setDueDate('');
  };

  const fillQuickPreset = () => {
    const shiftSuffix = detectedShift.shift === 'night' ? 'N' : 'D';
    setLine(`1323${shiftSuffix}`);
    setTotalHC('26');
    setLeaveAL('1');
    setLeaveSL('0');
    setLeaveUP('1');
    setLeaveUPP('0');
    setLeaveOther('0');
    setLateHC('1');
    setPlanHCCS('12');
    setPlanHCUN('12');
    setRoutingHCCS('12');
    setRoutingHCUN('12');
    setModel('K550');
    setJobCS('MP105550010-K5501CS-PC20');
    setPlanOutputCS('250');
    setEstimateOutputCS('245');
    setJobUN('MP105550010-K5501UN-PC20');
    setPlanOutputUN('250');
    setEstimateOutputUN('240');
    setUph('25');
    setPlanHours('10');
    setActualHours('10');
    setLeaderName('Nguyễn Văn A (Leader)');
    setNote('Máy móc vận hành ổn định.');
    onShowToast('Đã nạp mẫu dữ liệu nhanh!');
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();

    if (!line.trim()) {
      onShowToast('Vui lòng nhập tên Line chuyền (Vd: 1323D hoặc 1323N)!', true);
      return;
    }
    if (numTotalHC <= 0) {
      onShowToast('Vui lòng nhập Tổng HC hợp lệ (> 0)!', true);
      return;
    }
    if (totalPlanHC <= 0) {
      onShowToast('Vui lòng nhập HC Plan (Plan CS hoặc Plan UN)!', true);
      return;
    }
    if (totalRoutingHC <= 0) {
      onShowToast('Vui lòng nhập HC Routing (HC CS hoặc HC UN)!', true);
      return;
    }
    if (!planHours.trim() || parseNumber(planHours) <= 0) {
      onShowToast('Vui lòng nhập Giờ Plan hợp lệ (> 0)!', true);
      return;
    }
    if (!actualHours.trim() || parseNumber(actualHours) <= 0) {
      onShowToast('Vui lòng nhập Giờ Thực Tế hợp lệ (> 0)!', true);
      return;
    }
    if (!leaderName.trim()) {
      onShowToast('Vui lòng nhập họ tên Line Leader!', true);
      return;
    }

    const report: ShiftReport = {
      id: 'rep-' + Date.now(),
      requestId: crypto.randomUUID(),
      line: line.trim().toUpperCase(),
      shiftType: detectedShift.shift,
      reportStage: reportStage, // 'BOS' (Đầu Ca) hoặc 'EOS' (Cuối Ca)
      totalHC: numTotalHC,
      leaveAL: numAL,
      leaveSL: numSL,
      leaveUP: numUP,
      leaveUPP: numUPP,
      leaveOther: numOther,
      totalLeaveHC: totalLeave,
      lateHC: numLateHC,
      planHC: totalPlanHC,
      planHCCS: numPlanHCCS,
      planHCUN: numPlanHCUN,
      routingHC: totalRoutingHC,
      routingHCCS: numRoutingHCCS,
      routingHCUN: numRoutingHCUN,
      presentHC,
      diffHCText: diffText,
      attRate,
      model: model.trim(),
      jobCS: jobCS.trim(),
      qcLineCS: qcLineCS.trim() ? parseNumber(qcLineCS) : undefined,
      planOutputCS: numPlanCS,
      estimateOutputCS: numEstCS,
      jobUN: jobUN.trim(),
      qcLineUN: qcLineUN.trim() ? parseNumber(qcLineUN) : undefined,
      planOutputUN: numPlanUN,
      estimateOutputUN: numEstUN,
      uph: numUPH,
      stdHour: `${stdHourNum.toFixed(1)}h`,
      stdHourCS: stdHourCSNum > 0 ? `${stdHourCSNum.toFixed(1)}h` : undefined,
      stdHourUN: stdHourUNNum > 0 ? `${stdHourUNNum.toFixed(1)}h` : undefined,
      actualLine: `${actualLineNum.toFixed(1)}h`,
      planOutput: totalPlanOutput,
      estimateOutput: totalEstimateOutput,
      estimateAtt: `${estimateAtt}%`,
      planHours: planHours.trim().replace(',', '.'),
      actualHours: actualHours.trim().replace(',', '.'),
      effRate,
      effExcludingLoss,
      effIncludingLoss,
      date: reportDate,
      leader: leaderName.trim(),
      note: note.trim(),
      remarkFailAtt:
        remarkFailAtt.trim() ||
        (attRate < 95 ? `Vắng ${totalLeave} (AL:${numAL}, SL:${numSL})` : 'Đạt ATT'),
      jobPending: jobPending.trim() || jobCS.trim() || 'Job Pending',
      reason:
        reason.trim() ||
        note.trim() ||
        (totalEstimateOutput < totalPlanOutput
          ? 'Hụt sản lượng theo kế hoạch'
          : 'Vận hành ổn định'),
      dueDate:
        dueDate.trim() ||
        (totalEstimateOutput < totalPlanOutput ? 'Trong 24h tới' : 'Đúng tiến độ'),
      createdAt: Date.now()
    };

    onSaveReport(report);
    onShowToast(
      `Đã lưu Báo Cáo ${reportStage === 'EOS' ? 'Cuối Ca (EOS - Actual)' : 'Đầu Ca (BOS - Estimate)'} cho Line ${line.trim()}!`
    );
    handleReset();
  };

  React.useEffect(() => {
    if (initialLine) {
      setLine(initialLine);
    }
    if (initialStage) {
      setReportStage(initialStage);
    }
  }, [initialLine, initialStage]);

  return (
    <section className="bg-white rounded-2xl shadow-sm border border-slate-200 overflow-hidden no-print">
      {/* Header bar */}
      <div className="bg-slate-900 text-white px-3 sm:px-4 py-1.5 sm:py-2 flex justify-between items-center flex-wrap gap-1.5">
        <h2 className="font-bold text-xs sm:text-sm flex items-center gap-1.5">
          <PenSquare className="w-3.5 h-3.5 text-sky-400" />
          Bản Nhập Dữ Liệu & Tính Toán Ca (BOS / EOS)
        </h2>
        <div className="flex items-center gap-1.5 flex-wrap">
          {onBackToReport && (
            <button
              type="button"
              onClick={onBackToReport}
              className="text-[11px] bg-sky-600 hover:bg-sky-500 text-white font-bold px-2.5 py-0.5 rounded-md flex items-center gap-1 transition-colors cursor-pointer shadow-2xs"
              title="Chuyển sang Bảng Báo Cáo"
            >
              <span>📊 Báo Cáo</span>
            </button>
          )}
          <span className="text-[10px] bg-slate-800 text-sky-300 border border-slate-700 px-2 py-0.5 rounded-md font-mono font-bold">
            {detectedShift.label}
          </span>
        </div>
      </div>

      {/* 2 TAB RIÊNG BIỆT: BOS (ĐẦU CA) & EOS (CUỐI CA) */}
      <div className="p-1 sm:p-1.5 bg-slate-950 border-b border-slate-800 grid grid-cols-2 gap-1.5">
        <button
          type="button"
          onClick={() => handleSwitchTab('BOS')}
          className={`py-1 px-2.5 rounded-lg transition-all cursor-pointer flex items-center gap-2 text-left border ${
            reportStage === 'BOS'
              ? 'bg-gradient-to-r from-sky-600 to-blue-700 text-white border-sky-400 shadow-sm font-black ring-1 ring-sky-400/40'
              : 'bg-slate-900/80 hover:bg-slate-800 text-slate-400 hover:text-slate-200 border-slate-800'
          }`}
        >
          <span className="text-base sm:text-lg">
            {detectedShift.shift === 'night' ? '🌙' : '☀️'}
          </span>
          <div className="leading-tight truncate">
            <div className="text-[11px] font-black uppercase tracking-wide flex items-center gap-1">
              BOS (Đầu Ca)
              {reportStage === 'BOS' && (
                <span className="w-1.5 h-1.5 rounded-full bg-amber-300 animate-pulse"></span>
              )}
            </div>
            <div className="text-[9px] font-medium opacity-80">Kế hoạch & Estimate</div>
          </div>
        </button>

        <button
          type="button"
          onClick={() => handleSwitchTab('EOS')}
          className={`py-1 px-2.5 rounded-lg transition-all cursor-pointer flex items-center gap-2 text-left border ${
            reportStage === 'EOS'
              ? 'bg-gradient-to-r from-emerald-600 to-teal-700 text-white border-emerald-400 shadow-sm font-black ring-1 ring-emerald-400/40'
              : 'bg-slate-900/80 hover:bg-slate-800 text-slate-400 hover:text-slate-200 border-slate-800'
          }`}
        >
          <span className="text-base sm:text-lg">🏁</span>
          <div className="leading-tight truncate">
            <div className="text-[11px] font-black uppercase tracking-wide flex items-center gap-1">
              EOS (Cuối Ca)
              {reportStage === 'EOS' && (
                <span className="w-1.5 h-1.5 rounded-full bg-emerald-300 animate-pulse"></span>
              )}
            </div>
            <div className="text-[9px] font-medium opacity-80">Tổng kết & Actual</div>
          </div>
        </button>
      </div>

      {/* BANNER THÔNG TIN TRONG TAB EOS: TỰ ĐỘNG NẠP TỪ BOS */}
      {reportStage === 'EOS' && (
        <div className="bg-gradient-to-r from-emerald-50 via-teal-50 to-emerald-50 border-b border-emerald-200 px-4 py-2.5 text-xs text-emerald-950">
          <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-2">
            <div className="flex items-center gap-2">
              <span className="px-1.5 py-0.5 rounded bg-emerald-600 text-white font-black text-[10px] uppercase shrink-0">
                Tự Động Điền
              </span>
              <p className="text-[11px] font-medium text-emerald-900">
                {matchedBosReport ? (
                  <span>
                    Đã tự động lấy số liệu đầu ca từ <strong>BOS Line {matchedBosReport.line}</strong>. Toàn bộ kế hoạch và thông số đã được điền, bạn chỉ cần nhập <strong>Actual (Thực Tế)</strong> bên dưới.
                  </span>
                ) : (
                  <span>
                    Chưa tìm thấy báo cáo BOS cho Line {line || 'đang chọn'}. Khi bạn nhập mã Line (1323 - 1328), hệ thống sẽ tự động nạp số liệu đầu ca.
                  </span>
                )}
              </p>
            </div>
            {matchedBosReport && (
              <button
                type="button"
                onClick={() => fillFromBosReport(matchedBosReport)}
                className="px-2 py-0.5 bg-emerald-700 hover:bg-emerald-800 text-white rounded text-[10px] font-bold shrink-0 flex items-center gap-1 cursor-pointer transition-colors shadow-2xs"
                title="Nạp lại toàn bộ dữ liệu nền từ BOS"
              >
                <RotateCcw className="w-2.5 h-2.5" /> Nạp lại từ BOS
              </button>
            )}
          </div>
        </div>
      )}

      <form onSubmit={handleSubmit} className="p-5 space-y-5">
        {/* TEMPLATE 1: ĐIỂM DANH NHÂN SỰ (HC UPDATE) */}
        <div className="bg-slate-50 p-4 rounded-xl border border-slate-200/80 space-y-3">
          <div className="flex justify-between items-center">
            <h3 className="text-xs font-bold text-sky-900 uppercase tracking-wider flex items-center gap-1.5">
              <Users className="w-4 h-4 text-sky-600" /> Điểm Danh Nhân Sự (HC)
            </h3>
            <span
              className={`text-[11px] font-bold px-2.5 py-0.5 rounded-full border ${
                attRate >= 95
                  ? 'bg-emerald-100 text-emerald-800 border-emerald-300'
                  : 'bg-amber-100 text-amber-800 border-amber-300'
              }`}
            >
              Attendance: {attRate}%
            </span>
          </div>

          {/* Hàng 1: Line & Tổng HC */}
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                Line (Hậu tố N: Đêm | D: Ngày) <span className="text-rose-500">*</span>
              </label>
              <input
                type="text"
                required
                placeholder="Vd: 1325N / 1325D"
                value={line}
                onChange={(e) => handleSelectLine(e.target.value.toUpperCase())}
                className="w-full bg-white border border-slate-300 rounded-lg px-3 py-1.5 text-sm font-extrabold text-sky-900 focus:outline-none focus:ring-2 focus:ring-sky-500 uppercase"
              />
              <p className="text-[10px] text-slate-400 mt-0.5">
                {line.endsWith('N')
                  ? '🌙 Đã nhận diện: Ca Đêm (Night)'
                  : line.endsWith('D')
                  ? '☀️ Đã nhận diện: Ca Ngày (Day)'
                  : 'Gợi ý: Thêm đuôi N hoặc D'}
              </p>
              {/* Quick line chips for 1323 - 1328 */}
              <div className="flex items-center gap-1 mt-1.5 flex-wrap">
                <span className="text-[10px] text-slate-500 font-bold">6 Line:</span>
                {['1323', '1324', '1325', '1326', '1327', '1328'].map((l) => {
                  const shiftSuffix = detectedShift.shift === 'night' ? 'N' : 'D';
                  const targetLine = `${l}${shiftSuffix}`;
                  const isSelected = line.startsWith(l);
                  return (
                    <button
                      key={l}
                      type="button"
                      onClick={() => handleSelectLine(targetLine)}
                      className={`px-1.5 py-0.5 rounded text-[10px] font-black cursor-pointer transition-all ${
                        isSelected
                          ? 'bg-sky-600 text-white shadow-2xs'
                          : 'bg-slate-200 hover:bg-slate-300 text-slate-700'
                      }`}
                    >
                      {l}
                    </button>
                  );
                })}
              </div>
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                Tổng HC <span className="text-rose-500">*</span>
              </label>
              <input
                type="number"
                min="0"
                required
                placeholder="Vd: 28"
                value={totalHC}
                onChange={(e) => setTotalHC(e.target.value)}
                className="w-full bg-white border border-slate-300 rounded-lg px-3 py-1.5 text-sm font-bold text-center focus:outline-none focus:ring-2 focus:ring-sky-500"
              />
            </div>
          </div>

          {/* Hàng 2: 5 Loại vắng chi tiết: AL, SL, UP, UPP, Khác */}
          <div className="bg-rose-50/60 p-2.5 rounded-lg border border-rose-200/60 space-y-1.5">
            <div className="flex justify-between items-center">
              <label className="block text-[11px] font-bold text-rose-800">
                Các Loại Vắng (Tổng: <span className="text-rose-900 font-black">{totalLeave}</span>)
              </label>
              <span className="text-[10px] text-rose-500 italic">AL / SL / UP / UPP / Khác</span>
            </div>
            <div className="grid grid-cols-5 gap-1.5">
              <div>
                <label className="block text-[10px] font-semibold text-slate-600 mb-0.5 text-center">AL</label>
                <input
                  type="number"
                  min="0"
                  placeholder="0"
                  value={leaveAL}
                  onChange={(e) => setLeaveAL(e.target.value)}
                  className="w-full bg-white border border-rose-200 text-rose-800 rounded-lg px-1 py-1 text-xs font-bold text-center focus:outline-none focus:ring-2 focus:ring-rose-400"
                />
              </div>
              <div>
                <label className="block text-[10px] font-semibold text-slate-600 mb-0.5 text-center">SL</label>
                <input
                  type="number"
                  min="0"
                  placeholder="0"
                  value={leaveSL}
                  onChange={(e) => setLeaveSL(e.target.value)}
                  className="w-full bg-white border border-rose-200 text-rose-800 rounded-lg px-1 py-1 text-xs font-bold text-center focus:outline-none focus:ring-2 focus:ring-rose-400"
                />
              </div>
              <div>
                <label className="block text-[10px] font-semibold text-slate-600 mb-0.5 text-center">UP</label>
                <input
                  type="number"
                  min="0"
                  placeholder="0"
                  value={leaveUP}
                  onChange={(e) => setLeaveUP(e.target.value)}
                  className="w-full bg-white border border-rose-200 text-rose-800 rounded-lg px-1 py-1 text-xs font-bold text-center focus:outline-none focus:ring-2 focus:ring-rose-400"
                />
              </div>
              <div>
                <label className="block text-[10px] font-semibold text-slate-600 mb-0.5 text-center">UPP</label>
                <input
                  type="number"
                  min="0"
                  placeholder="0"
                  value={leaveUPP}
                  onChange={(e) => setLeaveUPP(e.target.value)}
                  className="w-full bg-white border border-rose-300 text-rose-900 rounded-lg px-1 py-1 text-xs font-black text-center focus:outline-none focus:ring-2 focus:ring-rose-500"
                />
              </div>
              <div>
                <label className="block text-[10px] font-semibold text-slate-600 mb-0.5 text-center">Khác</label>
                <input
                  type="number"
                  min="0"
                  placeholder="0"
                  value={leaveOther}
                  onChange={(e) => setLeaveOther(e.target.value)}
                  className="w-full bg-white border border-rose-200 text-rose-800 rounded-lg px-1 py-1 text-xs font-bold text-center focus:outline-none focus:ring-2 focus:ring-rose-400"
                />
              </div>
            </div>
          </div>

          {/* Hàng 3: Đi Trễ, HC Plan (CS/UN) & HC Routing (CS/UN) */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5 pt-1">
            <div>
              <label className="block text-[11px] font-semibold text-slate-700 mb-1">Vào Trễ (Late)</label>
              <input
                type="number"
                min="0"
                placeholder="0"
                value={lateHC}
                onChange={(e) => setLateHC(e.target.value)}
                className="w-full bg-white border border-slate-300 rounded-lg px-2 py-1.5 text-xs text-center font-bold focus:outline-none focus:ring-2 focus:ring-sky-500"
              />
            </div>
            <div>
              <div className="flex justify-between items-center mb-1">
                <label className="block text-[11px] font-bold text-slate-700 truncate">
                  HC Plan <span className="text-rose-500">*</span>
                </label>
                <span
                  className="text-[10px] font-black text-amber-800 bg-amber-100 border border-amber-300 px-1.5 py-0.5 rounded"
                  title="Tổng HC Plan = Plan CS + Plan UN"
                >
                  Tổng: {totalPlanHC}
                </span>
              </div>
              <div className="grid grid-cols-2 gap-1.5">
                <div>
                  <input
                    type="number"
                    min="0"
                    placeholder="Plan CS"
                    title="HC Plan CS"
                    value={planHCCS}
                    onChange={(e) => setPlanHCCS(e.target.value)}
                    className="w-full bg-amber-50/70 border border-amber-300 rounded-lg px-1.5 py-1.5 text-xs font-bold text-center text-amber-950 focus:outline-none focus:ring-2 focus:ring-amber-500"
                  />
                </div>
                <div>
                  <input
                    type="number"
                    min="0"
                    placeholder="Plan UN"
                    title="HC Plan UN"
                    value={planHCUN}
                    onChange={(e) => setPlanHCUN(e.target.value)}
                    className="w-full bg-amber-50/70 border border-amber-300 rounded-lg px-1.5 py-1.5 text-xs font-bold text-center text-amber-950 focus:outline-none focus:ring-2 focus:ring-amber-500"
                  />
                </div>
              </div>
            </div>
            <div>
              <div className="flex justify-between items-center mb-1">
                <label className="block text-[11px] font-bold text-slate-700 truncate">
                  HC Routing <span className="text-rose-500">*</span>
                </label>
                <span
                  className="text-[10px] font-black text-sky-800 bg-sky-100 border border-sky-300 px-1.5 py-0.5 rounded"
                  title="Tổng HC Routing = HC CS + HC UN"
                >
                  Tổng: {totalRoutingHC}
                </span>
              </div>
              <div className="grid grid-cols-2 gap-1.5">
                <div>
                  <input
                    type="number"
                    min="0"
                    placeholder="HC CS"
                    title="HC Routing CS"
                    value={routingHCCS}
                    onChange={(e) => setRoutingHCCS(e.target.value)}
                    className="w-full bg-sky-50/70 border border-sky-300 rounded-lg px-1.5 py-1.5 text-xs font-bold text-center text-sky-950 focus:outline-none focus:ring-2 focus:ring-sky-500"
                  />
                </div>
                <div>
                  <input
                    type="number"
                    min="0"
                    placeholder="HC UN"
                    title="HC Routing UN"
                    value={routingHCUN}
                    onChange={(e) => setRoutingHCUN(e.target.value)}
                    className="w-full bg-indigo-50/70 border border-indigo-300 rounded-lg px-1.5 py-1.5 text-xs font-bold text-center text-indigo-950 focus:outline-none focus:ring-2 focus:ring-indigo-500"
                  />
                </div>
              </div>
            </div>
          </div>

          {/* Hàng 4: Kết quả (Hiện Diện, Thiếu/Đủ, Attendance) */}
          <div className="grid grid-cols-3 gap-2 pt-1">
            <div>
              <label className="block text-[11px] font-semibold text-slate-500 mb-1 truncate">
                Hiện Diện (Tổng - Vắng)
              </label>
              <input
                type="text"
                readOnly
                value={presentHC}
                className="w-full bg-emerald-50 border border-emerald-300 rounded-lg px-1.5 py-1.5 text-xs font-black text-center text-emerald-800"
              />
            </div>
            <div>
              <label
                className="block text-[11px] font-semibold text-slate-500 mb-1 truncate"
                title="So sánh Hiện Diện với Tổng HC Routing (HC CS + HC UN)"
              >
                Thiếu/Đủ (vs Routing: {totalRoutingHC})
              </label>
              <input
                type="text"
                readOnly
                value={diffText}
                className={`w-full border rounded-lg px-1.5 py-1.5 text-xs font-black text-center ${diffClass}`}
              />
            </div>
            <div>
              <label className="block text-[11px] font-semibold text-slate-500 mb-1 truncate">Attendance (%)</label>
              <input
                type="text"
                readOnly
                value={`${attRate}%`}
                className="w-full bg-white border border-slate-300 rounded-lg px-2 py-1.5 text-sm font-bold text-center text-slate-800"
              />
            </div>
          </div>
        </div>

        {/* TEMPLATE 2: BÁO CÁO HIỆU SUẤT (EFF & SẢN LƯỢNG) */}
        <div
          className={`p-4 rounded-xl border space-y-4 transition-colors ${
            reportStage === 'EOS'
              ? 'bg-gradient-to-br from-emerald-50/40 via-slate-50 to-teal-50/40 border-emerald-200'
              : 'bg-slate-50 border-slate-200/80'
          }`}
        >
          <div className="flex justify-between items-center">
            <h3 className="text-xs font-bold text-sky-900 uppercase tracking-wider flex items-center gap-1.5">
              <TrendingUp className="w-4 h-4 text-sky-600" />
              {reportStage === 'EOS'
                ? 'Báo Cáo Thực Tế Cuối Ca (EOS - Actual)'
                : 'Báo Cáo Hiệu Suất Đầu Ca (BOS - Estimate)'}
            </h3>
            <div className="flex items-center gap-2">
              <span
                className={`text-[11px] font-black px-2 py-0.5 rounded-md border ${
                  reportStage === 'EOS'
                    ? 'bg-emerald-100 text-emerald-800 border-emerald-300'
                    : 'bg-sky-100 text-sky-800 border-sky-300'
                }`}
              >
                {reportStage === 'EOS' ? 'Cuối Ca (EOS)' : 'Đầu Ca (BOS)'}
              </span>
              <span
                className={`text-[11px] font-bold px-2.5 py-0.5 rounded-full border ${
                  effRate >= 105
                    ? 'bg-emerald-100 text-emerald-800 border-emerald-300'
                    : 'bg-amber-100 text-amber-800 border-amber-300'
                }`}
              >
                EFF: {effRate}%
              </span>
            </div>
          </div>

          {/* Model chung của chuyền */}
          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">
              Model <span className="text-rose-500">*</span>
            </label>
            <input
              type="text"
              required
              placeholder="Vd: A465 / B218"
              value={model}
              onChange={(e) => setModel(e.target.value)}
              className="w-full bg-white border border-slate-300 rounded-lg px-3 py-1.5 text-sm font-semibold focus:outline-none focus:ring-2 focus:ring-sky-500"
            />
          </div>

          {/* KHỐI 1: JOB CS & 2 Ô SỐ LƯỢNG (KẾ HOẠCH & ACTUAL/ESTIMATE) */}
          <div className="bg-gradient-to-br from-sky-50 to-blue-50/60 p-3.5 rounded-xl border border-sky-200 space-y-2.5 shadow-2xs">
            <div className="flex items-center gap-1.5">
              <span className="w-2 h-2 rounded-full bg-sky-500"></span>
              <span className="text-xs font-bold text-sky-950 uppercase tracking-wide">
                1. Job CS
              </span>
            </div>

            {/* Hàng 1: Mã Job CS & QC Line */}
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5">
              <div className="sm:col-span-2">
                <label className="block text-xs font-semibold text-slate-700 mb-1">Mã Job CS</label>
                <input
                  type="text"
                  placeholder="Vd: MP103465020-A2642CS-PC32"
                  value={jobCS}
                  onChange={(e) => setJobCS(e.target.value)}
                  className="w-full bg-white border border-sky-300 rounded-lg px-3 py-1.5 text-xs font-mono text-slate-800 focus:outline-none focus:ring-2 focus:ring-sky-500"
                />
              </div>
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1" title="Số lượng nhân sự QC Line (Người)">
                  QC Line
                </label>
                <input
                  type="number"
                  min="0"
                  step="any"
                  placeholder="Vd: 1"
                  value={qcLineCS}
                  onChange={(e) => setQcLineCS(e.target.value)}
                  className="w-full bg-white border border-sky-300 rounded-lg px-2.5 py-1.5 text-sm font-bold text-center text-slate-800 focus:outline-none focus:ring-2 focus:ring-sky-500"
                />
              </div>
            </div>

            {/* 2 ô số lượng Kế Hoạch & (Estimate / Actual) của Job CS */}
            <div className="grid grid-cols-2 gap-x-2.5 gap-y-1 pt-1">
              <label className="text-[11px] font-semibold text-sky-900 flex items-end leading-tight min-h-[28px] sm:min-h-0">
                <span>Kế Hoạch (Plan) CS</span>
                <span className="text-rose-500 ml-0.5">*</span>
              </label>
              <label className="text-[11px] font-semibold text-sky-900 flex items-end justify-between leading-tight min-h-[28px] sm:min-h-0">
                <span className="leading-tight">
                  {reportStage === 'EOS' ? 'Actual (Thực Tế) CS' : 'Estimate (Dự Kiến) CS'}
                  <span className="text-rose-500 ml-0.5">*</span>
                </span>
                {reportStage === 'EOS' && (
                  <span className="text-[9px] bg-emerald-100 text-emerald-800 font-bold px-1.5 py-0.2 rounded shrink-0 ml-1">
                    Cuối ca
                  </span>
                )}
              </label>
              <div>
                <input
                  type="number"
                  min="0"
                  placeholder="Vd: 268"
                  value={planOutputCS}
                  onChange={(e) => setPlanOutputCS(e.target.value)}
                  className="w-full h-10 bg-white border border-sky-300 rounded-lg px-2.5 py-1.5 text-sm font-bold text-slate-800 focus:outline-none focus:ring-2 focus:ring-sky-500 box-border"
                />
              </div>
              <div>
                <input
                  type="number"
                  min="0"
                  placeholder={reportStage === 'EOS' ? 'Vd: 285 (Thực tế)' : 'Vd: 285'}
                  value={estimateOutputCS}
                  onChange={(e) => setEstimateOutputCS(e.target.value)}
                  className={`w-full h-10 rounded-lg px-2.5 py-1.5 text-sm font-black focus:outline-none focus:ring-2 box-border ${
                    reportStage === 'EOS'
                      ? 'bg-emerald-50 border-2 border-emerald-500 text-emerald-950 focus:ring-emerald-500'
                      : 'bg-sky-100/70 border border-sky-400 text-sky-950 focus:ring-sky-500'
                  }`}
                />
              </div>
            </div>
          </div>

          {/* KHỐI 2: JOB UN & 2 Ô SỐ LƯỢNG (KẾ HOẠCH & ACTUAL/ESTIMATE) */}
          <div className="bg-gradient-to-br from-indigo-50 to-violet-50/60 p-3.5 rounded-xl border border-indigo-200 space-y-2.5 shadow-2xs">
            <div className="flex items-center gap-1.5">
              <span className="w-2 h-2 rounded-full bg-indigo-500"></span>
              <span className="text-xs font-bold text-indigo-950 uppercase tracking-wide">
                2. Job UN
              </span>
            </div>

            {/* Hàng 1: Mã Job UN & QC Line */}
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5">
              <div className="sm:col-span-2">
                <label className="block text-xs font-semibold text-slate-700 mb-1">Mã Job UN</label>
                <input
                  type="text"
                  placeholder="Vd: MP103465020-A2642UN-PC32"
                  value={jobUN}
                  onChange={(e) => setJobUN(e.target.value)}
                  className="w-full bg-white border border-indigo-300 rounded-lg px-3 py-1.5 text-xs font-mono text-slate-800 focus:outline-none focus:ring-2 focus:ring-indigo-500"
                />
              </div>
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1" title="Số lượng nhân sự QC Line (Người)">
                  QC Line
                </label>
                <input
                  type="number"
                  min="0"
                  step="any"
                  placeholder="Vd: 1"
                  value={qcLineUN}
                  onChange={(e) => setQcLineUN(e.target.value)}
                  className="w-full bg-white border border-indigo-300 rounded-lg px-2.5 py-1.5 text-sm font-bold text-center text-slate-800 focus:outline-none focus:ring-2 focus:ring-indigo-500"
                />
              </div>
            </div>

            {/* 2 ô số lượng Kế Hoạch & (Estimate / Actual) của Job UN */}
            <div className="grid grid-cols-2 gap-x-2.5 gap-y-1 pt-1">
              <label className="text-[11px] font-semibold text-indigo-900 flex items-end leading-tight min-h-[28px] sm:min-h-0">
                <span>Kế Hoạch (Plan) UN</span>
                <span className="text-rose-500 ml-0.5">*</span>
              </label>
              <label className="text-[11px] font-semibold text-indigo-900 flex items-end justify-between leading-tight min-h-[28px] sm:min-h-0">
                <span className="leading-tight">
                  {reportStage === 'EOS' ? 'Actual (Thực Tế) UN' : 'Estimate (Dự Kiến) UN'}
                  <span className="text-rose-500 ml-0.5">*</span>
                </span>
                {reportStage === 'EOS' && (
                  <span className="text-[9px] bg-emerald-100 text-emerald-800 font-bold px-1.5 py-0.2 rounded shrink-0 ml-1">
                    Cuối ca
                  </span>
                )}
              </label>
              <div>
                <input
                  type="number"
                  min="0"
                  placeholder="Vd: 269"
                  value={planOutputUN}
                  onChange={(e) => setPlanOutputUN(e.target.value)}
                  className="w-full h-10 bg-white border border-indigo-300 rounded-lg px-2.5 py-1.5 text-sm font-bold text-slate-800 focus:outline-none focus:ring-2 focus:ring-indigo-500 box-border"
                />
              </div>
              <div>
                <input
                  type="number"
                  min="0"
                  placeholder={reportStage === 'EOS' ? 'Vd: 285 (Thực tế)' : 'Vd: 285'}
                  value={estimateOutputUN}
                  onChange={(e) => setEstimateOutputUN(e.target.value)}
                  className={`w-full h-10 rounded-lg px-2.5 py-1.5 text-sm font-black focus:outline-none focus:ring-2 box-border ${
                    reportStage === 'EOS'
                      ? 'bg-emerald-50 border-2 border-emerald-500 text-emerald-950 focus:ring-emerald-500'
                      : 'bg-indigo-100/70 border border-indigo-400 text-indigo-950 focus:ring-indigo-500'
                  }`}
                />
              </div>
            </div>
          </div>

          {/* HÀNG TỔNG HỢP SẢN LƯỢNG TOÀN LINE (TỰ ĐỘNG TÍNH CS + UN) */}
          <div className="bg-slate-200/60 p-3 rounded-xl border border-slate-300/80 space-y-2">
            <div className="flex justify-between items-center text-[11px]">
              <span className="font-bold text-slate-700 flex items-center gap-1">
                <Box className="w-3.5 h-3.5 text-slate-600" /> Tổng Sản Lượng Ca (CS + UN):
              </span>
              <span className="font-extrabold text-slate-700">
                {reportStage === 'EOS' ? 'ATT Hoàn Thành:' : 'Estimate ATT:'}{' '}
                <span className="text-purple-700 font-black">{estimateAtt}%</span>
              </span>
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div className="bg-white rounded-lg p-2 border border-slate-300 flex items-center justify-between">
                <span className="text-[11px] text-slate-600 font-medium">Tổng Kế Hoạch:</span>
                <span className="text-sm font-black text-slate-900">{totalPlanOutput.toLocaleString()}</span>
              </div>
              <div
                className={`rounded-lg p-2 border flex items-center justify-between ${
                  reportStage === 'EOS'
                    ? 'bg-emerald-100/80 border-emerald-400 text-emerald-950'
                    : 'bg-sky-50 border-sky-300 text-sky-900'
                }`}
              >
                <span className="text-[11px] font-medium">
                  {reportStage === 'EOS' ? 'Tổng Thực Tế (Actual):' : 'Tổng Estimate:'}
                </span>
                <span className="text-sm font-black">{totalEstimateOutput.toLocaleString()}</span>
              </div>
            </div>
          </div>

          {/* Hàng tham số: UPH & Giờ làm việc */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                UPH <span className="text-rose-500">*</span>
              </label>
              <input
                type="number"
                min="0"
                required
                placeholder="Vd: 26"
                value={uph}
                onChange={(e) => setUph(e.target.value)}
                className="w-full bg-white border border-slate-300 rounded-lg px-3 py-1.5 text-sm font-bold text-center focus:outline-none focus:ring-2 focus:ring-sky-500"
              />
            </div>
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                Giờ Plan <span className="text-rose-500">*</span>
              </label>
              <input
                type="text"
                inputMode="decimal"
                required
                placeholder="Vd: 10 hoặc 10.75"
                value={planHours}
                onChange={(e) => setPlanHours(e.target.value.replace(/[^0-9.,]/g, ''))}
                className="w-full bg-white border border-slate-300 rounded-lg px-3 py-1.5 text-sm font-bold text-center focus:outline-none focus:ring-2 focus:ring-sky-500"
              />
            </div>
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                Giờ Thực Tế <span className="text-rose-500">*</span>
              </label>
              <input
                type="text"
                inputMode="decimal"
                required
                placeholder="Vd: 10 hoặc 10.75"
                value={actualHours}
                onChange={(e) => setActualHours(e.target.value.replace(/[^0-9.,]/g, ''))}
                className="w-full bg-white border border-slate-300 rounded-lg px-3 py-1.5 text-sm font-bold text-center focus:outline-none focus:ring-2 focus:ring-sky-500"
              />
            </div>
          </div>

          {/* Hàng kết quả tự động: STD Hour (Plan), Actual Line (Thực Tế), EFF excluding loss & EFF including loss */}
          <div className="bg-sky-50/60 p-3.5 rounded-xl border border-sky-200/80 space-y-2.5">
            <div className="flex items-center text-[11px]">
              <span className="font-bold text-sky-950 flex items-center gap-1">
                <Layers className="w-3.5 h-3.5 text-sky-600" /> Kết Quả Tính Toán Tự Động (KPI)
              </span>
            </div>
            <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-3">
              {/* Ô 1: Tổng STD Hour / Plan */}
              <div className="bg-white rounded-lg p-2.5 border border-sky-300/60 shadow-2xs">
                <div className="text-[10px] text-slate-500 font-semibold uppercase truncate" title="Plan = (HC plan * số lượng) / UPH">
                  Tổng STD Hour (Plan)
                </div>
                <div className="text-base font-black text-sky-900 mt-0.5">
                  {stdHourNum.toFixed(1)}h
                </div>
                <div className="text-[10px] text-slate-500 mt-1 flex justify-between font-mono">
                  <span>CS: {stdHourCSNum.toFixed(1)}h</span>
                  <span>UN: {stdHourUNNum.toFixed(1)}h</span>
                </div>
              </div>

              {/* Ô 2: Actual Line */}
              <div className="bg-white rounded-lg p-2.5 border border-sky-300/60 shadow-2xs">
                <div className="text-[10px] text-slate-500 font-semibold uppercase truncate" title="Thực tế (bữa giờ): HC routing * Giờ thực tế">
                  Actual Line (Routing * Giờ)
                </div>
                <div className="text-base font-black text-indigo-900 mt-0.5">
                  {actualLineNum.toFixed(1)}h
                </div>
                <div className="text-[10px] text-slate-500 mt-1 truncate">
                  HC: {actualHC} × Giờ: {actualHoursNum}h
                </div>
              </div>

              {/* Ô 3: EFF excluding loss */}
              <div className="bg-white rounded-lg p-2.5 border border-emerald-300/80 shadow-2xs">
                <div className="text-[10px] text-emerald-800 font-bold uppercase truncate" title="EFF excluding loss = Plan / (HC routing * Giờ thực tế)">
                  EFF excluding loss
                </div>
                <div className={`text-base font-black mt-0.5 ${effExcludingLoss >= 100 ? 'text-emerald-600' : 'text-amber-600'}`}>
                  {effExcludingLoss}%
                </div>
                <div className="text-[10px] text-slate-500 mt-1 truncate font-medium">
                  {actualHC} HC × {actualHoursNum}h
                </div>
              </div>

              {/* Ô 4: EFF including loss */}
              <div className="bg-white rounded-lg p-2.5 border border-blue-300/80 shadow-2xs">
                <div className="text-[10px] text-blue-800 font-bold uppercase truncate" title="EFF including loss = Plan / [(HC routing + QC line) * Giờ thực tế]">
                  EFF including loss
                </div>
                <div className={`text-base font-black mt-0.5 ${effIncludingLoss >= 100 ? 'text-blue-600' : 'text-amber-600'}`}>
                  {effIncludingLoss}%
                </div>
                <div className="text-[10px] text-slate-500 mt-1 truncate font-medium">
                  {totalQCLine > 0 ? `(${actualHC} HC + ${totalQCLine} QC) × ${actualHoursNum}h` : 'QC Line: 0 người'}
                </div>
              </div>

              {/* Ô 5: ATT */}
              <div className="bg-white rounded-lg p-2.5 border border-purple-300/80 shadow-2xs">
                <div className="text-[10px] text-purple-800 font-bold uppercase truncate" title="Tỷ lệ hoàn thành sản lượng: Output / Plan">
                  ATT
                </div>
                <div className={`text-base font-black mt-0.5 ${estimateAtt >= 100 ? 'text-purple-700' : 'text-amber-600'}`}>
                  {estimateAtt}%
                </div>
                <div className="text-[10px] text-slate-500 mt-1 truncate font-medium">
                  {totalEstimateOutput.toLocaleString()} / {totalPlanOutput.toLocaleString()} pcs
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Thông tin Leader & Ngày */}
        <div className="grid grid-cols-2 gap-3">
          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">
              Line Leader <span className="text-rose-500">*</span>
            </label>
            <input
              type="text"
              required
              placeholder="Nhập họ tên Line Leader (bắt buộc)..."
              value={leaderName}
              onChange={(e) => setLeaderName(e.target.value)}
              className="w-full bg-white border border-slate-300 rounded-lg px-3 py-1.5 text-xs font-bold text-slate-800 focus:outline-none focus:ring-2 focus:ring-sky-500"
            />
          </div>
          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">Ngày Sản Xuất</label>
            <input
              type="date"
              value={reportDate}
              onChange={(e) => setReportDate(e.target.value)}
              className="w-full bg-white border border-slate-300 rounded-lg px-3 py-1.5 text-xs font-bold focus:outline-none focus:ring-2 focus:ring-sky-500"
            />
          </div>
        </div>

        {/* Mở rộng: Remark fail ATT, Job Pending, Reason, Due date */}
        <div className="border border-slate-200 rounded-xl overflow-hidden bg-slate-50/50">
          <button
            type="button"
            onClick={() => setShowExtendedFields(!showExtendedFields)}
            className="w-full px-4 py-2.5 bg-slate-100 hover:bg-slate-200/80 text-slate-700 flex items-center justify-between text-xs font-bold transition-colors cursor-pointer"
          >
            <span className="flex items-center gap-1.5">
              <span>{showExtendedFields ? '▼' : '▶'}</span>
              <span>Thông tin bổ sung báo cáo tổng hợp (Remark ATT, Pending, Lý do, Hạn bù)</span>
            </span>
            <span className="text-[10px] text-slate-500 font-normal">
              {showExtendedFields ? 'Thu gọn' : 'Tùy chọn'}
            </span>
          </button>

          {showExtendedFields && (
            <div className="p-3.5 space-y-3 bg-white border-t border-slate-200 text-xs">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-[11px] font-semibold text-slate-700 mb-1">
                    Remark Fail ATT (Chuyên cần)
                  </label>
                  <input
                    type="text"
                    placeholder="Vd: Vắng 2 HC (AL:1, SL:1) - ATT 92.3%"
                    value={remarkFailAtt}
                    onChange={(e) => setRemarkFailAtt(e.target.value)}
                    className="w-full bg-slate-50 border border-slate-300 rounded-lg px-2.5 py-1.5 text-xs text-slate-800 focus:outline-none focus:ring-1 focus:ring-sky-500"
                  />
                </div>

                <div>
                  <label className="block text-[11px] font-semibold text-slate-700 mb-1">
                    Job Pending (Tồn đọng)
                  </label>
                  <input
                    type="text"
                    placeholder="Vd: MP103465020-A2642CS-PC32"
                    value={jobPending}
                    onChange={(e) => setJobPending(e.target.value)}
                    className="w-full bg-slate-50 border border-slate-300 rounded-lg px-2.5 py-1.5 text-xs text-slate-800 focus:outline-none focus:ring-1 focus:ring-sky-500"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-[11px] font-semibold text-slate-700 mb-1">
                    Reason (Lý do sự cố nếu hụt)
                  </label>
                  <input
                    type="text"
                    placeholder="Vd: Sự cố máy dán nhãn 45p / Thiếu linh kiện..."
                    value={reason}
                    onChange={(e) => setReason(e.target.value)}
                    className="w-full bg-slate-50 border border-slate-300 rounded-lg px-2.5 py-1.5 text-xs text-slate-800 focus:outline-none focus:ring-1 focus:ring-sky-500"
                  />
                </div>

                <div>
                  <label className="block text-[11px] font-semibold text-slate-700 mb-1">
                    Due Date (Hạn hoàn thành / bù)
                  </label>
                  <input
                    type="text"
                    placeholder="Vd: Trong 24h / Bù ca sau 18:00 / Đúng tiến độ..."
                    value={dueDate}
                    onChange={(e) => setDueDate(e.target.value)}
                    className="w-full bg-slate-50 border border-slate-300 rounded-lg px-2.5 py-1.5 text-xs text-slate-800 focus:outline-none focus:ring-1 focus:ring-sky-500"
                  />
                </div>
              </div>
            </div>
          )}
        </div>

        <div>
          <label className="block text-xs font-medium text-slate-700 mb-1">
            Ghi Chú Chi Tiết (Sự Cố/Downtime Nếu Có)
          </label>
          <textarea
            rows={2}
            placeholder={
              reportStage === 'EOS'
                ? 'Nhập ghi chú tổng kết cuối ca, sự cố máy móc, nguyên vật liệu hoặc lý do hoàn thành...'
                : 'Nhập ghi chú đầu ca: kế hoạch chạy, máy móc, nguyên vật liệu dự tính...'
            }
            value={note}
            onChange={(e) => setNote(e.target.value)}
            className="w-full bg-white border border-slate-300 rounded-lg p-2.5 text-xs focus:outline-none focus:ring-2 focus:ring-sky-500"
          />
        </div>

        {/* Action Buttons */}
        <div className="flex items-center justify-end space-x-3 pt-2">
          <button
            type="button"
            onClick={handleReset}
            className="px-4 py-2.5 border border-slate-300 text-slate-600 rounded-xl text-xs font-semibold hover:bg-slate-100 transition-all flex items-center gap-1.5 cursor-pointer"
          >
            <RotateCcw className="w-3.5 h-3.5" /> Làm Sạch Form
          </button>
          <button
            type="submit"
            className={`px-5 py-2.5 text-white rounded-xl text-xs font-bold shadow-md flex items-center gap-2 transition-all cursor-pointer ${
              reportStage === 'EOS'
                ? 'bg-gradient-to-r from-emerald-600 to-teal-700 hover:from-emerald-500 hover:to-teal-600 shadow-emerald-600/30 ring-2 ring-emerald-400/40'
                : 'bg-gradient-to-r from-sky-600 to-blue-700 hover:from-sky-500 hover:to-blue-600 shadow-sky-600/30 ring-2 ring-sky-400/40'
            }`}
          >
            <Save className="w-4 h-4" />
            {reportStage === 'EOS'
              ? 'Lưu Báo Cáo EOS (Cuối Ca - Actual)'
              : 'Lưu Báo Cáo BOS (Đầu Ca - Estimate)'}
          </button>
        </div>
      </form>
    </section>
  );
};
