import React, { useState } from 'react';
import { KeyRound, AlertCircle, Check } from 'lucide-react';
import { verifyAdminPin, saveAdminPin, getAdminPin } from '../utils/storage';

interface ChangePinModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSuccess: (msg: string) => void;
}

export const ChangePinModal: React.FC<ChangePinModalProps> = ({
  isOpen,
  onClose,
  onSuccess
}) => {
  const [oldPin, setOldPin] = useState('');
  const [newPin, setNewPin] = useState('');
  const [confirmPin, setConfirmPin] = useState('');
  const [error, setError] = useState<string | null>(null);

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!verifyAdminPin(oldPin)) {
      setError('Mã PIN hiện tại không chính xác!');
      return;
    }
    if (newPin.trim().length < 6 || newPin.trim().length > 64) {
      setError('Mã PIN mới phải từ 6 đến 64 ký tự!');
      return;
    }
    if (newPin !== confirmPin) {
      setError('Mã PIN xác nhận không trùng khớp!');
      return;
    }

    const saved = saveAdminPin(newPin.trim());
    if (saved) {
      setOldPin('');
      setNewPin('');
      setConfirmPin('');
      setError(null);
      onSuccess('Đã đổi mã PIN Admin thành công!');
      onClose();
    } else {
      setError('Lưu mã PIN thất bại. Vui lòng thử lại.');
    }
  };

  return (
    <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-sm z-50 flex items-center justify-center p-4">
      <div className="bg-white rounded-2xl shadow-2xl max-w-sm w-full overflow-hidden p-6 space-y-4 animate-in fade-in zoom-in-95 duration-150">
        <div className="text-center space-y-1">
          <div className="w-12 h-12 bg-sky-100 text-sky-600 rounded-full flex items-center justify-center mx-auto text-xl">
            <KeyRound className="w-6 h-6" />
          </div>
          <h3 className="font-bold text-slate-800 text-base">Cài Đặt Mã PIN Admin</h3>
          <p className="text-xs text-slate-500">
            Mã PIN bảo mật dùng để duyệt các thao tác xóa và cấu hình hệ thống.
          </p>
        </div>

        <form onSubmit={handleSubmit} className="space-y-3 text-left">
          {error && (
            <div className="bg-rose-50 text-rose-700 p-2.5 rounded-xl border border-rose-200 text-xs font-medium flex items-center gap-1.5">
              <AlertCircle className="w-4 h-4 shrink-0 text-rose-600" />
              <span>{error}</span>
            </div>
          )}

          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">
              Mã PIN Hiện Tại (Mặc định: 123456)
            </label>
            <input
              type="password"
              required
              placeholder="Nhập PIN cũ"
              value={oldPin}
              onChange={(e) => {
                setOldPin(e.target.value);
                if (error) setError(null);
              }}
              className="w-full text-center font-bold border border-slate-300 rounded-xl px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-sky-500"
            />
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">
              Mã PIN Mới (6 - 64 ký tự)
            </label>
            <input
              type="password"
              required
              placeholder="Nhập PIN mới"
              value={newPin}
              onChange={(e) => {
                setNewPin(e.target.value);
                if (error) setError(null);
              }}
              className="w-full text-center font-bold border border-slate-300 rounded-xl px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-sky-500"
            />
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">
              Nhập Lại Mã PIN Mới
            </label>
            <input
              type="password"
              required
              placeholder="Xác nhận lại PIN mới"
              value={confirmPin}
              onChange={(e) => {
                setConfirmPin(e.target.value);
                if (error) setError(null);
              }}
              className="w-full text-center font-bold border border-slate-300 rounded-xl px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-sky-500"
            />
          </div>

          <div className="flex gap-2 pt-2">
            <button
              type="button"
              onClick={() => {
                setOldPin('');
                setNewPin('');
                setConfirmPin('');
                setError(null);
                onClose();
              }}
              className="flex-1 py-2.5 bg-slate-100 hover:bg-slate-200 text-slate-700 font-semibold text-xs rounded-xl transition-all"
            >
              Hủy
            </button>
            <button
              type="submit"
              className="flex-1 py-2.5 bg-sky-600 hover:bg-sky-700 text-white font-bold text-xs rounded-xl shadow-md transition-all flex items-center justify-center gap-1.5"
            >
              <Check className="w-4 h-4" /> Lưu PIN Mới
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
