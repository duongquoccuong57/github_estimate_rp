import React from 'react';
import { Gauge, Users, PackageCheck, Layers } from 'lucide-react';
import { ShiftReport } from '../types/report';
import { parseNumber } from '../utils/calculations';

interface KpiCardsProps {
  reports: ShiftReport[];
}

export const KpiCards: React.FC<KpiCardsProps> = ({ reports }) => {
  if (reports.length === 0) {
    return (
      <section className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="bg-white p-4 rounded-2xl shadow-sm border border-slate-200 flex items-center justify-between">
          <div>
            <p className="text-xs font-semibold text-slate-500 uppercase tracking-wide">EFF TRUNG BÌNH</p>
            <h3 className="text-2xl font-black text-slate-800 mt-1">0%</h3>
            <p className="text-xs text-slate-400 mt-0.5">Chưa có dữ liệu</p>
          </div>
          <div className="w-11 h-11 rounded-xl bg-sky-50 text-sky-600 flex items-center justify-center text-xl font-bold">
            <Gauge className="w-6 h-6" />
          </div>
        </div>

        <div className="bg-white p-4 rounded-2xl shadow-sm border border-slate-200 flex items-center justify-between">
          <div>
            <p className="text-xs font-semibold text-slate-500 uppercase tracking-wide">ATTENDANCE TRUNG BÌNH</p>
            <h3 className="text-2xl font-black text-slate-800 mt-1">0%</h3>
            <p className="text-xs text-slate-400 mt-0.5">Chuyên cần ca</p>
          </div>
          <div className="w-11 h-11 rounded-xl bg-emerald-50 text-emerald-600 flex items-center justify-center text-xl font-bold">
            <Users className="w-6 h-6" />
          </div>
        </div>

        <div className="bg-white p-4 rounded-2xl shadow-sm border border-slate-200 flex items-center justify-between">
          <div>
            <p className="text-xs font-semibold text-slate-500 uppercase tracking-wide">SẢN LƯỢNG (ESTIMATE)</p>
            <h3 className="text-2xl font-black text-slate-800 mt-1">0</h3>
            <p className="text-xs text-slate-400 mt-0.5">Kế hoạch: 0</p>
          </div>
          <div className="w-11 h-11 rounded-xl bg-purple-50 text-purple-600 flex items-center justify-center text-xl font-bold">
            <PackageCheck className="w-6 h-6" />
          </div>
        </div>

        <div className="bg-white p-4 rounded-2xl shadow-sm border border-slate-200 flex items-center justify-between">
          <div className="w-full overflow-hidden">
            <p className="text-xs font-semibold text-slate-500 uppercase tracking-wide">THÔNG TIN LINE & MODEL</p>
            <div className="mt-1 text-xs font-bold text-slate-400">Chưa có dữ liệu</div>
          </div>
          <div className="w-11 h-11 rounded-xl bg-slate-100 text-slate-600 flex items-center justify-center text-xl font-bold shrink-0 ml-2">
            <Layers className="w-6 h-6" />
          </div>
        </div>
      </section>
    );
  }

  let totalStd = 0;
  let totalAct = 0;
  let sumAtt = 0;
  let sumEst = 0;
  let sumPlan = 0;

  const lineModelMap: Record<string, Set<string>> = {};

  reports.forEach((r) => {
    const stdNum = parseNumber(r.stdHour.replace('h', ''));
    const actNum = parseNumber(r.actualLine.replace('h', ''));
    totalStd += stdNum;
    totalAct += actNum;
    sumAtt += Number(r.attRate) || 0;
    sumEst += Number(r.estimateOutput) || 0;
    sumPlan += Number(r.planOutput) || 0;

    if (!lineModelMap[r.line]) {
      lineModelMap[r.line] = new Set();
    }
    if (r.model) {
      lineModelMap[r.line].add(r.model);
    }
  });

  const overallEff = totalAct > 0 ? Math.round((totalStd / totalAct) * 1000) / 10 : 0;
  const avgAtt = Math.round((sumAtt / reports.length) * 10) / 10;
  const isEffTargetMet = overallEff >= 105;

  return (
    <section className="grid grid-cols-2 lg:grid-cols-4 gap-4">
      {/* EFF Trung Bình */}
      <div className="bg-white p-4 rounded-2xl shadow-sm border border-slate-200 flex items-center justify-between transition-all hover:shadow-md">
        <div>
          <p className="text-xs font-semibold text-slate-500 uppercase tracking-wide">EFF TRUNG BÌNH</p>
          <h3 className="text-2xl font-black text-slate-800 mt-1">{overallEff}%</h3>
          <p
            className={`text-xs font-bold mt-0.5 inline-flex items-center gap-1 ${
              isEffTargetMet ? 'text-emerald-600' : 'text-amber-600'
            }`}
          >
            <span className={`w-2 h-2 rounded-full ${isEffTargetMet ? 'bg-emerald-500' : 'bg-amber-500'}`} />
            {isEffTargetMet ? 'Đạt Chỉ Tiêu (≥105%)' : 'Dưới Chỉ Tiêu (<105%)'}
          </p>
        </div>
        <div className={`w-11 h-11 rounded-xl flex items-center justify-center text-xl font-bold ${
          isEffTargetMet ? 'bg-emerald-50 text-emerald-600' : 'bg-sky-50 text-sky-600'
        }`}>
          <Gauge className="w-6 h-6" />
        </div>
      </div>

      {/* ATT Trung Bình */}
      <div className="bg-white p-4 rounded-2xl shadow-sm border border-slate-200 flex items-center justify-between transition-all hover:shadow-md">
        <div>
          <p className="text-xs font-semibold text-slate-500 uppercase tracking-wide">ATTENDANCE TRUNG BÌNH</p>
          <h3 className="text-2xl font-black text-slate-800 mt-1">{avgAtt}%</h3>
          <p className="text-xs text-slate-500 mt-0.5">
            {avgAtt >= 95 ? 'Chuyên cần tốt (≥95%)' : 'Chuyên cần cần lưu ý'}
          </p>
        </div>
        <div className="w-11 h-11 rounded-xl bg-emerald-50 text-emerald-600 flex items-center justify-center text-xl font-bold">
          <Users className="w-6 h-6" />
        </div>
      </div>

      {/* Sản Lượng Estimate */}
      <div className="bg-white p-4 rounded-2xl shadow-sm border border-slate-200 flex items-center justify-between transition-all hover:shadow-md">
        <div>
          <p className="text-xs font-semibold text-slate-500 uppercase tracking-wide">SẢN LƯỢNG (ESTIMATE)</p>
          <h3 className="text-2xl font-black text-slate-800 mt-1">{sumEst.toLocaleString()}</h3>
          <p className="text-xs text-slate-500 mt-0.5">
            Kế hoạch: <span className="font-semibold text-slate-700">{sumPlan.toLocaleString()}</span>
          </p>
        </div>
        <div className="w-11 h-11 rounded-xl bg-purple-50 text-purple-600 flex items-center justify-center text-xl font-bold">
          <PackageCheck className="w-6 h-6" />
        </div>
      </div>

      {/* Line & Model */}
      <div className="bg-white p-4 rounded-2xl shadow-sm border border-slate-200 flex items-center justify-between transition-all hover:shadow-md">
        <div className="w-full overflow-hidden">
          <p className="text-xs font-semibold text-slate-500 uppercase tracking-wide">THÔNG TIN LINE & MODEL</p>
          <div className="mt-1 space-y-0.5 max-h-[60px] overflow-y-auto pr-1">
            {Object.entries(lineModelMap).map(([lineName, modelSet]) => {
              const models = Array.from(modelSet).join(', ');
              return (
                <div key={lineName} className="text-xs font-bold text-slate-700 truncate" title={`Line ${lineName}: ${models}`}>
                  Line {lineName}: <span className="text-sky-600 font-medium">{models || 'Chưa có'}</span>
                </div>
              );
            })}
          </div>
        </div>
        <div className="w-11 h-11 rounded-xl bg-slate-100 text-slate-700 flex items-center justify-center text-xl font-bold shrink-0 ml-2">
          <Layers className="w-6 h-6" />
        </div>
      </div>
    </section>
  );
};
