import React, { useState } from 'react';
import { Lock, X, AlertCircle } from 'lucide-react';
import { verifyAdminPin, getAdminPin } from '../utils/storage';

interface PinModalProps {
  isOpen: boolean;
  title?: string;
  description?: string;
  onClose: () => void;
  onSuccess: () => void;
}

export const PinModal: React.FC<PinModalProps> = ({
  isOpen,
  title = 'Xác Nhận Quyền Admin',
  description = 'Vui lòng nhập mã PIN quản trị để thực hiện thao tác xóa dữ liệu.',
  onClose,
  onSuccess
}) => {
  const [pin, setPin] = useState('');
  const [error, setError] = useState(false);

  if (!isOpen) return null;

  const currentPin = getAdminPin();
  const isDefault = currentPin === '123456';

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (verifyAdminPin(pin)) {
      setError(false);
      setPin('');
      onSuccess();
      onClose();
    } else {
      setError(true);
    }
  };

  return (
    <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-sm z-50 flex items-center justify-center p-4">
      <div className="bg-white rounded-2xl shadow-2xl max-w-sm w-full overflow-hidden p-6 space-y-4 animate-in fade-in zoom-in-95 duration-150">
        <div className="text-center space-y-1">
          <div className="w-12 h-12 bg-rose-100 text-rose-600 rounded-full flex items-center justify-center mx-auto text-xl">
            <Lock className="w-6 h-6" />
          </div>
          <h3 className="font-bold text-slate-800 text-base">{title}</h3>
          <p className="text-xs text-slate-500">{description}</p>
          {isDefault && (
            <p className="text-[11px] bg-amber-50 text-amber-800 border border-amber-200/80 rounded-lg px-2 py-1 inline-block mt-1 font-medium">
              💡 Mã PIN mặc định: <span className="font-bold font-mono">123456</span>
            </p>
          )}
        </div>

        <form onSubmit={handleSubmit} className="space-y-3">
          <div>
            <input
              type="password"
              autoFocus
              placeholder="Nhập mã PIN"
              value={pin}
              onChange={(e) => {
                setPin(e.target.value);
                if (error) setError(false);
              }}
              maxLength={64}
              className="w-full text-center tracking-widest text-lg font-bold border border-slate-300 rounded-xl px-3 py-2 focus:outline-none focus:ring-2 focus:ring-sky-500"
            />
            {error && (
              <p className="text-xs text-rose-600 text-center mt-1.5 font-semibold flex items-center justify-center gap-1">
                <AlertCircle className="w-3.5 h-3.5" /> Mã PIN không chính xác!
              </p>
            )}
          </div>

          <div className="flex gap-2 pt-2">
            <button
              type="button"
              onClick={() => {
                setPin('');
                setError(false);
                onClose();
              }}
              className="flex-1 py-2.5 bg-slate-100 hover:bg-slate-200 text-slate-700 font-semibold text-xs rounded-xl transition-all"
            >
              Hủy Bỏ
            </button>
            <button
              type="submit"
              className="flex-1 py-2.5 bg-rose-600 hover:bg-rose-700 text-white font-bold text-xs rounded-xl shadow-md transition-all"
            >
              Xác Nhận
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
