import React, { useState } from 'react';
import { MessageSquare, X, Copy, Check } from 'lucide-react';
import { ShiftReport } from '../types/report';
import { formatZaloMessage } from '../utils/calculations';

interface ZaloModalProps {
  report: ShiftReport | null;
  onClose: () => void;
  onCopied: (msg: string) => void;
}

export const ZaloModal: React.FC<ZaloModalProps> = ({
  report,
  onClose,
  onCopied
}) => {
  const [copied, setCopied] = useState(false);

  if (!report) return null;

  const text = formatZaloMessage(report);

  const handleCopy = async () => {
    try {
      if (navigator.clipboard && navigator.clipboard.writeText) {
        await navigator.clipboard.writeText(text);
      } else {
        const textArea = document.createElement('textarea');
        textArea.value = text;
        textArea.style.position = 'fixed';
        textArea.style.left = '-999999px';
        textArea.style.top = '-999999px';
        document.body.appendChild(textArea);
        textArea.focus();
        textArea.select();
        document.execCommand('copy');
        textArea.remove();
      }
      setCopied(true);
      onCopied('Đã sao chép tin nhắn Zalo/Teams thành công!');
      setTimeout(() => {
        setCopied(false);
        onClose();
      }, 1200);
    } catch (err) {
      console.error('Failed to copy', err);
    }
  };

  return (
    <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-sm z-50 flex items-center justify-center p-4">
      <div className="bg-white rounded-2xl shadow-2xl max-w-lg w-full overflow-hidden flex flex-col max-h-[90vh] animate-in fade-in zoom-in-95 duration-150">
        <div className="bg-slate-900 text-white px-5 py-4 flex justify-between items-center">
          <h3 className="font-bold text-sm flex items-center gap-2">
            <MessageSquare className="w-4 h-4 text-sky-400" />
            Định Dạng Tin Nhắn Zalo / Teams
          </h3>
          <button
            type="button"
            onClick={onClose}
            className="text-slate-400 hover:text-white p-1 rounded-lg transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="p-5 overflow-y-auto space-y-2">
          <p className="text-xs text-slate-500">
            Nội dung dưới đây đã được định dạng chuẩn với biểu tượng và số liệu rõ ràng để gửi trực tiếp vào nhóm trao đổi Zalo/Teams:
          </p>
          <textarea
            readOnly
            value={text}
            onClick={(e) => (e.target as HTMLTextAreaElement).select()}
            className="w-full h-72 bg-slate-50 border border-slate-300 rounded-xl p-3 font-mono text-xs text-slate-800 focus:outline-none focus:ring-2 focus:ring-sky-500 select-all leading-relaxed"
          />
        </div>

        <div className="bg-slate-100 px-5 py-3.5 flex justify-end gap-3 border-t border-slate-200">
          <button
            type="button"
            onClick={onClose}
            className="px-4 py-2 border border-slate-300 rounded-xl text-xs font-semibold text-slate-700 hover:bg-slate-200 transition-colors"
          >
            Đóng
          </button>
          <button
            type="button"
            onClick={handleCopy}
            className={`px-5 py-2 text-white rounded-xl text-xs font-bold flex items-center gap-2 shadow-md transition-all ${
              copied
                ? 'bg-emerald-600 hover:bg-emerald-700'
                : 'bg-sky-600 hover:bg-sky-700'
            }`}
          >
            {copied ? (
              <>
                <Check className="w-4 h-4" /> Đã Sao Chép!
              </>
            ) : (
              <>
                <Copy className="w-4 h-4" /> Sao Chép Tin Nhắn
              </>
            )}
          </button>
        </div>
      </div>
    </div>
  );
};
