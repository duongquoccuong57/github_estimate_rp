import React, { useState, useMemo } from 'react';
import {
  FileSpreadsheet,
  ClipboardCopy,
  Copy,
  Printer,
  Calendar,
  CheckCircle2,
  AlertTriangle,
  Settings2,
  Plus,
  Save,
  Sparkles,
  Edit3,
  X,
  RotateCcw
} from 'lucide-react';
import { ShiftReport, DailyLineSummary } from '../types/report';
import {
  generateDailyLineSummaries,
  exportDailySummaryToExcel,
  formatDailySummaryTSV,
  formatDailySummaryMessage,
  parseNumber
} from '../utils/calculations';
import {
  getStoredFactoryLines,
  saveStoredFactoryLines,
  DEFAULT_FACTORY_LINES
} from '../utils/storage';

interface MainReportViewProps {
  reports: ShiftReport[];
  selectedDate: string;
  onDateChange: (date: string) => void;
  onSaveReport: (report: ShiftReport) => void;
  onShowToast: (message: string, isError?: boolean) => void;
  onOpenCalculationForm?: (line: string, stage: 'BOS' | 'EOS') => void;
}

export const MainReportView: React.FC<MainReportViewProps> = ({
  reports,
  selectedDate,
  onDateChange,
  onSaveReport,
  onShowToast,
  onOpenCalculationForm
}) => {
  // Chọn ca: CHỈ CA NGÀY (D) HOẶC CA ĐÊM (N), không lấy cả 2 ca
  const [shiftFilter, setShiftFilter] = useState<'day' | 'night'>(() => {
    const hour = new Date().getHours();
    return hour >= 20 || hour < 8 ? 'night' : 'day';
  });

  // 2 Tab riêng biệt: BOS (Đầu Ca - Estimate) và EOS (Cuối Ca - Actual)
  const [stageTab, setStageTab] = useState<'BOS' | 'EOS'>('BOS');

  // Quản lý giá trị nhập trực tiếp Actual trong tab EOS cho từng dòng (key: `${line}-${jobType}`)
  const [eosActualInputs, setEosActualInputs] = useState<Record<string, string>>({});

  // Cấu hình danh sách 6 chuyền (1323 - 1328)
  const [factoryLines, setFactoryLines] = useState<string[]>(() => getStoredFactoryLines());
  const [showLineSettings, setShowLineSettings] = useState<boolean>(false);
  const [newLineInput, setNewLineInput] = useState<string>('');

  const [copiedMsg, setCopiedMsg] = useState<boolean>(false);
  const [copiedTsv, setCopiedTsv] = useState<boolean>(false);

  // Modal chỉnh sửa / tạo mới kế hoạch BOS nhanh cho 1 line
  const [editingBosLine, setEditingBosLine] = useState<string | null>(null);
  const [bosFormModel, setBosFormModel] = useState('');
  const [bosFormJobCS, setBosFormJobCS] = useState('');
  const [bosFormPlanCS, setBosFormPlanCS] = useState('');
  const [bosFormEstCS, setBosFormEstCS] = useState('');
  const [bosFormJobUN, setBosFormJobUN] = useState('');
  const [bosFormPlanUN, setBosFormPlanUN] = useState('');
  const [bosFormEstUN, setBosFormEstUN] = useState('');
  const [bosFormRemarkAtt, setBosFormRemarkAtt] = useState('Đạt ATT');
  const [bosFormReason, setBosFormReason] = useState('Vận hành ổn định');
  const [bosFormDueDate, setBosFormDueDate] = useState('Đúng tiến độ');

  // Tính toán dữ liệu tổng hợp theo ngày, ca và tab (BOS / EOS)
  // Trong tab EOS: Tự động fill toàn bộ thông tin đầu ca từ BOS, chừa Actual để nhập
  const rawSummaries: DailyLineSummary[] = useMemo(() => {
    return generateDailyLineSummaries(reports, selectedDate, shiftFilter, factoryLines, stageTab);
  }, [reports, selectedDate, shiftFilter, factoryLines, stageTab]);

  // Cập nhật số liệu động nếu người dùng đang gõ Actual trên tab EOS
  const summaries: DailyLineSummary[] = useMemo(() => {
    if (stageTab !== 'EOS') return rawSummaries;

    return rawSummaries.map((s) => {
      if (!s.hasPlan) return s;
      const key = `${s.line}-${s.jobType || 'ALL'}`;
      if (eosActualInputs[key] !== undefined) {
        const customActual = parseNumber(eosActualInputs[key]);
        const customGap = customActual - s.planOutput;
        return {
          ...s,
          estimateOutput: customActual,
          gap: customGap,
          gapQty: customGap
        };
      }
      return s;
    });
  }, [rawSummaries, eosActualInputs, stageTab]);

  // Thống kê tổng hợp
  const activeRows = useMemo(() => summaries.filter((s) => s.hasPlan), [summaries]);
  const noPlanRows = useMemo(() => summaries.filter((s) => !s.hasPlan), [summaries]);
  const runningLinesCount = useMemo(() => new Set(activeRows.map((s) => s.line)).size, [activeRows]);
  const totalPlan = useMemo(() => activeRows.reduce((acc, s) => acc + s.planOutput, 0), [activeRows]);
  const totalActual = useMemo(() => activeRows.reduce((acc, s) => acc + s.estimateOutput, 0), [activeRows]);
  const totalGap = totalActual - totalPlan;

  const shiftLabel = shiftFilter === 'night' ? 'Ca Đêm (Ca N)' : 'Ca Ngày (Ca D)';
  const shiftSuffix = shiftFilter === 'night' ? 'N' : 'D';

  // Xử lý thay đổi ô nhập Actual trong tab EOS
  const handleActualChange = (line: string, jobType: string | undefined, val: string) => {
    const key = `${line}-${jobType || 'ALL'}`;
    setEosActualInputs((prev) => ({
      ...prev,
      [key]: val
    }));
  };

  // Nạp nhanh mẫu số liệu Actual cho các line đang chờ nhập
  const handleFillSampleEos = () => {
    const newInputs: Record<string, string> = { ...eosActualInputs };
    activeRows.forEach((row) => {
      const key = `${row.line}-${row.jobType || 'ALL'}`;
      if (row.isEosPending || row.estimateOutput === 0) {
        const offset = Math.floor(Math.random() * 21) - 8;
        const sampleVal = Math.max(0, row.planOutput + offset);
        newInputs[key] = String(sampleVal);
      }
    });
    setEosActualInputs(newInputs);
    onShowToast('Đã nạp số liệu Actual mẫu cho các Job cuối ca! Hãy kiểm tra và bấm Lưu.');
  };

  // Lưu báo cáo EOS cho một Line cụ thể
  const handleSaveLineEos = (targetLine: string) => {
    const lineRows = summaries.filter((s) => s.line === targetLine && s.hasPlan);
    if (lineRows.length === 0) {
      onShowToast(`Line ${targetLine} không có kế hoạch chạy!`, true);
      return;
    }

    const baseRep = lineRows[0].rawReport;
    if (!baseRep) {
      onShowToast(`Không tìm thấy dữ liệu BOS nền cho Line ${targetLine}!`, true);
      return;
    }

    const csRow = lineRows.find((r) => r.jobType === 'CS');
    const unRow = lineRows.find((r) => r.jobType === 'UN');
    const singleRow = lineRows.find((r) => r.jobType === 'ALL');

    let csActual = 0;
    let unActual = 0;
    let totalActualOutput = 0;

    if (csRow && unRow) {
      const csKey = `${targetLine}-CS`;
      const unKey = `${targetLine}-UN`;
      csActual = eosActualInputs[csKey] !== undefined ? parseNumber(eosActualInputs[csKey]) : csRow.estimateOutput;
      unActual = eosActualInputs[unKey] !== undefined ? parseNumber(eosActualInputs[unKey]) : unRow.estimateOutput;
      totalActualOutput = csActual + unActual;
    } else if (csRow) {
      const csKey = `${targetLine}-CS`;
      csActual = eosActualInputs[csKey] !== undefined ? parseNumber(eosActualInputs[csKey]) : csRow.estimateOutput;
      totalActualOutput = csActual;
    } else if (unRow) {
      const unKey = `${targetLine}-UN`;
      unActual = eosActualInputs[unKey] !== undefined ? parseNumber(eosActualInputs[unKey]) : unRow.estimateOutput;
      totalActualOutput = unActual;
    } else if (singleRow) {
      const key = `${targetLine}-ALL`;
      totalActualOutput = eosActualInputs[key] !== undefined ? parseNumber(eosActualInputs[key]) : singleRow.estimateOutput;
    }

    const uphNum = baseRep.uph || 25;
    const planHCCS = baseRep.planHCCS || Math.round(baseRep.planHC / 2);
    const planHCUN = baseRep.planHCUN || (baseRep.planHC - planHCCS);
    const stdCS = uphNum > 0 && planHCCS > 0 && csActual > 0 ? (planHCCS * csActual) / uphNum : 0;
    const stdUN = uphNum > 0 && planHCUN > 0 && unActual > 0 ? (planHCUN * unActual) / uphNum : 0;
    const totalStdNum = stdCS + stdUN > 0 ? stdCS + stdUN : (baseRep.planHC * totalActualOutput) / (uphNum || 1);

    const actualHoursNum = parseNumber(baseRep.actualHours) || 10;
    const actualLineNum = baseRep.routingHC * actualHoursNum;
    const effRate = actualLineNum > 0 ? Math.round((totalStdNum / actualLineNum) * 1000) / 10 : 0;

    const eosReport: ShiftReport = {
      ...baseRep,
      id: `rep-eos-${targetLine}-${Date.now()}`,
      requestId: crypto.randomUUID(),
      reportStage: 'EOS',
      estimateOutputCS: csActual > 0 ? csActual : undefined,
      estimateOutputUN: unActual > 0 ? unActual : undefined,
      estimateOutput: totalActualOutput,
      stdHour: `${totalStdNum.toFixed(1)}h`,
      stdHourCS: stdCS > 0 ? `${stdCS.toFixed(1)}h` : undefined,
      stdHourUN: stdUN > 0 ? `${stdUN.toFixed(1)}h` : undefined,
      actualLine: `${actualLineNum.toFixed(1)}h`,
      effRate,
      note: `Báo cáo cuối ca EOS (Tổng Thực Tế: ${totalActualOutput} pcs).`,
      createdAt: Date.now()
    };

    onSaveReport(eosReport);
    onShowToast(`Đã lưu Báo Cáo EOS Line ${targetLine} (Actual: ${totalActualOutput.toLocaleString()} pcs) thành công!`);
  };

  // Lưu tất cả các line EOS đang có số liệu
  const handleSaveAllEos = () => {
    const uniqueLines = Array.from(new Set(activeRows.map((r) => r.line)));
    if (uniqueLines.length === 0) {
      onShowToast('Không có line nào có kế hoạch để lưu EOS!', true);
      return;
    }

    uniqueLines.forEach((l) => {
      handleSaveLineEos(l);
    });
    onShowToast(`Đã lưu Báo Cáo EOS cho toàn bộ ${uniqueLines.length} chuyền!`);
  };

  // Mở modal sửa / tạo kế hoạch BOS cho line
  const handleOpenEditBos = (lineCode: string) => {
    setEditingBosLine(lineCode);
    const existing = reports.find(
      (r) =>
        r.line.toUpperCase() === lineCode.toUpperCase() &&
        r.date === selectedDate &&
        r.shiftType === shiftFilter &&
        r.reportStage !== 'EOS'
    );

    if (existing) {
      setBosFormModel(existing.model || '');
      setBosFormJobCS(existing.jobCS || '');
      setBosFormPlanCS(existing.planOutputCS !== undefined ? String(existing.planOutputCS) : '');
      setBosFormEstCS(existing.estimateOutputCS !== undefined ? String(existing.estimateOutputCS) : '');
      setBosFormJobUN(existing.jobUN || '');
      setBosFormPlanUN(existing.planOutputUN !== undefined ? String(existing.planOutputUN) : '');
      setBosFormEstUN(existing.estimateOutputUN !== undefined ? String(existing.estimateOutputUN) : '');
      setBosFormRemarkAtt(existing.remarkFailAtt || 'Đạt ATT');
      setBosFormReason(existing.reason || 'Vận hành ổn định');
      setBosFormDueDate(existing.dueDate || 'Đúng tiến độ');
    } else {
      // Giá trị mặc định
      setBosFormModel('A465');
      setBosFormJobCS(`MP10${lineCode.replace(/\D/g, '')}-CS01`);
      setBosFormPlanCS('250');
      setBosFormEstCS('245');
      setBosFormJobUN(`MP10${lineCode.replace(/\D/g, '')}-UN01`);
      setBosFormPlanUN('250');
      setBosFormEstUN('240');
      setBosFormRemarkAtt('Đạt ATT');
      setBosFormReason('Vận hành ổn định');
      setBosFormDueDate('Đúng tiến độ');
    }
  };

  // Lưu kế hoạch BOS từ modal
  const handleSaveBosForm = (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingBosLine) return;

    const planCS = parseNumber(bosFormPlanCS);
    const estCS = parseNumber(bosFormEstCS);
    const planUN = parseNumber(bosFormPlanUN);
    const estUN = parseNumber(bosFormEstUN);
    const totalPlanVal = planCS + planUN;
    const totalEstVal = estCS + estUN;

    const newBosReport: ShiftReport = {
      id: `rep-bos-${editingBosLine}-${Date.now()}`,
      requestId: crypto.randomUUID(),
      line: editingBosLine,
      shiftType: shiftFilter,
      reportStage: 'BOS',
      date: selectedDate,
      model: bosFormModel.trim() || 'A465',
      jobCS: bosFormJobCS.trim() || `Job-${editingBosLine}-CS`,
      planOutputCS: planCS,
      estimateOutputCS: estCS,
      jobUN: bosFormJobUN.trim() || `Job-${editingBosLine}-UN`,
      planOutputUN: planUN,
      estimateOutputUN: estUN,
      planOutput: totalPlanVal,
      estimateOutput: totalEstVal,
      totalHC: 26,
      leaveAL: 0,
      leaveSL: 0,
      leaveUP: 0,
      leaveUPP: 0,
      leaveOther: 0,
      totalLeaveHC: 0,
      lateHC: 0,
      planHC: 24,
      planHCCS: 12,
      planHCUN: 12,
      routingHC: 24,
      routingHCCS: 12,
      routingHCUN: 12,
      presentHC: 26,
      diffHCText: '0 (Đủ)',
      attRate: 100,
      uph: 25,
      stdHour: `${(totalPlanVal / 25 * 1.2).toFixed(1)}h`,
      actualLine: '240.0h',
      estimateAtt: '100%',
      planHours: '10',
      actualHours: '10',
      effRate: 100,
      leader: 'Line Leader',
      note: 'Kế hoạch BOS đầu ca.',
      remarkFailAtt: bosFormRemarkAtt.trim() || 'Đạt ATT',
      jobPending: bosFormJobCS.trim() || `Job-${editingBosLine}-CS`,
      reason: bosFormReason.trim() || 'Vận hành ổn định',
      dueDate: bosFormDueDate.trim() || 'Đúng tiến độ',
      createdAt: Date.now()
    };

    onSaveReport(newBosReport);
    onShowToast(`Đã lưu Kế Hoạch BOS cho Line ${editingBosLine}!`);
    setEditingBosLine(null);
  };

  const handleExportExcel = () => {
    try {
      const success = exportDailySummaryToExcel(summaries, selectedDate, shiftFilter, stageTab);
      if (success) {
        const stageText = stageTab === 'EOS' ? 'EOS (Cuối Ca)' : 'BOS (Đầu Ca)';
        onShowToast(`Đã xuất báo cáo ${stageText} ${shiftLabel} ra file Excel (.xlsx)!`);
      }
    } catch (err) {
      console.error('Export error:', err);
      onShowToast('Có lỗi xảy ra khi xuất file Excel', true);
    }
  };

  const handleCopyTSV = () => {
    try {
      const tsv = formatDailySummaryTSV(summaries, stageTab);
      navigator.clipboard.writeText(tsv);
      setCopiedTsv(true);
      onShowToast(`Đã chép bảng ${stageTab === 'EOS' ? 'EOS (Cuối Ca)' : 'BOS (Đầu Ca)'}. Bấm Ctrl+V dán ngay vào Excel / Google Sheets!`);
      setTimeout(() => setCopiedTsv(false), 2500);
    } catch {
      onShowToast('Không thể sao chép bảng, vui lòng thử lại', true);
    }
  };

  const handleCopyMessage = () => {
    try {
      const text = formatDailySummaryMessage(summaries, selectedDate, shiftFilter, stageTab);
      navigator.clipboard.writeText(text);
      setCopiedMsg(true);
      onShowToast(`Đã sao chép tin nhắn báo cáo ${stageTab === 'EOS' ? 'EOS' : 'BOS'} (Zalo / Teams)!`);
      setTimeout(() => setCopiedMsg(false), 2500);
    } catch {
      onShowToast('Không thể sao chép văn bản, vui lòng thử lại', true);
    }
  };

  const handlePrint = () => {
    window.print();
  };

  const handleAddLine = () => {
    const trimmed = newLineInput.trim().toUpperCase();
    if (!trimmed) return;
    if (factoryLines.includes(trimmed)) {
      onShowToast('Line này đã có trong danh sách!', true);
      return;
    }
    const updated = [...factoryLines, trimmed];
    setFactoryLines(updated);
    saveStoredFactoryLines(updated);
    setNewLineInput('');
    onShowToast(`Đã thêm Line ${trimmed} vào danh sách xưởng!`);
  };

  const handleRemoveLine = (lineToRemove: string) => {
    if (factoryLines.length <= 1) {
      onShowToast('Cần giữ lại ít nhất 1 line!', true);
      return;
    }
    const updated = factoryLines.filter((l) => l !== lineToRemove);
    setFactoryLines(updated);
    saveStoredFactoryLines(updated);
    onShowToast(`Đã xóa Line ${lineToRemove}`);
  };

  const handleResetDefaultLines = () => {
    setFactoryLines(DEFAULT_FACTORY_LINES);
    saveStoredFactoryLines(DEFAULT_FACTORY_LINES);
    onShowToast('Đã khôi phục 6 line mặc định (1323 – 1328)!');
  };

  return (
    <div className="space-y-4">
      {/* Control Bar: Chọn Ngày, Ca (D/N) và các nút thao tác nhanh */}
      <div className="bg-white rounded-2xl shadow-sm border border-slate-200 p-4 flex flex-wrap items-center justify-between gap-3 no-print">
        {/* Bộ lọc Ngày và Ca */}
        <div className="flex flex-wrap items-center gap-3">
          {/* Chọn ngày */}
          <div className="flex items-center gap-1.5 bg-slate-50 border border-slate-300 rounded-xl px-3 py-1.5 shadow-2xs">
            <Calendar className="w-4 h-4 text-sky-600" />
            <span className="text-xs font-bold text-slate-600">Ngày:</span>
            <input
              type="date"
              value={selectedDate}
              onChange={(e) => onDateChange(e.target.value)}
              className="text-xs font-black text-slate-800 bg-transparent focus:outline-none cursor-pointer"
            />
          </div>

          {/* CHỌN CA: CHỈ CA NGÀY (D) HOẶC CA ĐÊM (N), KHÔNG GỘP 2 CA */}
          <div className="flex items-center gap-1.5">
            <span className="text-xs font-bold text-slate-600">Ca:</span>
            <div className="inline-flex rounded-xl bg-slate-100 p-1 text-xs font-bold shadow-inner border border-slate-200">
              <button
                type="button"
                onClick={() => setShiftFilter('day')}
                className={`px-3.5 py-1.5 rounded-lg transition-all cursor-pointer flex items-center gap-1.5 ${
                  shiftFilter === 'day'
                    ? 'bg-amber-500 text-white shadow-xs font-black'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                <span>☀️</span> Ca Ngày (Ca D)
              </button>
              <button
                type="button"
                onClick={() => setShiftFilter('night')}
                className={`px-3.5 py-1.5 rounded-lg transition-all cursor-pointer flex items-center gap-1.5 ${
                  shiftFilter === 'night'
                    ? 'bg-indigo-900 text-white shadow-xs font-black'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                <span>🌙</span> Ca Đêm (Ca N)
              </button>
            </div>
          </div>
        </div>

        {/* Các nút Xuất & Thao tác */}
        <div className="flex flex-wrap items-center gap-2">
          {/* Xuất Excel */}
          <button
            type="button"
            onClick={handleExportExcel}
            className="px-3.5 py-2 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-xs font-bold flex items-center gap-1.5 shadow-sm transition-all cursor-pointer"
            title="Tải về file Excel (.xlsx) chuẩn format 10 cột"
          >
            <FileSpreadsheet className="w-4 h-4" /> Xuất Excel (.xlsx)
          </button>

          {/* Chép Bảng TSV */}
          <button
            type="button"
            onClick={handleCopyTSV}
            className="px-3 py-2 bg-teal-700 hover:bg-teal-800 text-white rounded-xl text-xs font-bold flex items-center gap-1.5 shadow-sm transition-all cursor-pointer"
            title="Sao chép bảng định dạng tab để Ctrl+V dán ngay vào Excel / Google Sheets"
          >
            <ClipboardCopy className="w-4 h-4" /> {copiedTsv ? 'Đã chép bảng!' : 'Chép Dán Excel'}
          </button>

          {/* Chép Tin Nhắn */}
          <button
            type="button"
            onClick={handleCopyMessage}
            className="px-3 py-2 bg-sky-700 hover:bg-sky-800 text-white rounded-xl text-xs font-bold flex items-center gap-1.5 shadow-sm transition-all cursor-pointer"
            title="Sao chép tin nhắn gửi Zalo / Teams"
          >
            <Copy className="w-4 h-4" /> {copiedMsg ? 'Đã chép!' : 'Chép Tin Nhắn'}
          </button>

          {/* Quản lý danh sách Line */}
          <button
            type="button"
            onClick={() => setShowLineSettings(!showLineSettings)}
            className="px-3 py-2 bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 rounded-xl text-xs font-semibold flex items-center gap-1.5 transition-all cursor-pointer"
            title="Cấu hình danh sách 6 chuyền (1323 – 1328)"
          >
            <Settings2 className="w-4 h-4 text-amber-400" /> Quản Lý 6 Line
          </button>

          {/* In */}
          <button
            type="button"
            onClick={handlePrint}
            className="px-3 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 border border-slate-300 rounded-xl text-xs font-semibold flex items-center gap-1.5 transition-all cursor-pointer hidden sm:flex"
            title="In báo cáo ra giấy"
          >
            <Printer className="w-4 h-4 text-slate-500" /> In
          </button>
        </div>
      </div>

      {/* Quản lý danh sách 6 Line (Collapsible) */}
      {showLineSettings && (
        <div className="bg-amber-50/95 border border-amber-200 rounded-2xl p-4 text-xs text-amber-950 no-print">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 mb-2">
            <span className="font-bold flex items-center gap-1.5 text-amber-900">
              <Settings2 className="w-4 h-4 text-amber-700" /> Danh sách chuyền quản lý xưởng:
            </span>
            <button
              type="button"
              onClick={handleResetDefaultLines}
              className="text-amber-700 hover:text-amber-900 underline font-semibold text-[11px] cursor-pointer self-start sm:self-auto"
            >
              Khôi phục chuẩn 6 Line (1323 – 1328)
            </button>
          </div>
          <div className="flex flex-wrap items-center gap-1.5 mb-2.5">
            {factoryLines.map((l) => (
              <span
                key={l}
                className="inline-flex items-center gap-1 bg-white border border-amber-300 rounded-md px-2.5 py-1 font-bold text-slate-800 text-xs shadow-2xs"
              >
                Line {l}
                <button
                  type="button"
                  onClick={() => handleRemoveLine(l)}
                  className="text-slate-400 hover:text-rose-600 cursor-pointer ml-1"
                  title={`Xóa Line ${l}`}
                >
                  <X className="w-3.5 h-3.5" />
                </button>
              </span>
            ))}
          </div>
          <div className="flex items-center gap-2 max-w-sm">
            <input
              type="text"
              placeholder="Nhập line mới..."
              value={newLineInput}
              onChange={(e) => setNewLineInput(e.target.value.toUpperCase())}
              onKeyDown={(e) => e.key === 'Enter' && (e.preventDefault(), handleAddLine())}
              className="bg-white border border-amber-300 rounded-lg px-2.5 py-1 text-xs text-slate-800 font-bold focus:outline-none focus:ring-1 focus:ring-amber-500 flex-1"
            />
            <button
              type="button"
              onClick={handleAddLine}
              className="px-3 py-1 bg-amber-600 hover:bg-amber-700 text-white rounded-lg font-bold text-xs flex items-center gap-1 cursor-pointer"
            >
              <Plus className="w-3.5 h-3.5" /> Thêm
            </button>
          </div>
        </div>
      )}

      {/* 2 TAB RIÊNG BIỆT: BOS (ĐẦU CA) & EOS (CUỐI CA) - TOÀN BỘ MÀN HÌNH CHÍNH */}
      <div className="bg-slate-950 p-2.5 rounded-2xl border border-slate-800 shadow-md grid grid-cols-2 gap-2.5">
        <button
          type="button"
          onClick={() => setStageTab('BOS')}
          className={`py-3 px-4 rounded-xl transition-all cursor-pointer flex items-center justify-between border ${
            stageTab === 'BOS'
              ? 'bg-gradient-to-r from-sky-600 to-blue-700 text-white border-sky-400 shadow-lg font-black ring-2 ring-sky-400/40'
              : 'bg-slate-900/80 hover:bg-slate-800 text-slate-400 hover:text-slate-200 border-slate-800'
          }`}
        >
          <div className="flex items-center gap-3 text-left">
            <span className="text-2xl">☀️</span>
            <div>
              <div className="text-sm font-black uppercase tracking-wide flex items-center gap-2">
                TAB 1: BOS (ĐẦU CA)
                {stageTab === 'BOS' && (
                  <span className="w-2.5 h-2.5 rounded-full bg-amber-300 animate-pulse"></span>
                )}
              </div>
              <div className="text-xs font-medium opacity-85">
                Kế hoạch & Sản lượng dự kiến đầu ca (Estimate)
              </div>
            </div>
          </div>
          <span className="text-xs px-2.5 py-1 rounded-md font-mono font-bold bg-black/30 border border-white/10 hidden sm:inline-block">
            BOS - Estimate
          </span>
        </button>

        <button
          type="button"
          onClick={() => setStageTab('EOS')}
          className={`py-3 px-4 rounded-xl transition-all cursor-pointer flex items-center justify-between border ${
            stageTab === 'EOS'
              ? 'bg-gradient-to-r from-emerald-600 to-teal-700 text-white border-emerald-400 shadow-lg font-black ring-2 ring-emerald-400/40'
              : 'bg-slate-900/80 hover:bg-slate-800 text-slate-400 hover:text-slate-200 border-slate-800'
          }`}
        >
          <div className="flex items-center gap-3 text-left">
            <span className="text-2xl">🏁</span>
            <div>
              <div className="text-sm font-black uppercase tracking-wide flex items-center gap-2">
                TAB 2: ACTUAL EOS (CUỐI CA)
                {stageTab === 'EOS' && (
                  <span className="w-2.5 h-2.5 rounded-full bg-emerald-300 animate-pulse"></span>
                )}
              </div>
              <div className="text-xs font-medium opacity-85">
                Dữ liệu đầu ca tự động fill, điền số lượng Thực Tế (Actual)
              </div>
            </div>
          </div>
          <span className="text-xs px-2.5 py-1 rounded-md font-mono font-bold bg-black/30 border border-white/10 hidden sm:inline-block">
            EOS - Actual
          </span>
        </button>
      </div>

      {/* BANNER HƯỚNG DẪN TAB EOS */}
      {stageTab === 'EOS' && (
        <div className="bg-gradient-to-r from-emerald-50 via-teal-50 to-emerald-50 border border-emerald-200 rounded-2xl px-5 py-3 text-xs text-emerald-950 flex flex-wrap items-center justify-between gap-3 shadow-xs">
          <div className="flex items-center gap-2.5 max-w-3xl">
            <span className="px-2.5 py-1 rounded-lg bg-emerald-600 text-white font-black text-[10px] uppercase shrink-0 shadow-2xs">
              Tự Động Điền
            </span>
            <p className="text-xs font-semibold text-emerald-950 leading-relaxed">
              Dữ liệu đầu ca (<strong>Line, Model, Job theo Plan CS & UN, Kế hoạch, Remark ATT, Job Pending, Reason, Due date</strong>) đã được <strong>tự động nạp sẵn từ BOS</strong>! Các bạn chỉ cần <strong>điền Thực Tế (Actual)</strong> cho từng Job vào ô bên dưới rồi bấm <strong>Lưu EOS</strong>.
            </p>
          </div>
          <div className="flex items-center gap-2 shrink-0">
            <button
              type="button"
              onClick={handleFillSampleEos}
              className="px-3 py-1.5 bg-white hover:bg-emerald-100 text-emerald-800 border border-emerald-300 rounded-lg text-xs font-bold cursor-pointer transition-colors flex items-center gap-1.5 shadow-2xs"
              title="Điền nhanh số liệu Actual mẫu cho các line"
            >
              <Sparkles className="w-3.5 h-3.5 text-emerald-600" /> Điền Mẫu Nhanh
            </button>
            <button
              type="button"
              onClick={handleSaveAllEos}
              className="px-3.5 py-1.5 bg-emerald-700 hover:bg-emerald-800 text-white rounded-lg text-xs font-black cursor-pointer transition-colors flex items-center gap-1.5 shadow-xs"
              title="Lưu tất cả các dòng EOS đang có số liệu"
            >
              <Save className="w-3.5 h-3.5 text-white" /> Lưu Tất Cả EOS
            </button>
          </div>
        </div>
      )}

      {/* BANNER HƯỚNG DẪN TAB BOS */}
      {stageTab === 'BOS' && (
        <div className="bg-sky-50 border border-sky-200 rounded-2xl px-5 py-2.5 text-xs text-sky-950 flex items-center justify-between shadow-2xs">
          <div className="flex items-center gap-2">
            <span className="px-2 py-0.5 rounded bg-sky-600 text-white font-black text-[10px] uppercase shrink-0">
              BOS Đầu Ca
            </span>
            <p className="text-xs font-medium text-sky-950">
              Báo cáo đầu ca: Thống kê số lượng kế hoạch (Plan) và dự kiến (Estimate) cho từng chuyền và từng Job (CS & UN). Bạn có thể bấm <strong>Sửa Kế Hoạch</strong> ở cuối dòng để cập nhật.
            </p>
          </div>
        </div>
      )}

      {/* Quick KPI Strip */}
      <div className="bg-white rounded-2xl border border-slate-200 p-3 grid grid-cols-2 sm:grid-cols-4 gap-2 text-center text-xs shadow-2xs">
        <div className="p-2 rounded-xl bg-slate-50 border border-slate-200/80">
          <div className="text-[10px] text-slate-500 font-bold uppercase">Ca & Trạng Thái</div>
          <div className="text-base font-black text-slate-800 flex items-center justify-center gap-1 mt-0.5">
            <span>{shiftLabel}</span>
            <span className={`text-[10px] px-1.5 py-0.2 rounded font-black ${stageTab === 'EOS' ? 'bg-emerald-100 text-emerald-800' : 'bg-sky-100 text-sky-800'}`}>
              {stageTab}
            </span>
          </div>
        </div>
        <div className="p-2 rounded-xl bg-slate-50 border border-slate-200/80">
          <div className="text-[10px] text-slate-500 font-bold uppercase">Tổng Plan</div>
          <div className="text-base font-black text-sky-900 mt-0.5">{totalPlan.toLocaleString()}</div>
        </div>
        <div className="p-2 rounded-xl bg-slate-50 border border-slate-200/80">
          <div className="text-[10px] text-slate-500 font-bold uppercase">
            {stageTab === 'BOS' ? 'Tổng Estimate' : 'Tổng Actual (Thực Tế)'}
          </div>
          <div className={`text-base font-black mt-0.5 ${stageTab === 'EOS' ? 'text-emerald-700' : 'text-indigo-900'}`}>
            {totalActual.toLocaleString()}
          </div>
        </div>
        <div className="p-2 rounded-xl bg-slate-50 border border-slate-200/80">
          <div className="text-[10px] text-slate-500 font-bold uppercase">GAP Toàn Ca</div>
          <div
            className={`text-base font-black mt-0.5 ${
              totalGap >= 0 ? 'text-emerald-700' : 'text-rose-600'
            }`}
          >
            {totalGap >= 0 ? `+${totalGap.toLocaleString()}` : totalGap.toLocaleString()}
          </div>
        </div>
      </div>

      {/* BẢNG BÁO CÁO 10 CỘT CHUẨN TOÀN MÀN HÌNH */}
      <div className="bg-white rounded-2xl shadow-sm border border-slate-200 overflow-hidden">
        <div className="overflow-x-auto overflow-y-auto max-h-[750px]">
          <table className="w-full text-left border-collapse text-xs border border-slate-300 min-w-[1250px]">
            {/* Header: Đúng định dạng 10 cột chuẩn */}
            <thead className="bg-slate-900 text-white font-bold sticky top-0 z-10 text-[11px] tracking-wide">
              <tr>
                <th className="p-3 border-r border-slate-700 w-28 text-center uppercase">Line</th>
                <th className="p-3 border-r border-slate-700 min-w-[260px] uppercase">Job theo Plan</th>
                <th className="p-3 border-r border-slate-700 text-right w-24 uppercase">Plan</th>
                {/* Cột 4: Estimate (BOS) hoặc Actual (EOS) */}
                <th
                  className={`p-3 border-r border-slate-700 text-right w-36 uppercase ${
                    stageTab === 'EOS' ? 'bg-emerald-950 text-emerald-300' : 'bg-slate-900 text-white'
                  }`}
                >
                  {stageTab === 'BOS' ? 'Estimate' : 'Actual (EOS)'}
                </th>
                {/* CỘT GAP NẰM GIỮA ACTUAL VÀ REMARK FAIL ATT */}
                <th className="p-3 border-r border-slate-700 text-right w-24 bg-sky-950 text-amber-300 uppercase">
                  GAP
                </th>
                <th className="p-3 border-r border-slate-700 min-w-[180px] uppercase">Remark fail ATT</th>
                <th className="p-3 border-r border-slate-700 min-w-[180px] uppercase">Job Pending</th>
                <th className="p-3 border-r border-slate-700 text-right w-28 bg-slate-800 text-amber-300 uppercase">
                  Qty GAP tổng
                </th>
                <th className="p-3 border-r border-slate-700 min-w-[220px] uppercase">Reason</th>
                <th className="p-3 border-r border-slate-700 w-32 uppercase">Due date</th>
                <th className="p-3 w-28 text-center uppercase bg-slate-800 text-slate-200">
                  Thao Tác
                </th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-200 bg-white">
              {summaries.map((s, idx) => {
                if (!s.hasPlan) {
                  // CÁC LINE KHÔNG CHẠY TRONG CA NÀY -> ĐỂ "No plan", Job Pending là "—"
                  return (
                    <tr
                      key={`no-plan-${s.line}-${idx}`}
                      className="bg-slate-50/80 hover:bg-slate-100/80 transition-colors text-slate-500"
                    >
                      {/* Line */}
                      <td className="p-3 border-r border-slate-200 text-center font-black text-slate-700">
                        <span className="px-2.5 py-1 bg-slate-200 text-slate-700 rounded-md inline-block font-extrabold text-xs">
                          {s.line}
                        </span>
                      </td>

                      {/* Job theo Plan */}
                      <td className="p-3 border-r border-slate-200"></td>

                      {/* Plan */}
                      <td className="p-3 border-r border-slate-200"></td>

                      {/* Actual / Estimate */}
                      <td className="p-3 border-r border-slate-200"></td>

                      {/* GAP (nằm giữa Actual và Remark fail ATT) */}
                      <td className="p-3 border-r border-slate-200 bg-slate-50/40"></td>

                      {/* Remark fail ATT */}
                      <td className="p-3 border-r border-slate-200"></td>

                      {/* Job Pending */}
                      <td className="p-3 border-r border-slate-200 text-center text-slate-400 font-bold">
                        {s.jobPending || '—'}
                      </td>

                      {/* Qty GAP tổng */}
                      <td className="p-3 border-r border-slate-200 bg-slate-50/50"></td>

                      {/* Reason */}
                      <td className="p-3 border-r border-slate-200"></td>

                      {/* Due date */}
                      <td className="p-3 border-r border-slate-200"></td>

                      {/* Thao tác: Bấm để thêm kế hoạch nếu line có chạy */}
                      <td className="p-2 text-center">
                        <div className="flex flex-col gap-1 items-center justify-center">
                          <button
                            type="button"
                            onClick={() => handleOpenEditBos(s.line)}
                            className="w-full px-2 py-1 bg-slate-200 hover:bg-sky-100 text-slate-700 hover:text-sky-900 rounded text-[10px] font-bold cursor-pointer transition-colors"
                            title={`Thêm nhanh kế hoạch chạy cho Line ${s.line}`}
                          >
                            + Thêm Plan
                          </button>
                          {onOpenCalculationForm && (
                            <button
                              type="button"
                              onClick={() => onOpenCalculationForm(s.line, stageTab)}
                              className="w-full px-1.5 py-0.5 bg-slate-100 hover:bg-slate-200 text-slate-600 rounded text-[9px] font-bold cursor-pointer transition-colors border border-slate-300"
                              title={`Mở bản tính toán chi tiết cho Line ${s.line}`}
                            >
                              📝 Bảng Tính
                            </button>
                          )}
                        </div>
                      </td>
                    </tr>
                  );
                }

                // LINE CÓ BÁO CÁO TRONG CA NÀY
                const isGapPositive = s.gap >= 0;
                const isGapTotalPositive = s.gapQty >= 0;
                const isAttOk = s.attRate >= 95;

                // Giá trị Actual hiển thị trong tab EOS
                const inputKey = `${s.line}-${s.jobType || 'ALL'}`;
                const currentInputValue =
                  eosActualInputs[inputKey] !== undefined
                    ? eosActualInputs[inputKey]
                    : s.estimateOutput > 0
                    ? String(s.estimateOutput)
                    : '';

                return (
                  <tr
                    key={`active-${s.line}-${s.jobType}-${idx}`}
                    className="hover:bg-sky-50/40 transition-colors border-b border-slate-200"
                  >
                    {/* 1. Line */}
                    <td className="p-3 border-r border-slate-200 text-center">
                      <span className="inline-flex items-center gap-1 px-2.5 py-1 bg-sky-100 border border-sky-300 text-sky-950 rounded-md font-black text-xs">
                        {s.line}
                      </span>
                    </td>

                    {/* 2. Job theo Plan (CS 1 hàng, UN 1 hàng) */}
                    <td className="p-3 border-r border-slate-200 font-mono text-[11px] text-slate-900 font-medium break-all">
                      <div className="flex items-center gap-1.5 flex-wrap">
                        {s.jobType === 'CS' && (
                          <span className="px-1.5 py-0.5 rounded text-[10px] font-black bg-sky-100 text-sky-800 border border-sky-300 shrink-0">
                            CS
                          </span>
                        )}
                        {s.jobType === 'UN' && (
                          <span className="px-1.5 py-0.5 rounded text-[10px] font-black bg-indigo-100 text-indigo-800 border border-indigo-300 shrink-0">
                            UN
                          </span>
                        )}
                        <span className="font-semibold">{s.jobTheoPlan}</span>
                      </div>
                    </td>

                    {/* 3. Plan */}
                    <td className="p-3 border-r border-slate-200 text-right font-black text-slate-800 text-xs font-mono">
                      {s.planOutput.toLocaleString()}
                    </td>

                    {/* 4. Actual / Estimate (Cho phép nhập trực tiếp trên tab EOS) */}
                    <td className="p-2 border-r border-slate-200 text-right font-mono">
                      {stageTab === 'EOS' ? (
                        <div className="flex items-center justify-end gap-1.5">
                          <input
                            type="number"
                            min="0"
                            placeholder="Điền Actual..."
                            value={currentInputValue}
                            onChange={(e) => handleActualChange(s.line, s.jobType, e.target.value)}
                            className="w-24 bg-white border-2 border-emerald-500 rounded-lg px-2 py-1 text-xs font-black text-right text-emerald-950 focus:outline-none focus:ring-2 focus:ring-emerald-400 shadow-2xs"
                          />
                          {s.isEosPending ? (
                            <span
                              className="text-[9px] bg-amber-100 text-amber-800 border border-amber-300 px-1 py-0.5 rounded font-black shrink-0"
                              title="Tự nạp từ BOS, đang chờ nhập Actual"
                            >
                              Chờ
                            </span>
                          ) : (
                            <span
                              className="text-[9px] bg-emerald-100 text-emerald-800 border border-emerald-300 px-1 py-0.5 rounded font-black shrink-0"
                              title="Đã lưu báo cáo EOS"
                            >
                              ✓
                            </span>
                          )}
                        </div>
                      ) : (
                        <span className="font-black text-sky-900 text-xs">
                          {s.estimateOutput.toLocaleString()}
                        </span>
                      )}
                    </td>

                    {/* 5. GAP (NẰM GIỮA ACTUAL VÀ REMARK FAIL ATT) */}
                    <td className="p-3 border-r border-slate-200 text-right font-mono bg-sky-50/40">
                      <span
                        className={`inline-block px-2.5 py-0.5 rounded font-black text-xs ${
                          isGapPositive
                            ? 'bg-emerald-100 text-emerald-800 border border-emerald-300'
                            : 'bg-rose-100 text-rose-800 border border-rose-300'
                        }`}
                      >
                        {isGapPositive ? `+${s.gap}` : s.gap}
                      </span>
                    </td>

                    {/* 6. Remark fail ATT */}
                    <td className="p-3 border-r border-slate-200 text-[11px]">
                      {isAttOk ? (
                        <span className="text-emerald-700 font-medium flex items-center gap-1">
                          <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600 shrink-0" /> {s.remarkFailAtt}
                        </span>
                      ) : (
                        <span className="text-rose-700 font-bold flex items-center gap-1 bg-rose-50 px-2 py-0.5 rounded border border-rose-200">
                          <AlertTriangle className="w-3.5 h-3.5 text-rose-600 shrink-0" /> {s.remarkFailAtt}
                        </span>
                      )}
                    </td>

                    {/* 7. Job Pending (lấy mã Job CS / UN giống cột Job theo plan) */}
                    <td className="p-3 border-r border-slate-200 font-mono text-[11px] text-slate-900 font-medium break-all">
                      <div className="flex items-center gap-1.5 flex-wrap">
                        {s.jobType === 'CS' && (
                          <span className="px-1.5 py-0.5 rounded text-[10px] font-black bg-sky-100 text-sky-800 border border-sky-300 shrink-0">
                            CS
                          </span>
                        )}
                        {s.jobType === 'UN' && (
                          <span className="px-1.5 py-0.5 rounded text-[10px] font-black bg-indigo-100 text-indigo-800 border border-indigo-300 shrink-0">
                            UN
                          </span>
                        )}
                        <span className="font-semibold">{s.jobPending}</span>
                      </div>
                    </td>

                    {/* 8. Qty GAP tổng */}
                    <td className="p-3 border-r border-slate-200 text-right font-mono">
                      <span
                        className={`inline-block px-2 py-0.5 rounded font-black text-xs ${
                          isGapTotalPositive
                            ? 'bg-emerald-100 text-emerald-800 border border-emerald-300'
                            : 'bg-rose-100 text-rose-800 border border-rose-300'
                        }`}
                      >
                        {isGapTotalPositive ? `+${s.gapQty}` : s.gapQty}
                      </span>
                    </td>

                    {/* 9. Reason */}
                    <td className="p-3 border-r border-slate-200 text-[11px] text-slate-700">
                      {s.reason}
                    </td>

                    {/* 10. Due date */}
                    <td className="p-3 border-r border-slate-200 text-[11px] font-semibold text-slate-700">
                      {s.dueDate}
                    </td>

                    {/* Thao tác: Lưu Line (khi ở EOS) hoặc Sửa BOS (khi ở BOS) */}
                    <td className="p-2 text-center">
                      <div className="flex flex-col gap-1 items-center justify-center">
                        {stageTab === 'EOS' ? (
                          <button
                            type="button"
                            onClick={() => handleSaveLineEos(s.line)}
                            className="w-full px-2 py-1 bg-emerald-600 hover:bg-emerald-700 text-white rounded text-[10px] font-bold cursor-pointer transition-colors flex items-center justify-center gap-1 shadow-2xs"
                            title={`Lưu báo cáo EOS cho Line ${s.line}`}
                          >
                            <Save className="w-3 h-3" /> Lưu EOS
                          </button>
                        ) : (
                          <button
                            type="button"
                            onClick={() => handleOpenEditBos(s.line)}
                            className="w-full px-2 py-1 bg-sky-100 hover:bg-sky-200 text-sky-900 border border-sky-300 rounded text-[10px] font-bold cursor-pointer transition-colors flex items-center justify-center gap-1"
                            title={`Sửa nhanh kế hoạch Line ${s.line}`}
                          >
                            <Edit3 className="w-3 h-3 text-sky-700" /> Sửa Nhanh
                          </button>
                        )}
                        {onOpenCalculationForm && (
                          <button
                            type="button"
                            onClick={() => onOpenCalculationForm(s.line, stageTab)}
                            className="w-full px-1.5 py-0.5 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded text-[9px] font-bold cursor-pointer transition-colors border border-slate-300 flex items-center justify-center gap-1"
                            title={`Mở bản tính toán chi tiết cho Line ${s.line}`}
                          >
                            <span>📝 Bảng Tính</span>
                          </button>
                        )}
                      </div>
                    </td>
                  </tr>
                );
              })}
            </tbody>

            {/* Table Footer: Tổng kết các chỉ số */}
            <tfoot className="bg-slate-900 text-white font-bold sticky bottom-0 text-[11px] border-t-2 border-slate-700">
              <tr>
                <td className="p-3 border-r border-slate-700 text-center font-black">
                  TỔNG CỘNG
                </td>
                <td className="p-3 border-r border-slate-700 text-slate-300 font-medium">
                  {activeRows.length} Job ({runningLinesCount}/{factoryLines.length} Line chạy)
                </td>
                <td className="p-3 border-r border-slate-700 text-right font-black text-sky-400 font-mono text-xs">
                  {totalPlan.toLocaleString()}
                </td>
                <td className="p-3 border-r border-slate-700 text-right font-black text-white font-mono text-xs">
                  {totalActual.toLocaleString()}
                </td>
                {/* Tổng GAP */}
                <td
                  className={`p-3 border-r border-slate-700 text-right font-black font-mono text-xs ${
                    totalGap >= 0 ? 'text-emerald-400' : 'text-rose-400'
                  }`}
                >
                  {totalGap >= 0 ? `+${totalGap.toLocaleString()}` : totalGap.toLocaleString()}
                </td>
                <td className="p-3 border-r border-slate-700 text-slate-400 font-normal">
                  —
                </td>
                <td className="p-3 border-r border-slate-700 text-slate-400 font-normal">
                  —
                </td>
                <td
                  className={`p-3 border-r border-slate-700 text-right font-black font-mono text-xs ${
                    totalGap >= 0 ? 'text-emerald-400' : 'text-rose-400'
                  }`}
                >
                  {totalGap >= 0 ? `+${totalGap.toLocaleString()}` : totalGap.toLocaleString()}
                </td>
                <td className="p-3 border-r border-slate-700 text-slate-400 font-normal">
                  —
                </td>
                <td className="p-3 border-r border-slate-700 text-slate-400 font-normal">
                  —
                </td>
                <td className="p-3 text-center text-slate-400 font-bold text-[10px]">
                  {stageTab}
                </td>
              </tr>
            </tfoot>
          </table>
        </div>

        {/* Chú thích phía dưới bảng */}
        <div className="bg-slate-50 border-t border-slate-200 px-5 py-3 flex flex-wrap items-center justify-between gap-3 text-xs text-slate-600">
          <div className="flex items-center gap-2">
            <span className="font-bold text-slate-800">
              {stageTab === 'BOS' ? 'Tab BOS (Đầu Ca):' : 'Tab Actual EOS (Cuối Ca):'}
            </span>
            <span>
              {stageTab === 'BOS'
                ? `Chỉ hiển thị riêng ${shiftLabel} (CS 1 hàng & UN 1 hàng với số lượng riêng biệt). Cột GAP nằm ngay sau Estimate.`
                : `Dữ liệu đầu ca đã tự động fill từ BOS. Điền số lượng Thực Tế (Actual) vào ô và bấm Lưu Line để chốt báo cáo cuối ca.`}
            </span>
          </div>
          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={handleCopyTSV}
              className="px-3 py-1 bg-teal-600 hover:bg-teal-700 text-white rounded-lg font-bold cursor-pointer text-xs flex items-center gap-1 shadow-2xs"
            >
              <ClipboardCopy className="w-3.5 h-3.5" /> Chép Bảng
            </button>
            <button
              type="button"
              onClick={handleExportExcel}
              className="px-3 py-1 bg-emerald-600 hover:bg-emerald-700 text-white rounded-lg font-bold cursor-pointer text-xs flex items-center gap-1 shadow-2xs"
            >
              <FileSpreadsheet className="w-3.5 h-3.5" /> Xuất Excel
            </button>
          </div>
        </div>
      </div>

      {/* MODAL SỬA KẾ HOẠCH BOS CHO LINE (GỌN GÀNG, CHỈ 10 THÔNG TIN CHUẨN) */}
      {editingBosLine && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-3 bg-slate-900/70 backdrop-blur-xs overflow-y-auto">
          <div className="bg-white w-full max-w-xl rounded-2xl shadow-2xl border border-slate-200 overflow-hidden">
            <div className="bg-slate-900 text-white px-5 py-3.5 flex justify-between items-center">
              <h3 className="font-bold text-sm flex items-center gap-2">
                <Edit3 className="w-4 h-4 text-sky-400" />
                Cập Nhật Kế Hoạch BOS - Line {editingBosLine}
              </h3>
              <button
                type="button"
                onClick={() => setEditingBosLine(null)}
                className="text-slate-400 hover:text-white cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSaveBosForm} className="p-5 space-y-4 text-xs">
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">Model chuyền</label>
                <input
                  type="text"
                  required
                  placeholder="Vd: A465"
                  value={bosFormModel}
                  onChange={(e) => setBosFormModel(e.target.value)}
                  className="w-full bg-slate-50 border border-slate-300 rounded-lg px-3 py-1.5 font-bold text-slate-800 focus:outline-none focus:ring-2 focus:ring-sky-500"
                />
              </div>

              {/* Job CS & Số lượng */}
              <div className="bg-sky-50/70 p-3 rounded-xl border border-sky-200 space-y-2">
                <div className="font-bold text-sky-900 flex items-center gap-1">
                  <span className="w-2 h-2 rounded-full bg-sky-500"></span> Phân Đoạn Job CS
                </div>
                <div>
                  <label className="block text-[11px] font-semibold text-slate-600 mb-0.5">Mã Job CS</label>
                  <input
                    type="text"
                    required
                    placeholder="Mã Job CS..."
                    value={bosFormJobCS}
                    onChange={(e) => setBosFormJobCS(e.target.value)}
                    className="w-full bg-white border border-sky-300 rounded-lg px-2.5 py-1.5 font-mono font-medium text-slate-800 focus:outline-none focus:ring-2 focus:ring-sky-500"
                  />
                </div>
                <div className="grid grid-cols-2 gap-x-2 gap-y-1">
                  <label className="text-[11px] font-semibold text-slate-600 flex items-end leading-tight min-h-[24px] sm:min-h-0">
                    Kế hoạch (Plan) CS
                  </label>
                  <label className="text-[11px] font-semibold text-slate-600 flex items-end leading-tight min-h-[24px] sm:min-h-0">
                    Dự kiến (Estimate) CS
                  </label>
                  <div>
                    <input
                      type="number"
                      min="0"
                      required
                      placeholder="0"
                      value={bosFormPlanCS}
                      onChange={(e) => setBosFormPlanCS(e.target.value)}
                      className="w-full h-9 bg-white border border-sky-300 rounded-lg px-2.5 py-1 font-bold text-center text-slate-800 focus:outline-none focus:ring-2 focus:ring-sky-500 box-border"
                    />
                  </div>
                  <div>
                    <input
                      type="number"
                      min="0"
                      required
                      placeholder="0"
                      value={bosFormEstCS}
                      onChange={(e) => setBosFormEstCS(e.target.value)}
                      className="w-full h-9 bg-white border border-sky-300 rounded-lg px-2.5 py-1 font-bold text-center text-slate-800 focus:outline-none focus:ring-2 focus:ring-sky-500 box-border"
                    />
                  </div>
                </div>
              </div>

              {/* Job UN & Số lượng */}
              <div className="bg-indigo-50/70 p-3 rounded-xl border border-indigo-200 space-y-2">
                <div className="font-bold text-indigo-900 flex items-center gap-1">
                  <span className="w-2 h-2 rounded-full bg-indigo-500"></span> Job UN
                </div>
                <div>
                  <label className="block text-[11px] font-semibold text-slate-600 mb-0.5">Mã Job UN</label>
                  <input
                    type="text"
                    required
                    placeholder="Mã Job UN..."
                    value={bosFormJobUN}
                    onChange={(e) => setBosFormJobUN(e.target.value)}
                    className="w-full bg-white border border-indigo-300 rounded-lg px-2.5 py-1.5 font-mono font-medium text-slate-800 focus:outline-none focus:ring-2 focus:ring-indigo-500"
                  />
                </div>
                <div className="grid grid-cols-2 gap-x-2 gap-y-1">
                  <label className="text-[11px] font-semibold text-slate-600 flex items-end leading-tight min-h-[24px] sm:min-h-0">
                    Kế hoạch (Plan) UN
                  </label>
                  <label className="text-[11px] font-semibold text-slate-600 flex items-end leading-tight min-h-[24px] sm:min-h-0">
                    Dự kiến (Estimate) UN
                  </label>
                  <div>
                    <input
                      type="number"
                      min="0"
                      required
                      placeholder="0"
                      value={bosFormPlanUN}
                      onChange={(e) => setBosFormPlanUN(e.target.value)}
                      className="w-full h-9 bg-white border border-indigo-300 rounded-lg px-2.5 py-1 font-bold text-center text-slate-800 focus:outline-none focus:ring-2 focus:ring-indigo-500 box-border"
                    />
                  </div>
                  <div>
                    <input
                      type="number"
                      min="0"
                      required
                      placeholder="0"
                      value={bosFormEstUN}
                      onChange={(e) => setBosFormEstUN(e.target.value)}
                      className="w-full h-9 bg-white border border-indigo-300 rounded-lg px-2.5 py-1 font-bold text-center text-slate-800 focus:outline-none focus:ring-2 focus:ring-indigo-500 box-border"
                    />
                  </div>
                </div>
              </div>

              {/* Thông tin phụ trợ: Remark ATT, Reason, Due Date */}
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
                <div>
                  <label className="block text-[11px] font-semibold text-slate-600 mb-0.5">Remark fail ATT</label>
                  <input
                    type="text"
                    value={bosFormRemarkAtt}
                    onChange={(e) => setBosFormRemarkAtt(e.target.value)}
                    className="w-full bg-slate-50 border border-slate-300 rounded-lg px-2.5 py-1.5 text-xs text-slate-800 focus:outline-none focus:ring-2 focus:ring-sky-500"
                  />
                </div>
                <div>
                  <label className="block text-[11px] font-semibold text-slate-600 mb-0.5">Reason</label>
                  <input
                    type="text"
                    value={bosFormReason}
                    onChange={(e) => setBosFormReason(e.target.value)}
                    className="w-full bg-slate-50 border border-slate-300 rounded-lg px-2.5 py-1.5 text-xs text-slate-800 focus:outline-none focus:ring-2 focus:ring-sky-500"
                  />
                </div>
                <div>
                  <label className="block text-[11px] font-semibold text-slate-600 mb-0.5">Due date</label>
                  <input
                    type="text"
                    value={bosFormDueDate}
                    onChange={(e) => setBosFormDueDate(e.target.value)}
                    className="w-full bg-slate-50 border border-slate-300 rounded-lg px-2.5 py-1.5 text-xs text-slate-800 focus:outline-none focus:ring-2 focus:ring-sky-500"
                  />
                </div>
              </div>

              <div className="flex items-center justify-end gap-2 pt-2 border-t border-slate-200">
                <button
                  type="button"
                  onClick={() => setEditingBosLine(null)}
                  className="px-3.5 py-1.5 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-lg font-bold cursor-pointer transition-colors"
                >
                  Hủy
                </button>
                <button
                  type="submit"
                  className="px-4 py-1.5 bg-sky-600 hover:bg-sky-700 text-white rounded-lg font-black cursor-pointer transition-colors shadow-sm flex items-center gap-1.5"
                >
                  <Save className="w-3.5 h-3.5" /> Lưu Kế Hoạch BOS
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
