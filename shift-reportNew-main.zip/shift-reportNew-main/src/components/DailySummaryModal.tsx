import React, { useState, useMemo } from 'react';
import {
  X,
  FileSpreadsheet,
  Copy,
  Printer,
  Calendar,
  CheckCircle2,
  AlertTriangle,
  Settings2,
  Plus,
  ClipboardCopy,
  Sparkles,
  Save,
  RotateCcw
} from 'lucide-react';
import { ShiftReport, DailyLineSummary } from '../types/report';
import {
  generateDailyLineSummaries,
  exportDailySummaryToExcel,
  formatDailySummaryMessage,
  formatDailySummaryTSV,
  parseNumber
} from '../utils/calculations';
import {
  getStoredFactoryLines,
  saveStoredFactoryLines,
  DEFAULT_FACTORY_LINES
} from '../utils/storage';

interface DailySummaryModalProps {
  isOpen: boolean;
  onClose: () => void;
  reports: ShiftReport[];
  selectedDate: string;
  onShowToast: (message: string, isError?: boolean) => void;
  onSaveReport?: (report: ShiftReport) => void;
}

export const DailySummaryModal: React.FC<DailySummaryModalProps> = ({
  isOpen,
  onClose,
  reports,
  selectedDate,
  onShowToast,
  onSaveReport
}) => {
  const [reportDate, setReportDate] = useState<string>(
    selectedDate || new Date().toISOString().split('T')[0]
  );

  // Chỉ lấy theo ca D hoặc N, không lấy cả 2 ca (mặc định theo giờ hiện tại)
  const [shiftFilter, setShiftFilter] = useState<'day' | 'night'>(() => {
    const hour = new Date().getHours();
    return hour >= 20 || hour < 8 ? 'night' : 'day';
  });

  // 2 Tab riêng biệt: BOS (Đầu Ca - Estimate) và EOS (Cuối Ca - Actual)
  const [stageFilter, setStageFilter] = useState<'BOS' | 'EOS'>('BOS');

  // Quản lý giá trị nhập trực tiếp Actual trong tab EOS cho từng dòng (key: `${line}-${jobType}`)
  const [eosActualInputs, setEosActualInputs] = useState<Record<string, string>>({});

  const [factoryLines, setFactoryLines] = useState<string[]>(() => getStoredFactoryLines());
  const [showLineSettings, setShowLineSettings] = useState<boolean>(false);
  const [newLineInput, setNewLineInput] = useState<string>('');
  const [copiedMsg, setCopiedMsg] = useState<boolean>(false);
  const [copiedTsv, setCopiedTsv] = useState<boolean>(false);

  // Sinh danh sách dữ liệu tổng hợp theo ngày, ca và giai đoạn (BOS / EOS)
  // Trong tab EOS: Toàn bộ thông tin đầu ca tự động fill từ BOS, chỉ chừa Actual để người dùng điền vào
  const rawSummaries: DailyLineSummary[] = useMemo(() => {
    return generateDailyLineSummaries(reports, reportDate, shiftFilter, factoryLines, stageFilter);
  }, [reports, reportDate, shiftFilter, factoryLines, stageFilter]);

  // Cập nhật số liệu động nếu người dùng đang nhập Actual trên tab EOS
  const summaries: DailyLineSummary[] = useMemo(() => {
    if (stageFilter !== 'EOS') return rawSummaries;

    return rawSummaries.map((s) => {
      if (!s.hasPlan) return s;
      const key = `${s.line}-${s.jobType || 'ALL'}`;
      if (eosActualInputs[key] !== undefined) {
        const customActual = parseNumber(eosActualInputs[key]);
        const customGap = customActual - s.planOutput;
        return {
          ...s,
          estimateOutput: customActual,
          gap: customGap,
          gapQty: customGap
        };
      }
      return s;
    });
  }, [rawSummaries, eosActualInputs, stageFilter]);

  // Aggregate statistics for running lines and jobs in this shift
  const activeRows = useMemo(() => summaries.filter((s) => s.hasPlan), [summaries]);
  const noPlanRows = useMemo(() => summaries.filter((s) => !s.hasPlan), [summaries]);
  const runningLinesCount = useMemo(() => new Set(activeRows.map((s) => s.line)).size, [activeRows]);
  const totalPlan = useMemo(() => activeRows.reduce((acc, s) => acc + s.planOutput, 0), [activeRows]);
  const totalActual = useMemo(() => activeRows.reduce((acc, s) => acc + s.estimateOutput, 0), [activeRows]);
  const totalGap = totalActual - totalPlan;

  if (!isOpen) return null;

  // Xử lý thay đổi ô nhập Actual trong tab EOS
  const handleActualChange = (line: string, jobType: string | undefined, val: string) => {
    const key = `${line}-${jobType || 'ALL'}`;
    setEosActualInputs((prev) => ({
      ...prev,
      [key]: val
    }));
  };

  // Nạp nhanh mẫu số liệu Actual cho các line đang chờ nhập
  const handleFillSampleEos = () => {
    const newInputs: Record<string, string> = { ...eosActualInputs };
    activeRows.forEach((row) => {
      const key = `${row.line}-${row.jobType || 'ALL'}`;
      if (row.isEosPending || row.estimateOutput === 0) {
        // Mẫu số liệu ngẫu nhiên bám sát Plan
        const offset = Math.floor(Math.random() * 21) - 8; // -8 đến +12
        const sampleVal = Math.max(0, row.planOutput + offset);
        newInputs[key] = String(sampleVal);
      }
    });
    setEosActualInputs(newInputs);
    onShowToast('Đã nạp số liệu Actual mẫu cho các Job cuối ca! Hãy kiểm tra và bấm Lưu.');
  };

  // Lưu báo cáo EOS cho một Line cụ thể
  const handleSaveLineEos = (targetLine: string) => {
    if (!onSaveReport) {
      onShowToast('Không có hàm lưu báo cáo!', true);
      return;
    }

    const lineRows = summaries.filter((s) => s.line === targetLine && s.hasPlan);
    if (lineRows.length === 0) {
      onShowToast(`Line ${targetLine} không có kế hoạch chạy!`, true);
      return;
    }

    // Tìm base report từ BOS
    const baseRep = lineRows[0].rawReport;
    if (!baseRep) {
      onShowToast(`Không tìm thấy dữ liệu BOS nền cho Line ${targetLine}!`, true);
      return;
    }

    // Lấy số lượng Actual cho CS và UN
    const csRow = lineRows.find((r) => r.jobType === 'CS');
    const unRow = lineRows.find((r) => r.jobType === 'UN');
    const singleRow = lineRows.find((r) => r.jobType === 'ALL');

    let csActual = 0;
    let unActual = 0;
    let totalActualOutput = 0;

    if (csRow && unRow) {
      const csKey = `${targetLine}-CS`;
      const unKey = `${targetLine}-UN`;
      csActual = eosActualInputs[csKey] !== undefined ? parseNumber(eosActualInputs[csKey]) : csRow.estimateOutput;
      unActual = eosActualInputs[unKey] !== undefined ? parseNumber(eosActualInputs[unKey]) : unRow.estimateOutput;
      totalActualOutput = csActual + unActual;
    } else if (csRow) {
      const csKey = `${targetLine}-CS`;
      csActual = eosActualInputs[csKey] !== undefined ? parseNumber(eosActualInputs[csKey]) : csRow.estimateOutput;
      totalActualOutput = csActual;
    } else if (unRow) {
      const unKey = `${targetLine}-UN`;
      unActual = eosActualInputs[unKey] !== undefined ? parseNumber(eosActualInputs[unKey]) : unRow.estimateOutput;
      totalActualOutput = unActual;
    } else if (singleRow) {
      const key = `${targetLine}-ALL`;
      totalActualOutput = eosActualInputs[key] !== undefined ? parseNumber(eosActualInputs[key]) : singleRow.estimateOutput;
    }

    // Tính toán STD Hour và EFF cho EOS
    const uphNum = baseRep.uph || 25;
    const planHCCS = baseRep.planHCCS || Math.round(baseRep.planHC / 2);
    const planHCUN = baseRep.planHCUN || (baseRep.planHC - planHCCS);
    const stdCS = uphNum > 0 && planHCCS > 0 && csActual > 0 ? (planHCCS * csActual) / uphNum : 0;
    const stdUN = uphNum > 0 && planHCUN > 0 && unActual > 0 ? (planHCUN * unActual) / uphNum : 0;
    const totalStdNum = stdCS + stdUN > 0 ? stdCS + stdUN : (baseRep.planHC * totalActualOutput) / (uphNum || 1);

    const actualHoursNum = parseNumber(baseRep.actualHours) || 10;
    const actualLineNum = baseRep.routingHC * actualHoursNum;
    const effRate = actualLineNum > 0 ? Math.round((totalStdNum / actualLineNum) * 1000) / 10 : 0;

    const eosReport: ShiftReport = {
      ...baseRep,
      id: `rep-eos-${targetLine}-${Date.now()}`,
      requestId: crypto.randomUUID(),
      reportStage: 'EOS',
      estimateOutputCS: csActual > 0 ? csActual : undefined,
      estimateOutputUN: unActual > 0 ? unActual : undefined,
      estimateOutput: totalActualOutput,
      stdHour: `${totalStdNum.toFixed(1)}h`,
      stdHourCS: stdCS > 0 ? `${stdCS.toFixed(1)}h` : undefined,
      stdHourUN: stdUN > 0 ? `${stdUN.toFixed(1)}h` : undefined,
      actualLine: `${actualLineNum.toFixed(1)}h`,
      effRate,
      note: `Báo cáo cuối ca EOS (Tổng Thực Tế: ${totalActualOutput} pcs).`,
      createdAt: Date.now()
    };

    onSaveReport(eosReport);
    onShowToast(`Đã lưu Báo Cáo EOS Line ${targetLine} (Actual: ${totalActualOutput.toLocaleString()} pcs) thành công!`);
  };

  // Lưu tất cả các line EOS đang có số liệu
  const handleSaveAllEos = () => {
    const uniqueLines = Array.from(new Set(activeRows.map((r) => r.line)));
    if (uniqueLines.length === 0) {
      onShowToast('Không có line nào có kế hoạch để lưu EOS!', true);
      return;
    }

    uniqueLines.forEach((l) => {
      handleSaveLineEos(l);
    });
    onShowToast(`Đã lưu Báo Cáo EOS cho toàn bộ ${uniqueLines.length} chuyền!`);
  };

  const handleExportExcel = () => {
    try {
      const success = exportDailySummaryToExcel(summaries, reportDate, shiftFilter, stageFilter);
      if (success) {
        const shiftText = shiftFilter === 'night' ? 'Ca Đêm (N)' : 'Ca Ngày (D)';
        const stageText = stageFilter === 'EOS' ? 'EOS (Cuối Ca)' : 'BOS (Đầu Ca)';
        onShowToast(`Đã xuất báo cáo ${stageText} ${shiftText} ra file Excel (.xlsx)!`);
      }
    } catch (err) {
      console.error('Export error:', err);
      onShowToast('Có lỗi xảy ra khi xuất file Excel', true);
    }
  };

  const handleCopyTSV = () => {
    try {
      const tsv = formatDailySummaryTSV(summaries, stageFilter);
      navigator.clipboard.writeText(tsv);
      setCopiedTsv(true);
      onShowToast(`Đã chép bảng ${stageFilter === 'EOS' ? 'EOS (Cuối Ca)' : 'BOS (Đầu Ca)'}. Bấm Ctrl+V dán ngay vào Excel / Google Sheets!`);
      setTimeout(() => setCopiedTsv(false), 2500);
    } catch {
      onShowToast('Không thể sao chép bảng, vui lòng thử lại', true);
    }
  };

  const handleCopyMessage = () => {
    try {
      const text = formatDailySummaryMessage(summaries, reportDate, shiftFilter, stageFilter);
      navigator.clipboard.writeText(text);
      setCopiedMsg(true);
      onShowToast(`Đã sao chép tin nhắn báo cáo ${stageFilter === 'EOS' ? 'EOS' : 'BOS'} (Zalo / Teams)!`);
      setTimeout(() => setCopiedMsg(false), 2500);
    } catch {
      onShowToast('Không thể sao chép văn bản, vui lòng thử lại', true);
    }
  };

  const handlePrint = () => {
    window.print();
  };

  const handleAddLine = () => {
    const trimmed = newLineInput.trim().toUpperCase();
    if (!trimmed) return;
    if (factoryLines.includes(trimmed)) {
      onShowToast('Line này đã có trong danh sách!', true);
      return;
    }
    const updated = [...factoryLines, trimmed];
    setFactoryLines(updated);
    saveStoredFactoryLines(updated);
    setNewLineInput('');
    onShowToast(`Đã thêm Line ${trimmed} vào danh sách xưởng!`);
  };

  const handleRemoveLine = (lineToRemove: string) => {
    if (factoryLines.length <= 1) {
      onShowToast('Cần giữ lại ít nhất 1 line!', true);
      return;
    }
    const updated = factoryLines.filter((l) => l !== lineToRemove);
    setFactoryLines(updated);
    saveStoredFactoryLines(updated);
    onShowToast(`Đã xóa Line ${lineToRemove}`);
  };

  const handleResetDefaultLines = () => {
    setFactoryLines(DEFAULT_FACTORY_LINES);
    saveStoredFactoryLines(DEFAULT_FACTORY_LINES);
    onShowToast('Đã khôi phục 6 line mặc định (1323 – 1328)!');
  };

  const shiftLabel = shiftFilter === 'night' ? 'Ca Đêm (Ca N)' : 'Ca Ngày (Ca D)';

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-2 sm:p-4 bg-slate-900/70 backdrop-blur-xs overflow-y-auto">
      <div className="bg-white w-full max-w-7xl rounded-2xl shadow-2xl border border-slate-200 overflow-hidden flex flex-col max-h-[95vh]">
        {/* Modal Top Header */}
        <div className="bg-gradient-to-r from-slate-900 via-sky-950 to-slate-900 text-white px-5 py-3.5 flex flex-col md:flex-row justify-between items-start md:items-center gap-3">
          <div className="flex items-center gap-3">
            <div className="bg-sky-600/90 p-2.5 rounded-xl shadow-inner text-white">
              <FileSpreadsheet className="w-6 h-6" />
            </div>
            <div>
              <div className="flex items-center gap-2 flex-wrap">
                <h2 className="text-base sm:text-lg font-black tracking-tight text-white uppercase">
                  BÁO CÁO SẢN XUẤT CÁC LINE - {shiftLabel.toUpperCase()}
                </h2>
                <span className="text-[10px] bg-amber-500/30 text-amber-200 border border-amber-400/30 px-2 py-0.5 rounded-full font-bold uppercase">
                  6 Line (1323 - 1328)
                </span>
                <span
                  className={`text-[10px] font-black px-2 py-0.5 rounded-md border ${
                    stageFilter === 'EOS'
                      ? 'bg-emerald-500/30 text-emerald-200 border-emerald-400/30'
                      : 'bg-sky-500/30 text-sky-200 border-sky-400/30'
                  }`}
                >
                  {stageFilter === 'EOS' ? '🏁 TAB CUỐI CA (ACTUAL EOS)' : '☀️ TAB ĐẦU CA (BOS - ESTIMATE)'}
                </span>
              </div>
              <p className="text-xs text-slate-300">
                Thứ tự 10 cột chuẩn: <strong>Line, Job theo Plan, Plan, {stageFilter === 'BOS' ? 'Estimate' : 'Actual'}, GAP, Remark fail ATT, Job Pending, Qty GAP tổng, Reason, Due date</strong>
              </p>
            </div>
          </div>

          {/* Action Buttons */}
          <div className="flex items-center gap-2 flex-wrap self-end md:self-center">
            {/* Xuất Excel */}
            <button
              type="button"
              onClick={handleExportExcel}
              className="px-3.5 py-1.5 bg-emerald-600 hover:bg-emerald-500 text-white rounded-lg text-xs font-bold flex items-center gap-1.5 shadow-md transition-all cursor-pointer"
              title="Tải về file Excel (.xlsx) chuẩn format theo ca"
            >
              <FileSpreadsheet className="w-3.5 h-3.5" /> Xuất Excel (.xlsx)
            </button>

            {/* Chép Bảng TSV */}
            <button
              type="button"
              onClick={handleCopyTSV}
              className="px-3 py-1.5 bg-teal-700 hover:bg-teal-600 text-white rounded-lg text-xs font-bold flex items-center gap-1.5 shadow-md transition-all cursor-pointer"
              title="Sao chép bảng định dạng tab để Ctrl+V dán ngay vào Excel / Google Sheets"
            >
              <ClipboardCopy className="w-3.5 h-3.5" /> {copiedTsv ? 'Đã chép bảng!' : 'Chép Dán Excel'}
            </button>

            {/* Chép Tin Nhắn */}
            <button
              type="button"
              onClick={handleCopyMessage}
              className="px-3 py-1.5 bg-sky-700 hover:bg-sky-600 text-white rounded-lg text-xs font-bold flex items-center gap-1.5 shadow-md transition-all cursor-pointer"
              title="Sao chép nội dung tin nhắn gửi Zalo / Teams"
            >
              <Copy className="w-3.5 h-3.5" /> {copiedMsg ? 'Đã chép!' : 'Chép Tin Nhắn'}
            </button>

            {/* Quản lý danh sách Line */}
            <button
              type="button"
              onClick={() => setShowLineSettings(!showLineSettings)}
              className="px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 rounded-lg text-xs font-semibold flex items-center gap-1.5 transition-all cursor-pointer"
              title="Cấu hình danh sách 6 chuyền (1323 – 1328)"
            >
              <Settings2 className="w-3.5 h-3.5 text-amber-400" /> Quản Lý Line
            </button>

            {/* In */}
            <button
              type="button"
              onClick={handlePrint}
              className="px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 rounded-lg text-xs font-semibold flex items-center gap-1.5 transition-all cursor-pointer hidden sm:flex"
              title="In báo cáo"
            >
              <Printer className="w-3.5 h-3.5 text-slate-300" /> In
            </button>

            {/* Close */}
            <button
              type="button"
              onClick={onClose}
              className="text-slate-400 hover:text-white p-1 rounded-lg hover:bg-slate-800 transition-colors ml-1 cursor-pointer"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* 2 TAB RIÊNG BIỆT: BOS (ĐẦU CA - ESTIMATE) & EOS (CUỐI CA - ACTUAL) */}
        <div className="bg-slate-950 p-2.5 border-b border-slate-800 grid grid-cols-2 gap-2.5">
          <button
            type="button"
            onClick={() => setStageFilter('BOS')}
            className={`py-2 px-3 sm:px-4 rounded-xl transition-all cursor-pointer flex items-center justify-between border ${
              stageFilter === 'BOS'
                ? 'bg-gradient-to-r from-sky-600 to-blue-700 text-white border-sky-400 shadow-md font-black ring-2 ring-sky-400/40'
                : 'bg-slate-900/80 hover:bg-slate-800 text-slate-400 hover:text-slate-200 border-slate-800'
            }`}
          >
            <div className="flex items-center gap-2.5 text-left truncate">
              <span className="text-xl">☀️</span>
              <div className="truncate">
                <div className="text-xs sm:text-sm font-black uppercase tracking-wide flex items-center gap-1.5">
                  BOS (Đầu Ca)
                  {stageFilter === 'BOS' && (
                    <span className="w-2 h-2 rounded-full bg-amber-300 animate-pulse shrink-0"></span>
                  )}
                </div>
                <div className="text-[10px] sm:text-xs font-medium opacity-85 truncate">
                  Báo cáo Kế hoạch & Estimate sản lượng
                </div>
              </div>
            </div>
            <span className="text-[11px] px-2 py-0.5 rounded font-mono font-bold bg-black/20 shrink-0 hidden sm:inline-block">
              Estimate
            </span>
          </button>

          <button
            type="button"
            onClick={() => setStageFilter('EOS')}
            className={`py-2 px-3 sm:px-4 rounded-xl transition-all cursor-pointer flex items-center justify-between border ${
              stageFilter === 'EOS'
                ? 'bg-gradient-to-r from-emerald-600 to-teal-700 text-white border-emerald-400 shadow-md font-black ring-2 ring-emerald-400/40'
                : 'bg-slate-900/80 hover:bg-slate-800 text-slate-400 hover:text-slate-200 border-slate-800'
            }`}
          >
            <div className="flex items-center gap-2.5 text-left truncate">
              <span className="text-xl">🏁</span>
              <div className="truncate">
                <div className="text-xs sm:text-sm font-black uppercase tracking-wide flex items-center gap-1.5">
                  Actual EOS (Cuối Ca)
                  {stageFilter === 'EOS' && (
                    <span className="w-2 h-2 rounded-full bg-emerald-300 animate-pulse shrink-0"></span>
                  )}
                </div>
                <div className="text-[10px] sm:text-xs font-medium opacity-85 truncate">
                  Tự fill đầu ca, điền Thực Tế (Actual)
                </div>
              </div>
            </div>
            <span className="text-[11px] px-2 py-0.5 rounded font-mono font-bold bg-black/20 shrink-0 hidden sm:inline-block">
              Actual EOS
            </span>
          </button>
        </div>

        {/* BANNER THÔNG TIN TAB EOS: TỰ ĐỘNG NẠP NỀN TỪ BOS, CHỜ NHẬP ACTUAL */}
        {stageFilter === 'EOS' && (
          <div className="bg-gradient-to-r from-emerald-50 via-teal-50 to-emerald-50 border-b border-emerald-200 px-5 py-2.5 text-xs text-emerald-950 flex flex-wrap items-center justify-between gap-2.5">
            <div className="flex items-center gap-2 max-w-3xl">
              <span className="px-2 py-0.5 rounded bg-emerald-600 text-white font-black text-[10px] uppercase shrink-0 shadow-2xs">
                Tự Động Nạp BOS
              </span>
              <p className="text-[11px] font-medium text-emerald-900 leading-snug">
                Dữ liệu đầu ca (<strong>Kế hoạch, Model, Job CS & UN, Remark ATT, Job Pending, Reason, Due date</strong>) đã được <strong>tự động fill từ BOS</strong>. Bạn chỉ cần <strong>điền Thực Tế (Actual)</strong> cho từng Job rồi bấm <strong>Lưu EOS</strong>!
              </p>
            </div>
            <div className="flex items-center gap-2 shrink-0">
              <button
                type="button"
                onClick={handleFillSampleEos}
                className="px-2.5 py-1 bg-white hover:bg-emerald-100 text-emerald-800 border border-emerald-300 rounded-md text-[11px] font-bold cursor-pointer transition-colors flex items-center gap-1 shadow-2xs"
                title="Điền nhanh số liệu Actual mẫu cho các line"
              >
                <Sparkles className="w-3 h-3 text-emerald-600" /> Điền Mẫu Nhanh
              </button>
              {onSaveReport && (
                <button
                  type="button"
                  onClick={handleSaveAllEos}
                  className="px-3 py-1 bg-emerald-700 hover:bg-emerald-800 text-white rounded-md text-[11px] font-black cursor-pointer transition-colors flex items-center gap-1 shadow-xs"
                  title="Lưu tất cả các dòng EOS đang có số liệu"
                >
                  <Save className="w-3 h-3 text-white" /> Lưu Tất Cả EOS
                </button>
              )}
            </div>
          </div>
        )}

        {/* BANNER THÔNG TIN TAB BOS */}
        {stageFilter === 'BOS' && (
          <div className="bg-sky-50 border-b border-sky-200 px-5 py-2 text-xs text-sky-950 flex items-center justify-between">
            <div className="flex items-center gap-2">
              <span className="px-2 py-0.5 rounded bg-sky-600 text-white font-black text-[10px] uppercase shrink-0 shadow-2xs">
                BOS (Đầu Ca)
              </span>
              <p className="text-[11px] font-medium text-sky-900">
                Báo cáo đầu ca: Thống kê số lượng kế hoạch (Plan) và dự kiến (Estimate) cho từng chuyền và từng Job (CS & UN).
              </p>
            </div>
          </div>
        )}

        {/* Line Settings Panel (Collapsible) */}
        {showLineSettings && (
          <div className="bg-amber-50/95 border-b border-amber-200 px-5 py-3 text-xs text-amber-950">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 mb-2">
              <span className="font-bold flex items-center gap-1.5 text-amber-900">
                <Settings2 className="w-4 h-4 text-amber-700" /> Danh sách chuyền quản lý:
              </span>
              <button
                type="button"
                onClick={handleResetDefaultLines}
                className="text-amber-700 hover:text-amber-900 underline font-semibold text-[11px] cursor-pointer self-start sm:self-auto"
              >
                Khôi phục chuẩn 6 Line (1323 – 1328)
              </button>
            </div>
            <div className="flex flex-wrap items-center gap-1.5 mb-2.5">
              {factoryLines.map((l) => (
                <span
                  key={l}
                  className="inline-flex items-center gap-1 bg-white border border-amber-300 rounded-md px-2 py-0.5 font-bold text-slate-800 text-[11px] shadow-2xs"
                >
                  Line {l}
                  <button
                    type="button"
                    onClick={() => handleRemoveLine(l)}
                    className="text-slate-400 hover:text-rose-600 cursor-pointer ml-0.5"
                    title={`Xóa Line ${l}`}
                  >
                    <X className="w-3 h-3" />
                  </button>
                </span>
              ))}
            </div>
            <div className="flex items-center gap-2 max-w-sm">
              <input
                type="text"
                placeholder="Nhập line mới..."
                value={newLineInput}
                onChange={(e) => setNewLineInput(e.target.value.toUpperCase())}
                onKeyDown={(e) => e.key === 'Enter' && (e.preventDefault(), handleAddLine())}
                className="bg-white border border-amber-300 rounded-lg px-2.5 py-1 text-xs text-slate-800 font-bold focus:outline-none focus:ring-1 focus:ring-amber-500 flex-1"
              />
              <button
                type="button"
                onClick={handleAddLine}
                className="px-2.5 py-1 bg-amber-600 hover:bg-amber-700 text-white rounded-lg font-bold text-xs flex items-center gap-1 cursor-pointer"
              >
                <Plus className="w-3.5 h-3.5" /> Thêm
              </button>
            </div>
          </div>
        )}

        {/* Filter Bar: CHỈ CHỌN CA NGÀY (D) HOẶC CA ĐÊM (N) */}
        <div className="bg-slate-100 border-b border-slate-200 px-5 py-2.5 flex flex-wrap items-center justify-between gap-3">
          <div className="flex flex-wrap items-center gap-3">
            {/* Date Picker */}
            <div className="flex items-center gap-1.5 bg-white border border-slate-300 rounded-lg px-2.5 py-1.5 shadow-2xs">
              <Calendar className="w-3.5 h-3.5 text-sky-600" />
              <span className="text-[11px] font-bold text-slate-600">Ngày:</span>
              <input
                type="date"
                value={reportDate}
                onChange={(e) => setReportDate(e.target.value)}
                className="text-xs font-bold text-slate-800 bg-transparent focus:outline-none cursor-pointer"
              />
            </div>

            {/* Shift Filter: CHỈ 2 CA D HOẶC N, KHÔNG GỘP */}
            <div className="flex items-center gap-1">
              <span className="text-[11px] font-bold text-slate-600 mr-1">Chọn Ca Báo Cáo:</span>
              <div className="inline-flex rounded-lg bg-slate-200/90 p-1 text-xs font-bold shadow-inner">
                <button
                  type="button"
                  onClick={() => setShiftFilter('day')}
                  className={`px-3 py-1.5 rounded-md transition-all cursor-pointer flex items-center gap-1.5 ${
                    shiftFilter === 'day'
                      ? 'bg-amber-500 text-white shadow-xs font-black'
                      : 'text-slate-600 hover:text-slate-900'
                  }`}
                >
                  <span>☀️</span> Ca Ngày (Ca D)
                </button>
                <button
                  type="button"
                  onClick={() => setShiftFilter('night')}
                  className={`px-3 py-1.5 rounded-md transition-all cursor-pointer flex items-center gap-1.5 ${
                    shiftFilter === 'night'
                      ? 'bg-indigo-900 text-white shadow-xs font-black'
                      : 'text-slate-600 hover:text-slate-900'
                  }`}
                >
                  <span>🌙</span> Ca Đêm (Ca N)
                </button>
              </div>
            </div>
          </div>

          {/* Quick Notice */}
          <div className="text-[11px] text-slate-500 flex items-center gap-2">
            <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-md bg-emerald-50 text-emerald-800 border border-emerald-300 font-bold">
              <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" /> {runningLinesCount}/{factoryLines.length} Line Chạy ({activeRows.length} Job)
            </span>
            <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-md bg-slate-200 text-slate-700 font-bold">
              {noPlanRows.length} Line No plan
            </span>
          </div>
        </div>

        {/* KPI Summary Strip */}
        <div className="bg-slate-50 border-b border-slate-200 px-5 py-2.5 grid grid-cols-2 sm:grid-cols-4 gap-2 text-center text-xs">
          <div className="bg-white p-2 rounded-lg border border-slate-200/80 shadow-2xs">
            <div className="text-[10px] text-slate-500 font-semibold uppercase">Ca & Giai Đoạn</div>
            <div className="text-base font-black text-slate-800 flex items-center justify-center gap-1">
              <span>{shiftLabel}</span>
              <span className={`text-[10px] px-1.5 py-0.2 rounded font-bold ${stageFilter === 'EOS' ? 'bg-emerald-100 text-emerald-800' : 'bg-sky-100 text-sky-800'}`}>
                {stageFilter}
              </span>
            </div>
          </div>
          <div className="bg-white p-2 rounded-lg border border-slate-200/80 shadow-2xs">
            <div className="text-[10px] text-slate-500 font-semibold uppercase">Tổng Plan</div>
            <div className="text-base font-black text-sky-900">{totalPlan.toLocaleString()}</div>
          </div>
          <div className="bg-white p-2 rounded-lg border border-slate-200/80 shadow-2xs">
            <div className="text-[10px] text-slate-500 font-semibold uppercase">
              {stageFilter === 'BOS' ? 'Tổng Estimate' : 'Tổng Actual (Thực Tế)'}
            </div>
            <div className={`text-base font-black ${stageFilter === 'EOS' ? 'text-emerald-700' : 'text-indigo-900'}`}>
              {totalActual.toLocaleString()}
            </div>
          </div>
          <div className="bg-white p-2 rounded-lg border border-slate-200/80 shadow-2xs">
            <div className="text-[10px] text-slate-500 font-semibold uppercase">GAP Tổng Ca</div>
            <div
              className={`text-base font-black ${
                totalGap >= 0 ? 'text-emerald-700' : 'text-rose-600'
              }`}
            >
              {totalGap >= 0 ? `+${totalGap.toLocaleString()}` : totalGap.toLocaleString()}
            </div>
          </div>
        </div>

        {/* Main Data Table - CÓ CỘT GAP NẰM GIỮA ACTUAL VÀ REMARK FAIL ATT */}
        <div className="flex-1 overflow-x-auto overflow-y-auto p-4">
          <table className="w-full text-left border-collapse text-xs border border-slate-300 min-w-[1250px]">
            {/* Header: Đúng định dạng 10 cột chuẩn + Thao tác lưu EOS */}
            <thead className="bg-slate-900 text-white font-bold sticky top-0 z-10 text-[11px] tracking-wide">
              <tr>
                <th className="p-3 border-r border-slate-700 w-28 text-center uppercase">Line</th>
                <th className="p-3 border-r border-slate-700 min-w-[260px] uppercase">Job theo Plan</th>
                <th className="p-3 border-r border-slate-700 text-right w-24 uppercase">Plan</th>
                {/* Cột 4: Estimate (BOS) hoặc Actual (EOS) */}
                <th
                  className={`p-3 border-r border-slate-700 text-right w-36 uppercase ${
                    stageFilter === 'EOS' ? 'bg-emerald-950 text-emerald-300' : 'bg-slate-900 text-white'
                  }`}
                >
                  {stageFilter === 'BOS' ? 'Estimate' : 'Actual (EOS)'}
                </th>
                {/* CỘT GAP NẰM GIỮA ACTUAL VÀ REMARK FAIL ATT */}
                <th className="p-3 border-r border-slate-700 text-right w-24 bg-sky-950 text-amber-300 uppercase">
                  GAP
                </th>
                <th className="p-3 border-r border-slate-700 min-w-[180px] uppercase">Remark fail ATT</th>
                <th className="p-3 border-r border-slate-700 min-w-[180px] uppercase">Job Pending</th>
                <th className="p-3 border-r border-slate-700 text-right w-28 bg-slate-800 text-amber-300 uppercase">
                  Qty GAP tổng
                </th>
                <th className="p-3 border-r border-slate-700 min-w-[220px] uppercase">Reason</th>
                <th className="p-3 border-r border-slate-700 w-32 uppercase">Due date</th>
                {stageFilter === 'EOS' && onSaveReport && (
                  <th className="p-3 w-28 text-center uppercase bg-emerald-900 text-white">
                    Thao Tác
                  </th>
                )}
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-200 bg-white">
              {summaries.map((s, idx) => {
                if (!s.hasPlan) {
                  // CÁC LINE KHÔNG CHẠY TRONG CA NÀY -> ĐỂ "No plan"
                  return (
                    <tr
                      key={`no-plan-${s.line}-${idx}`}
                      className="bg-slate-50/80 hover:bg-slate-100/80 transition-colors text-slate-500"
                    >
                      {/* Line */}
                      <td className="p-3 border-r border-slate-200 text-center font-black text-slate-700">
                        <span className="px-2.5 py-1 bg-slate-200 text-slate-700 rounded-md inline-block font-extrabold text-xs">
                          {s.line}
                        </span>
                      </td>

                      {/* Job theo Plan */}
                      <td className="p-3 border-r border-slate-200"></td>

                      {/* Plan */}
                      <td className="p-3 border-r border-slate-200"></td>

                      {/* Actual / Estimate */}
                      <td className="p-3 border-r border-slate-200"></td>

                      {/* GAP (nằm giữa Actual và Remark fail ATT) */}
                      <td className="p-3 border-r border-slate-200 bg-slate-50/40"></td>

                      {/* Remark fail ATT */}
                      <td className="p-3 border-r border-slate-200"></td>

                      {/* Job Pending */}
                      <td className="p-3 border-r border-slate-200 text-center text-slate-400 font-bold">
                        {s.jobPending || '—'}
                      </td>

                      {/* Qty GAP tổng */}
                      <td className="p-3 border-r border-slate-200 bg-slate-50/50"></td>

                      {/* Reason */}
                      <td className="p-3 border-r border-slate-200"></td>

                      {/* Due date */}
                      <td className="p-3 border-r border-slate-200"></td>

                      {stageFilter === 'EOS' && onSaveReport && (
                        <td className="p-3 text-center text-slate-400 italic">
                          —
                        </td>
                      )}
                    </tr>
                  );
                }

                // LINE CÓ BÁO CÁO TRONG CA NÀY
                const isGapPositive = s.gap >= 0;
                const isGapTotalPositive = s.gapQty >= 0;
                const isAttOk = s.attRate >= 95;

                // Giá trị Actual hiển thị (nếu người dùng đang nhập thì lấy từ eosActualInputs)
                const inputKey = `${s.line}-${s.jobType || 'ALL'}`;
                const currentInputValue =
                  eosActualInputs[inputKey] !== undefined
                    ? eosActualInputs[inputKey]
                    : s.estimateOutput > 0
                    ? String(s.estimateOutput)
                    : '';

                return (
                  <tr
                    key={`active-${s.line}-${s.jobType}-${idx}`}
                    className="hover:bg-sky-50/40 transition-colors border-b border-slate-200"
                  >
                    {/* 1. Line */}
                    <td className="p-3 border-r border-slate-200 text-center">
                      <span className="inline-flex items-center gap-1 px-2.5 py-1 bg-sky-100 border border-sky-300 text-sky-950 rounded-md font-black text-xs">
                        {s.line}
                      </span>
                    </td>

                    {/* 2. Job theo Plan */}
                    <td className="p-3 border-r border-slate-200 font-mono text-[11px] text-slate-900 font-medium break-all">
                      <div className="flex items-center gap-1.5 flex-wrap">
                        {s.jobType === 'CS' && (
                          <span className="px-1.5 py-0.5 rounded text-[10px] font-black bg-sky-100 text-sky-800 border border-sky-300 shrink-0">
                            CS
                          </span>
                        )}
                        {s.jobType === 'UN' && (
                          <span className="px-1.5 py-0.5 rounded text-[10px] font-black bg-indigo-100 text-indigo-800 border border-indigo-300 shrink-0">
                            UN
                          </span>
                        )}
                        <span className="font-semibold">{s.jobTheoPlan}</span>
                      </div>
                    </td>

                    {/* 3. Plan */}
                    <td className="p-3 border-r border-slate-200 text-right font-black text-slate-800 text-xs font-mono">
                      {s.planOutput.toLocaleString()}
                    </td>

                    {/* 4. Actual / Estimate (Cho phép nhập trực tiếp trên tab EOS) */}
                    <td className="p-2.5 border-r border-slate-200 text-right font-mono">
                      {stageFilter === 'EOS' ? (
                        <div className="flex items-center justify-end gap-1.5">
                          <input
                            type="number"
                            min="0"
                            placeholder="Điền Actual..."
                            value={currentInputValue}
                            onChange={(e) => handleActualChange(s.line, s.jobType, e.target.value)}
                            className="w-24 bg-white border-2 border-emerald-500 rounded-lg px-2 py-1 text-xs font-black text-right text-emerald-950 focus:outline-none focus:ring-2 focus:ring-emerald-400 shadow-2xs"
                          />
                          {s.isEosPending ? (
                            <span
                              className="text-[9px] bg-amber-100 text-amber-800 border border-amber-300 px-1 py-0.5 rounded font-black shrink-0"
                              title="Tự nạp từ BOS, đang chờ nhập Actual"
                            >
                              Chờ
                            </span>
                          ) : (
                            <span
                              className="text-[9px] bg-emerald-100 text-emerald-800 border border-emerald-300 px-1 py-0.5 rounded font-black shrink-0"
                              title="Đã lưu báo cáo EOS"
                            >
                              ✓
                            </span>
                          )}
                        </div>
                      ) : (
                        <span className="font-black text-sky-900 text-xs">
                          {s.estimateOutput.toLocaleString()}
                        </span>
                      )}
                    </td>

                    {/* 5. GAP (NẰM GIỮA ACTUAL VÀ REMARK FAIL ATT) */}
                    <td className="p-3 border-r border-slate-200 text-right font-mono bg-sky-50/40">
                      <span
                        className={`inline-block px-2.5 py-0.5 rounded font-black text-xs ${
                          isGapPositive
                            ? 'bg-emerald-100 text-emerald-800 border border-emerald-300'
                            : 'bg-rose-100 text-rose-800 border border-rose-300'
                        }`}
                      >
                        {isGapPositive ? `+${s.gap}` : s.gap}
                      </span>
                    </td>

                    {/* 6. Remark fail ATT */}
                    <td className="p-3 border-r border-slate-200 text-[11px]">
                      {isAttOk ? (
                        <span className="text-emerald-700 font-medium flex items-center gap-1">
                          <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600 shrink-0" /> {s.remarkFailAtt}
                        </span>
                      ) : (
                        <span className="text-rose-700 font-bold flex items-center gap-1 bg-rose-50 px-2 py-0.5 rounded border border-rose-200">
                          <AlertTriangle className="w-3.5 h-3.5 text-rose-600 shrink-0" /> {s.remarkFailAtt}
                        </span>
                      )}
                    </td>

                    {/* 7. Job Pending (lấy mã Job CS / UN giống cột Job theo plan) */}
                    <td className="p-3 border-r border-slate-200 font-mono text-[11px] text-slate-900 font-medium break-all">
                      <div className="flex items-center gap-1.5 flex-wrap">
                        {s.jobType === 'CS' && (
                          <span className="px-1.5 py-0.5 rounded text-[10px] font-black bg-sky-100 text-sky-800 border border-sky-300 shrink-0">
                            CS
                          </span>
                        )}
                        {s.jobType === 'UN' && (
                          <span className="px-1.5 py-0.5 rounded text-[10px] font-black bg-indigo-100 text-indigo-800 border border-indigo-300 shrink-0">
                            UN
                          </span>
                        )}
                        <span className="font-semibold">{s.jobPending}</span>
                      </div>
                    </td>

                    {/* 8. Qty GAP tổng */}
                    <td className="p-3 border-r border-slate-200 text-right font-mono">
                      <span
                        className={`inline-block px-2 py-0.5 rounded font-black text-xs ${
                          isGapTotalPositive
                            ? 'bg-emerald-100 text-emerald-800 border border-emerald-300'
                            : 'bg-rose-100 text-rose-800 border border-rose-300'
                        }`}
                      >
                        {isGapTotalPositive ? `+${s.gapQty}` : s.gapQty}
                      </span>
                    </td>

                    {/* 9. Reason */}
                    <td className="p-3 border-r border-slate-200 text-[11px] text-slate-700">
                      {s.reason}
                    </td>

                    {/* 10. Due date */}
                    <td className="p-3 border-r border-slate-200 text-[11px] font-semibold text-slate-700">
                      {s.dueDate}
                    </td>

                    {/* Nút lưu EOS cho Line (khi ở tab EOS) */}
                    {stageFilter === 'EOS' && onSaveReport && (
                      <td className="p-2 text-center">
                        <button
                          type="button"
                          onClick={() => handleSaveLineEos(s.line)}
                          className="px-2.5 py-1 bg-emerald-600 hover:bg-emerald-700 text-white rounded text-[10px] font-bold cursor-pointer transition-colors flex items-center justify-center gap-1 mx-auto shadow-2xs"
                          title={`Lưu báo cáo EOS cho Line ${s.line}`}
                        >
                          <Save className="w-3 h-3" /> Lưu Line
                        </button>
                      </td>
                    )}
                  </tr>
                );
              })}
            </tbody>

            {/* Table Footer: Tổng kết các chỉ số */}
            <tfoot className="bg-slate-900 text-white font-bold sticky bottom-0 text-[11px] border-t-2 border-slate-700">
              <tr>
                <td className="p-3 border-r border-slate-700 text-center font-black">
                  TỔNG CỘNG
                </td>
                <td className="p-3 border-r border-slate-700 text-slate-300 font-medium">
                  {activeRows.length} Job ({runningLinesCount}/{factoryLines.length} Line chạy)
                </td>
                <td className="p-3 border-r border-slate-700 text-right font-black text-sky-400 font-mono text-xs">
                  {totalPlan.toLocaleString()}
                </td>
                <td className="p-3 border-r border-slate-700 text-right font-black text-white font-mono text-xs">
                  {totalActual.toLocaleString()}
                </td>
                {/* Tổng GAP */}
                <td
                  className={`p-3 border-r border-slate-700 text-right font-black font-mono text-xs ${
                    totalGap >= 0 ? 'text-emerald-400' : 'text-rose-400'
                  }`}
                >
                  {totalGap >= 0 ? `+${totalGap.toLocaleString()}` : totalGap.toLocaleString()}
                </td>
                <td className="p-3 border-r border-slate-700 text-slate-400 font-normal">
                  —
                </td>
                <td className="p-3 border-r border-slate-700 text-slate-400 font-normal">
                  —
                </td>
                <td
                  className={`p-3 border-r border-slate-700 text-right font-black font-mono text-xs ${
                    totalGap >= 0 ? 'text-emerald-400' : 'text-rose-400'
                  }`}
                >
                  {totalGap >= 0 ? `+${totalGap.toLocaleString()}` : totalGap.toLocaleString()}
                </td>
                <td className="p-3 border-r border-slate-700 text-slate-400 font-normal">
                  —
                </td>
                <td className="p-3 border-r border-slate-700 text-slate-400 font-normal">
                  —
                </td>
                {stageFilter === 'EOS' && onSaveReport && (
                  <td className="p-3 text-center text-emerald-300 font-bold text-[10px]">
                    EOS
                  </td>
                )}
              </tr>
            </tfoot>
          </table>
        </div>

        {/* Modal Footer Controls */}
        <div className="bg-slate-100 border-t border-slate-200 px-5 py-3 flex flex-wrap items-center justify-between gap-3 text-xs text-slate-600">
          <div className="flex items-center gap-2 flex-wrap">
            <span className="font-bold text-slate-800">
              {stageFilter === 'BOS' ? 'Tab BOS (Đầu Ca):' : 'Tab Actual EOS (Cuối Ca):'}
            </span>
            <span>
              {stageFilter === 'BOS'
                ? `Tổng hợp riêng ${shiftLabel} (CS 1 hàng & UN 1 hàng với số lượng riêng biệt). Cột GAP nằm ngay sau Actual.`
                : `Dữ liệu đầu ca đã tự động fill từ BOS. Điền số lượng Thực Tế (Actual) vào ô và bấm Lưu Line để chốt báo cáo cuối ca.`}
            </span>
          </div>
          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={handleCopyTSV}
              className="px-3 py-1 bg-teal-600 hover:bg-teal-700 text-white rounded font-bold cursor-pointer text-xs flex items-center gap-1 shadow-2xs"
            >
              <ClipboardCopy className="w-3.5 h-3.5" /> Chép Bảng
            </button>
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-1 bg-slate-800 hover:bg-slate-900 text-white rounded font-bold cursor-pointer text-xs shadow-2xs"
            >
              Đóng
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
