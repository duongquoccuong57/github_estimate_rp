export interface DatabricksConfig {
  workspaceUrl: string; // e.g. https://adb-1234567890.azuredatabricks.net
  token: string;        // Personal Access Token (dapi...)
  warehouseId: string;  // SQL Warehouse / Endpoint ID (e.g. 1a2b3c4d5e6f7a8b)
  catalog: string;      // Catalog name (default: 'hive_metastore' or 'main')
  schema: string;       // Schema/Database (default: 'default')
  tableName: string;    // Table name (default: 'production_shift_reports')
  autoSync: boolean;                  // Automatically push to Databricks on save
  useDatabricksAsPrimaryStorage: boolean; // Directly fetch & load data from Databricks table on app open
}

export const DEFAULT_DATABRICKS_CONFIG: DatabricksConfig = {
  workspaceUrl: '',
  token: '',
  warehouseId: '',
  catalog: 'hive_metastore',
  schema: 'default',
  tableName: 'production_shift_reports',
  autoSync: true,
  useDatabricksAsPrimaryStorage: false,
};

export interface DatabricksSyncResult {
  success: boolean;
  message: string;
  statementId?: string;
  details?: unknown;
}
