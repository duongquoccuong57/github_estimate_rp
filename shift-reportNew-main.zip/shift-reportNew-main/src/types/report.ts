export interface ShiftReport {
  id: string | number;
  requestId?: string;
  line: string;
  shiftType: 'day' | 'night';
  reportStage?: 'BOS' | 'EOS'; // BOS: Đầu ca (Estimate), EOS: Cuối ca (Actual)
  totalHC: number;
  leaveAL: number;
  leaveSL: number;
  leaveUP: number;
  leaveUPP: number;
  leaveOther: number;
  totalLeaveHC: number;
  lateHC: number;
  planHC: number;
  planHCCS?: number;
  planHCUN?: number;
  routingHC: number;
  routingHCCS?: number;
  routingHCUN?: number;
  presentHC: number;
  diffHCText: string;
  attRate: number;
  model: string;
  jobCS: string;
  qcLineCS?: number;
  planOutputCS?: number;
  estimateOutputCS?: number;
  jobUN: string;
  qcLineUN?: number;
  planOutputUN?: number;
  estimateOutputUN?: number;
  uph: number;
  stdHour: string;
  stdHourCS?: string;
  stdHourUN?: string;
  actualLine: string;
  planOutput: number;
  estimateOutput: number;
  estimateAtt: string;
  planHours: string;
  actualHours: string;
  lossHours?: number;
  effRate: number;
  effExcludingLoss?: number;
  effIncludingLoss?: number;
  date: string;
  leader: string;
  note: string;
  createdAt: number;
  // Extended fields for Daily Summary format
  remarkFailAtt?: string;
  jobPending?: string;
  reason?: string;
  dueDate?: string;
}

export interface DailyLineSummary {
  line: string;
  hasPlan: boolean;
  shiftType: 'day' | 'night';
  reportStage?: 'BOS' | 'EOS';
  jobType?: 'CS' | 'UN' | 'ALL';
  jobTheoPlan: string;
  model: string;
  jobCS: string;
  jobUN: string;
  planOutput: number;
  planOutputCS?: number;
  planOutputUN?: number;
  estimateOutput: number;
  estimateOutputCS?: number;
  estimateOutputUN?: number;
  gap: number; // GAP = estimateOutput - planOutput (nằm giữa Actual và Remark fail ATT)
  gapQty: number; // Qty GAP tổng
  planHC: number;
  planHCCS?: number;
  planHCUN?: number;
  routingHC: number;
  routingHCCS?: number;
  routingHCUN?: number;
  presentHC: number;
  totalHC: number;
  attRate: number;
  remarkFailAtt: string;
  effRate: number;
  jobPending: string;
  reason: string;
  dueDate: string;
  leader: string;
  note?: string;
  reportId?: string | number;
  isEosPending?: boolean; // True nếu ở tab EOS mà line chưa điền Actual EOS (tự động fill từ BOS)
  bosReportId?: string | number;
  rawReport?: ShiftReport;
}
