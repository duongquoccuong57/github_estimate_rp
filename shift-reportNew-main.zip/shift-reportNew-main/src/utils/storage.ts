import { ShiftReport } from '../types/report';
import { generateSampleReports } from './calculations';

const STORAGE_KEY = 'production_reports_v9';
const PIN_KEY = 'report_admin_pin_v2';
const DEFAULT_PIN = '123456';
const FACTORY_LINES_KEY = 'factory_lines_config_v2';

export const DEFAULT_FACTORY_LINES = [
  '1323',
  '1324',
  '1325',
  '1326',
  '1327',
  '1328'
];

export function getStoredFactoryLines(): string[] {
  try {
    const raw = localStorage.getItem(FACTORY_LINES_KEY);
    if (!raw) return DEFAULT_FACTORY_LINES;
    const parsed = JSON.parse(raw);
    return Array.isArray(parsed) && parsed.length > 0 ? parsed : DEFAULT_FACTORY_LINES;
  } catch {
    return DEFAULT_FACTORY_LINES;
  }
}

export function saveStoredFactoryLines(lines: string[]): void {
  try {
    localStorage.setItem(FACTORY_LINES_KEY, JSON.stringify(lines));
  } catch (e) {
    console.error('Error saving factory lines:', e);
  }
}

export function getStoredReports(): ShiftReport[] {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) {
      // First run: load initial realistic sample data with separated Job CS and Job UN!
      const initial = generateSampleReports();
      localStorage.setItem(STORAGE_KEY, JSON.stringify(initial));
      return initial;
    }
    const parsed = JSON.parse(raw);
    return Array.isArray(parsed) ? parsed : [];
  } catch (e) {
    console.error('Error reading localStorage reports:', e);
    return [];
  }
}

export function saveStoredReports(reports: ShiftReport[]): void {
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(reports));
  } catch (e) {
    console.error('Error saving reports to localStorage:', e);
  }
}

export function getAdminPin(): string {
  try {
    const pin = localStorage.getItem(PIN_KEY);
    return pin && pin.length >= 6 ? pin : DEFAULT_PIN;
  } catch {
    return DEFAULT_PIN;
  }
}

export function saveAdminPin(newPin: string): boolean {
  if (!newPin || newPin.length < 6 || newPin.length > 64) {
    return false;
  }
  try {
    localStorage.setItem(PIN_KEY, newPin);
    return true;
  } catch {
    return false;
  }
}

export function verifyAdminPin(enteredPin: string): boolean {
  const currentPin = getAdminPin();
  return enteredPin.trim() === currentPin;
}
