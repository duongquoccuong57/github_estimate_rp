import { ShiftReport } from '../types/report';
import { DatabricksConfig, DEFAULT_DATABRICKS_CONFIG, DatabricksSyncResult } from '../types/databricks';

const DATABRICKS_CONFIG_KEY = 'databricks_connection_config_v1';

export function getStoredDatabricksConfig(): DatabricksConfig {
  try {
    const raw = localStorage.getItem(DATABRICKS_CONFIG_KEY);
    if (!raw) return DEFAULT_DATABRICKS_CONFIG;
    const parsed = JSON.parse(raw);
    return { ...DEFAULT_DATABRICKS_CONFIG, ...parsed };
  } catch {
    return DEFAULT_DATABRICKS_CONFIG;
  }
}

export function saveStoredDatabricksConfig(config: DatabricksConfig): void {
  try {
    localStorage.setItem(DATABRICKS_CONFIG_KEY, JSON.stringify(config));
  } catch (e) {
    console.error('Failed to save Databricks config:', e);
  }
}

/**
 * Clean workspace URL (strip trailing slashes, remove /#... paths)
 */
function normalizeWorkspaceUrl(url: string): string {
  let cleaned = (url || '').trim();
  if (!cleaned) return '';
  if (!cleaned.startsWith('http://') && !cleaned.startsWith('https://')) {
    cleaned = `https://${cleaned}`;
  }
  return cleaned.replace(/\/+$/, '');
}

/**
 * Execute SQL statement on Databricks via REST API
 * POST /api/2.0/sql/statements
 * Uses server-side proxy route /api/databricks/execute-sql to bypass CORS if available,
 * with direct client fetch as fallback.
 */
export async function executeDatabricksSql(
  config: DatabricksConfig,
  statement: string
): Promise<{ status: 'SUCCESS' | 'FAILED' | 'PENDING'; raw: any; error?: string }> {
  const workspaceUrl = normalizeWorkspaceUrl(config.workspaceUrl);
  if (!workspaceUrl || !config.token || !config.warehouseId) {
    throw new Error('Thiếu thông tin kết nối Databricks (Workspace URL, Token hoặc Warehouse ID)');
  }

  const payload = {
    statement,
    warehouse_id: config.warehouseId.trim(),
    catalog: config.catalog?.trim() || undefined,
    schema: config.schema?.trim() || undefined,
    wait_timeout: '30s',
    on_wait_timeout: 'CONTINUE',
  };

  // Try server proxy first to avoid browser CORS restrictions
  try {
    const proxyRes = await fetch('/api/databricks/execute-sql', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        workspaceUrl,
        token: config.token.trim(),
        ...payload,
      }),
    });

    if (proxyRes.ok) {
      const data = await proxyRes.json();
      const state = data?.status?.state;
      if (state === 'SUCCEEDED') {
        return { status: 'SUCCESS', raw: data };
      }
      if (state === 'FAILED') {
        const errMsg = data?.status?.error?.message || 'Lỗi thực thi SQL trên Databricks';
        return { status: 'FAILED', raw: data, error: errMsg };
      }
      return { status: 'PENDING', raw: data };
    }
  } catch {
    // Proxy not available or failed, try direct REST call
  }

  // Fallback: direct REST call to Databricks
  const targetUrl = `${workspaceUrl}/api/2.0/sql/statements`;
  const res = await fetch(targetUrl, {
    method: 'POST',
    headers: {
      'Authorization': `Bearer ${config.token.trim()}`,
      'Content-Type': 'application/json',
    },
    body: JSON.stringify(payload),
  });

  if (!res.ok) {
    const errText = await res.text();
    let parsedMsg = errText;
    try {
      const errJson = JSON.parse(errText);
      parsedMsg = errJson.message || errJson.error || errText;
    } catch {}
    throw new Error(`Databricks API Error (${res.status}): ${parsedMsg}`);
  }

  const data = await res.json();
  const state = data?.status?.state;
  if (state === 'SUCCEEDED') {
    return { status: 'SUCCESS', raw: data };
  }
  if (state === 'FAILED') {
    const errMsg = data?.status?.error?.message || 'Thực thi SQL thất bại trên Databricks';
    return { status: 'FAILED', raw: data, error: errMsg };
  }
  return { status: 'PENDING', raw: data };
}

/**
 * Test connection to Databricks SQL Warehouse (SELECT 1)
 */
export async function testDatabricksConnection(config: DatabricksConfig): Promise<DatabricksSyncResult> {
  try {
    const res = await executeDatabricksSql(config, 'SELECT 1 AS connection_test, current_timestamp() AS ping_time');
    if (res.status === 'SUCCESS') {
      return {
        success: true,
        message: 'Kết nối Databricks REST API thành công! SQL Warehouse đang hoạt động.',
        details: res.raw,
      };
    }
    return {
      success: false,
      message: res.error || 'Databricks không phản hồi trạng thái SUCCEEDED.',
      details: res.raw,
    };
  } catch (e: any) {
    return {
      success: false,
      message: e.message || 'Không thể kết nối đến Databricks',
    };
  }
}

/**
 * Automatically ensure Delta table exists in Databricks catalog/schema
 */
export async function ensureDatabricksTable(config: DatabricksConfig): Promise<DatabricksSyncResult> {
  const fullTable = `\`${config.catalog || 'hive_metastore'}\`.\`${config.schema || 'default'}\`.\`${config.tableName || 'production_shift_reports'}\``;

  const ddl = `
CREATE TABLE IF NOT EXISTS ${fullTable} (
  id STRING,
  line STRING,
  shift_type STRING,
  report_stage STRING,
  report_date STRING,
  leader STRING,
  model STRING,
  job_cs STRING,
  qc_line_cs DOUBLE,
  plan_output_cs BIGINT,
  estimate_output_cs BIGINT,
  job_un STRING,
  qc_line_un DOUBLE,
  plan_output_un BIGINT,
  estimate_output_un BIGINT,
  plan_output BIGINT,
  estimate_output BIGINT,
  uph DOUBLE,
  std_hour STRING,
  actual_line STRING,
  plan_hours STRING,
  actual_hours STRING,
  total_hc INT,
  present_hc INT,
  plan_hc INT,
  routing_hc INT,
  total_leave_hc INT,
  late_hc INT,
  diff_hc_text STRING,
  att_rate DOUBLE,
  eff_rate DOUBLE,
  eff_excluding_loss DOUBLE,
  eff_including_loss DOUBLE,
  estimate_att STRING,
  remark_fail_att STRING,
  job_pending STRING,
  reason STRING,
  due_date STRING,
  note STRING,
  created_at TIMESTAMP,
  synced_at TIMESTAMP
)
USING DELTA
COMMENT 'Production Line Shift Reports (BOS / EOS) from Milwaukee Plant Leader App';
  `.trim();

  try {
    const res = await executeDatabricksSql(config, ddl);
    if (res.status === 'SUCCESS') {
      return {
        success: true,
        message: `Bảng Delta ${fullTable} đã sẵn sàng trên Databricks!`,
      };
    }
    return {
      success: false,
      message: res.error || 'Không thể tạo bảng Delta trên Databricks',
    };
  } catch (e: any) {
    return {
      success: false,
      message: e.message || 'Lỗi khi khởi tạo bảng Databricks',
    };
  }
}

function escapeSql(val: any): string {
  if (val === null || val === undefined) return 'NULL';
  if (typeof val === 'number') {
    if (isNaN(val) || !isFinite(val)) return 'NULL';
    return String(val);
  }
  if (typeof val === 'boolean') return val ? 'TRUE' : 'FALSE';
  const str = String(val).replace(/'/g, "''").replace(/\\/g, '\\\\');
  return `'${str}'`;
}

/**
 * Push / Upsert a single report or multiple reports to Databricks Delta table via MERGE INTO
 */
export async function syncReportsToDatabricks(
  config: DatabricksConfig,
  reports: ShiftReport[]
): Promise<DatabricksSyncResult> {
  if (!reports || reports.length === 0) {
    return { success: false, message: 'Không có báo cáo nào để đồng bộ.' };
  }

  // Ensure table exists first
  const ensureRes = await ensureDatabricksTable(config);
  if (!ensureRes.success) {
    return ensureRes;
  }

  const fullTable = `\`${config.catalog || 'hive_metastore'}\`.\`${config.schema || 'default'}\`.\`${config.tableName || 'production_shift_reports'}\``;

  // Build rows values for MERGE or INSERT
  // Merge key: line, report_date, shift_type, report_stage
  const rowsValues = reports.map((r) => {
    const reportId = String(r.id || `${r.line}_${r.date}_${r.shiftType}_${r.reportStage || 'BOS'}`);
    const stage = r.reportStage || 'BOS';
    const createdAtIso = r.createdAt ? new Date(r.createdAt).toISOString() : new Date().toISOString();

    return `(
      ${escapeSql(reportId)},
      ${escapeSql(r.line)},
      ${escapeSql(r.shiftType)},
      ${escapeSql(stage)},
      ${escapeSql(r.date)},
      ${escapeSql(r.leader || '')},
      ${escapeSql(r.model || '')},
      ${escapeSql(r.jobCS || '')},
      ${escapeSql(r.qcLineCS ?? null)},
      ${escapeSql(r.planOutputCS ?? null)},
      ${escapeSql(r.estimateOutputCS ?? null)},
      ${escapeSql(r.jobUN || '')},
      ${escapeSql(r.qcLineUN ?? null)},
      ${escapeSql(r.planOutputUN ?? null)},
      ${escapeSql(r.estimateOutputUN ?? null)},
      ${escapeSql(r.planOutput ?? 0)},
      ${escapeSql(r.estimateOutput ?? 0)},
      ${escapeSql(r.uph ?? 0)},
      ${escapeSql(r.stdHour || '')},
      ${escapeSql(r.actualLine || '')},
      ${escapeSql(r.planHours || '')},
      ${escapeSql(r.actualHours || '')},
      ${escapeSql(r.totalHC ?? 0)},
      ${escapeSql(r.presentHC ?? 0)},
      ${escapeSql(r.planHC ?? 0)},
      ${escapeSql(r.routingHC ?? 0)},
      ${escapeSql(r.totalLeaveHC ?? 0)},
      ${escapeSql(r.lateHC ?? 0)},
      ${escapeSql(r.diffHCText || '')},
      ${escapeSql(r.attRate ?? 0)},
      ${escapeSql(r.effRate ?? 0)},
      ${escapeSql(r.effExcludingLoss ?? null)},
      ${escapeSql(r.effIncludingLoss ?? null)},
      ${escapeSql(r.estimateAtt || '')},
      ${escapeSql(r.remarkFailAtt || '')},
      ${escapeSql(r.jobPending || '')},
      ${escapeSql(r.reason || '')},
      ${escapeSql(r.dueDate || '')},
      ${escapeSql(r.note || '')},
      timestamp('${createdAtIso}'),
      current_timestamp()
    )`;
  });

  const mergeSql = `
MERGE INTO ${fullTable} AS target
USING (
  SELECT * FROM (VALUES
    ${rowsValues.join(',\n    ')}
  ) AS src (
    id, line, shift_type, report_stage, report_date, leader, model,
    job_cs, qc_line_cs, plan_output_cs, estimate_output_cs,
    job_un, qc_line_un, plan_output_un, estimate_output_un,
    plan_output, estimate_output, uph, std_hour, actual_line,
    plan_hours, actual_hours, total_hc, present_hc, plan_hc, routing_hc,
    total_leave_hc, late_hc, diff_hc_text, att_rate, eff_rate,
    eff_excluding_loss, eff_including_loss, estimate_att,
    remark_fail_att, job_pending, reason, due_date, note,
    created_at, synced_at
  )
) AS source
ON target.line = source.line
   AND target.report_date = source.report_date
   AND target.shift_type = source.shift_type
   AND target.report_stage = source.report_stage
WHEN MATCHED THEN
  UPDATE SET
    target.id = source.id,
    target.leader = source.leader,
    target.model = source.model,
    target.job_cs = source.job_cs,
    target.qc_line_cs = source.qc_line_cs,
    target.plan_output_cs = source.plan_output_cs,
    target.estimate_output_cs = source.estimate_output_cs,
    target.job_un = source.job_un,
    target.qc_line_un = source.qc_line_un,
    target.plan_output_un = source.plan_output_un,
    target.estimate_output_un = source.estimate_output_un,
    target.plan_output = source.plan_output,
    target.estimate_output = source.estimate_output,
    target.uph = source.uph,
    target.std_hour = source.std_hour,
    target.actual_line = source.actual_line,
    target.plan_hours = source.plan_hours,
    target.actual_hours = source.actual_hours,
    target.total_hc = source.total_hc,
    target.present_hc = source.present_hc,
    target.plan_hc = source.plan_hc,
    target.routing_hc = source.routing_hc,
    target.total_leave_hc = source.total_leave_hc,
    target.late_hc = source.late_hc,
    target.diff_hc_text = source.diff_hc_text,
    target.att_rate = source.att_rate,
    target.eff_rate = source.eff_rate,
    target.eff_excluding_loss = source.eff_excluding_loss,
    target.eff_including_loss = source.eff_including_loss,
    target.estimate_att = source.estimate_att,
    target.remark_fail_att = source.remark_fail_att,
    target.job_pending = source.job_pending,
    target.reason = source.reason,
    target.due_date = source.due_date,
    target.note = source.note,
    target.synced_at = current_timestamp()
WHEN NOT MATCHED THEN
  INSERT (
    id, line, shift_type, report_stage, report_date, leader, model,
    job_cs, qc_line_cs, plan_output_cs, estimate_output_cs,
    job_un, qc_line_un, plan_output_un, estimate_output_un,
    plan_output, estimate_output, uph, std_hour, actual_line,
    plan_hours, actual_hours, total_hc, present_hc, plan_hc, routing_hc,
    total_leave_hc, late_hc, diff_hc_text, att_rate, eff_rate,
    eff_excluding_loss, eff_including_loss, estimate_att,
    remark_fail_att, job_pending, reason, due_date, note,
    created_at, synced_at
  ) VALUES (
    source.id, source.line, source.shift_type, source.report_stage, source.report_date, source.leader, source.model,
    source.job_cs, source.qc_line_cs, source.plan_output_cs, source.estimate_output_cs,
    source.job_un, source.qc_line_un, source.plan_output_un, source.estimate_output_un,
    source.plan_output, source.estimate_output, source.uph, source.std_hour, source.actual_line,
    source.plan_hours, source.actual_hours, source.total_hc, source.present_hc, source.plan_hc, source.routing_hc,
    source.total_leave_hc, source.late_hc, source.diff_hc_text, source.att_rate, source.eff_rate,
    source.eff_excluding_loss, source.eff_including_loss, source.estimate_att,
    source.remark_fail_att, source.job_pending, source.reason, source.due_date, source.note,
    source.created_at, source.synced_at
  );
  `.trim();

  try {
    const res = await executeDatabricksSql(config, mergeSql);
    if (res.status === 'SUCCESS') {
      return {
        success: true,
        message: `Đã đồng bộ thành công ${reports.length} báo cáo lên Databricks Delta Table (${fullTable})!`,
        details: res.raw,
      };
    }
    return {
      success: false,
      message: res.error || 'Đồng bộ Databricks thất bại',
      details: res.raw,
    };
  } catch (e: any) {
    return {
      success: false,
      message: e.message || 'Lỗi khi gửi dữ liệu lên Databricks REST API',
    };
  }
}

/**
 * Query reports directly from Databricks Delta table
 */
export async function fetchReportsFromDatabricks(
  config: DatabricksConfig,
  dateFilter?: string
): Promise<{ success: boolean; reports: ShiftReport[]; message?: string }> {
  const fullTable = `\`${config.catalog || 'hive_metastore'}\`.\`${config.schema || 'default'}\`.\`${config.tableName || 'production_shift_reports'}\``;

  let query = `SELECT * FROM ${fullTable}`;
  if (dateFilter) {
    query += ` WHERE report_date = '${dateFilter.replace(/'/g, "''")}'`;
  }
  query += ` ORDER BY report_date DESC, created_at DESC LIMIT 500`;

  try {
    const res = await executeDatabricksSql(config, query);
    if (res.status !== 'SUCCESS') {
      return { success: false, reports: [], message: res.error || 'Không thể truy vấn dữ liệu từ Databricks' };
    }

    const data = res.raw;
    const columns: Array<{ name: string }> = data?.manifest?.schema?.columns || [];
    const dataArray: Array<Array<any>> = data?.result?.data_array || [];

    if (!dataArray || dataArray.length === 0) {
      return { success: true, reports: [] };
    }

    const colIndexMap: Record<string, number> = {};
    columns.forEach((col, idx) => {
      colIndexMap[col.name.toLowerCase()] = idx;
    });

    const parsedReports: ShiftReport[] = dataArray.map((row) => {
      const getVal = (name: string) => {
        const idx = colIndexMap[name.toLowerCase()];
        return idx !== undefined ? row[idx] : null;
      };

      const id = getVal('id') || `report_${Date.now()}`;
      const line = String(getVal('line') || '1323');
      const shiftType = (getVal('shift_type') || 'day') as 'day' | 'night';
      const reportStage = (getVal('report_stage') || 'BOS') as 'BOS' | 'EOS';
      const date = String(getVal('report_date') || '');
      const leader = String(getVal('leader') || '');
      const model = String(getVal('model') || '');

      const jobCS = String(getVal('job_cs') || '');
      const qcLineCS = getVal('qc_line_cs') !== null ? Number(getVal('qc_line_cs')) : undefined;
      const planOutputCS = getVal('plan_output_cs') !== null ? Number(getVal('plan_output_cs')) : undefined;
      const estimateOutputCS = getVal('estimate_output_cs') !== null ? Number(getVal('estimate_output_cs')) : undefined;

      const jobUN = String(getVal('job_un') || '');
      const qcLineUN = getVal('qc_line_un') !== null ? Number(getVal('qc_line_un')) : undefined;
      const planOutputUN = getVal('plan_output_un') !== null ? Number(getVal('plan_output_un')) : undefined;
      const estimateOutputUN = getVal('estimate_output_un') !== null ? Number(getVal('estimate_output_un')) : undefined;

      const planOutput = Number(getVal('plan_output') || 0);
      const estimateOutput = Number(getVal('estimate_output') || 0);
      const uph = Number(getVal('uph') || 0);
      const stdHour = String(getVal('std_hour') || '');
      const actualLine = String(getVal('actual_line') || '');
      const planHours = String(getVal('plan_hours') || '');
      const actualHours = String(getVal('actual_hours') || '');

      const totalHC = Number(getVal('total_hc') || 0);
      const presentHC = Number(getVal('present_hc') || 0);
      const planHC = Number(getVal('plan_hc') || 0);
      const routingHC = Number(getVal('routing_hc') || 0);
      const totalLeaveHC = Number(getVal('total_leave_hc') || 0);
      const lateHC = Number(getVal('late_hc') || 0);
      const diffHCText = String(getVal('diff_hc_text') || '0');

      const attRate = Number(getVal('att_rate') || 0);
      const effRate = Number(getVal('eff_rate') || 0);
      const effExcludingLoss = getVal('eff_excluding_loss') !== null ? Number(getVal('eff_excluding_loss')) : undefined;
      const effIncludingLoss = getVal('eff_including_loss') !== null ? Number(getVal('eff_including_loss')) : undefined;

      const estimateAtt = String(getVal('estimate_att') || '');
      const remarkFailAtt = String(getVal('remark_fail_att') || '');
      const jobPending = String(getVal('job_pending') || '');
      const reason = String(getVal('reason') || '');
      const dueDate = String(getVal('due_date') || '');
      const note = String(getVal('note') || '');

      const rawCreated = getVal('created_at');
      const createdAt = rawCreated ? new Date(rawCreated).getTime() : Date.now();

      return {
        id,
        line,
        shiftType,
        reportStage,
        date,
        leader,
        model,
        jobCS,
        qcLineCS,
        planOutputCS,
        estimateOutputCS,
        jobUN,
        qcLineUN,
        planOutputUN,
        estimateOutputUN,
        planOutput,
        estimateOutput,
        uph,
        stdHour,
        actualLine,
        planHours,
        actualHours,
        totalHC,
        presentHC,
        planHC,
        routingHC,
        leaveAL: 0,
        leaveSL: 0,
        leaveUP: 0,
        leaveUPP: 0,
        leaveOther: 0,
        totalLeaveHC,
        lateHC,
        diffHCText,
        attRate,
        effRate,
        effExcludingLoss,
        effIncludingLoss,
        estimateAtt,
        remarkFailAtt,
        jobPending,
        reason,
        dueDate,
        note,
        createdAt,
      };
    });

    return { success: true, reports: parsedReports };
  } catch (e: any) {
    return { success: false, reports: [], message: e.message || 'Lỗi kết nối Databricks' };
  }
}

/**
 * Delete a report from Databricks table
 */
export async function deleteReportFromDatabricks(
  config: DatabricksConfig,
  report: ShiftReport
): Promise<DatabricksSyncResult> {
  const fullTable = `\`${config.catalog || 'hive_metastore'}\`.\`${config.schema || 'default'}\`.\`${config.tableName || 'production_shift_reports'}\``;
  const deleteSql = `DELETE FROM ${fullTable} WHERE line = '${report.line}' AND report_date = '${report.date}' AND shift_type = '${report.shiftType}' AND report_stage = '${report.reportStage || 'BOS'}'`;

  try {
    const res = await executeDatabricksSql(config, deleteSql);
    if (res.status === 'SUCCESS') {
      return { success: true, message: `Đã xóa bản ghi trên Databricks!` };
    }
    return { success: false, message: res.error || 'Xóa trên Databricks thất bại' };
  } catch (e: any) {
    return { success: false, message: e.message || 'Lỗi khi xóa dữ liệu trên Databricks' };
  }
}

