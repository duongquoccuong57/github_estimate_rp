import * as XLSX from 'xlsx';
import { ShiftReport, DailyLineSummary } from '../types/report';

export function getSmartShiftDate(): string {
  const now = new Date();
  const hours = now.getHours();
  const target = new Date(now);
  // Manufacturing shift logic: between 0h and 6h AM belongs to the previous day's night shift
  if (hours >= 0 && hours < 6) {
    target.setDate(target.getDate() - 1);
  }
  const year = target.getFullYear();
  const month = String(target.getMonth() + 1).padStart(2, '0');
  const day = String(target.getDate()).padStart(2, '0');
  return `${year}-${month}-${day}`;
}

export function detectShift(lineName: string): { shift: 'day' | 'night'; label: string } {
  const trimmed = lineName.trim().toUpperCase();
  if (trimmed.endsWith('N')) {
    return { shift: 'night', label: '🌙 Ca Đêm (Night)' };
  } else if (trimmed.endsWith('D')) {
    return { shift: 'day', label: '☀️ Ca Ngày (Day)' };
  } else {
    const hours = new Date().getHours();
    const isNight = hours >= 18 || hours < 6;
    return isNight 
      ? { shift: 'night', label: '🌙 Ca Đêm (Night)' } 
      : { shift: 'day', label: '☀️ Ca Ngày (Day)' };
  }
}

export function parseNumber(val: string | number | undefined): number {
  if (val === undefined || val === null || val === '') return 0;
  if (typeof val === 'number') return isNaN(val) ? 0 : val;
  const normalized = String(val).trim().replace(',', '.');
  const n = parseFloat(normalized);
  return isNaN(n) ? 0 : n;
}

export function generateSampleReports(): ShiftReport[] {
  const today = getSmartShiftDate();
  return [
    {
      id: 'sample-1',
      requestId: 'req-sample-1',
      line: '1325N',
      shiftType: 'night',
      reportStage: 'BOS',
      totalHC: 28,
      leaveAL: 1,
      leaveSL: 0,
      leaveUP: 0,
      leaveUPP: 0,
      leaveOther: 0,
      totalLeaveHC: 1,
      lateHC: 0,
      planHC: 25,
      planHCCS: 13,
      planHCUN: 12,
      routingHC: 25,
      routingHCCS: 13,
      routingHCUN: 12,
      presentHC: 27,
      diffHCText: '+2 (Thừa)',
      attRate: 96.4,
      model: 'A465',
      jobCS: 'MP103465020-A2642CS-PC32',
      planOutputCS: 268,
      estimateOutputCS: 285,
      jobUN: 'MP103465020-A2642UN-PC32',
      planOutputUN: 269,
      estimateOutputUN: 285,
      uph: 26,
      stdHour: '274.0h',
      stdHourCS: '142.5h',
      stdHourUN: '131.5h',
      actualLine: '268.8h',
      planOutput: 537,
      estimateOutput: 570,
      estimateAtt: '106.1%',
      planHours: '10.75',
      actualHours: '10.75',
      effRate: 101.9,
      date: today,
      leader: 'Nguyễn Văn Hùng',
      note: 'Dây chuyền vận hành ổn định, không có downtime linh kiện, vượt kế hoạch sản xuất ca.',
      remarkFailAtt: 'Đạt ATT (96.4%)',
      jobPending: 'MP103465020-A2642CS-PC32',
      reason: 'Vượt kế hoạch (+33 pcs), dây chuyền chạy tốt',
      dueDate: 'Đã hoàn thành',
      createdAt: Date.now() - 3600000 * 4
    },
    {
      id: 'sample-2',
      requestId: 'req-sample-2',
      line: '1326N',
      shiftType: 'night',
      reportStage: 'BOS',
      totalHC: 24,
      leaveAL: 2,
      leaveSL: 1,
      leaveUP: 0,
      leaveUPP: 0,
      leaveOther: 0,
      totalLeaveHC: 3,
      lateHC: 1,
      planHC: 22,
      planHCCS: 11,
      planHCUN: 11,
      routingHC: 22,
      routingHCCS: 11,
      routingHCUN: 11,
      presentHC: 21,
      diffHCText: '-1 (Thiếu)',
      attRate: 87.5,
      model: 'B218',
      jobCS: 'MP102218010-B1104CS-PC15',
      planOutputCS: 225,
      estimateOutputCS: 230,
      jobUN: 'MP102218010-B1104UN-PC15',
      planOutputUN: 225,
      estimateOutputUN: 230,
      uph: 22,
      stdHour: '230.0h',
      stdHourCS: '115.0h',
      stdHourUN: '115.0h',
      actualLine: '220.0h',
      planOutput: 450,
      estimateOutput: 460,
      estimateAtt: '102.2%',
      planHours: '10',
      actualHours: '10',
      effRate: 104.5,
      date: today,
      leader: 'Trần Thị Mai',
      note: 'Thiếu 1 HC do nghỉ đột xuất, line hỗ trợ chéo công đoạn dán nhãn.',
      remarkFailAtt: 'Vắng 3 HC (AL:2, SL:1) - ATT 87.5%',
      jobPending: 'MP102218010-B1104CS-PC15',
      reason: 'Thiếu nhân sự, đã mượn hỗ trợ đạt sản lượng',
      dueDate: 'Bù ca sau 18:00',
      createdAt: Date.now() - 3600000 * 2
    },
    {
      id: 'sample-3',
      requestId: 'req-sample-3',
      line: '1324D',
      shiftType: 'day',
      reportStage: 'EOS',
      totalHC: 30,
      leaveAL: 0,
      leaveSL: 0,
      leaveUP: 0,
      leaveUPP: 0,
      leaveOther: 0,
      totalLeaveHC: 0,
      lateHC: 0,
      planHC: 28,
      planHCCS: 14,
      planHCUN: 14,
      routingHC: 28,
      routingHCCS: 14,
      routingHCUN: 14,
      presentHC: 30,
      diffHCText: '+2 (Thừa)',
      attRate: 100,
      model: 'M890-PRO',
      jobCS: 'MP108900010-M8901CS-PC99',
      planOutputCS: 300,
      estimateOutputCS: 310,
      jobUN: 'MP108900010-M8901UN-PC99',
      planOutputUN: 300,
      estimateOutputUN: 315,
      uph: 30,
      stdHour: '291.7h',
      stdHourCS: '144.7h',
      stdHourUN: '147.0h',
      actualLine: '280.0h',
      planOutput: 600,
      estimateOutput: 625,
      estimateAtt: '104.2%',
      planHours: '10',
      actualHours: '10',
      effRate: 104.2,
      date: today,
      leader: 'Lê Minh Tuấn',
      note: 'Chuyên cần 100%, nguyên phụ liệu cấp đều đặn, vượt sản lượng.',
      remarkFailAtt: 'Đạt ATT 100%',
      jobPending: 'MP108900010-M8901CS-PC99',
      reason: 'Cung cấp linh kiện đầy đủ, vận hành tốt',
      dueDate: 'Đúng tiến độ',
      createdAt: Date.now() - 3600000 * 6
    },
    {
      id: 'sample-4',
      requestId: 'req-sample-4',
      line: '1323D',
      shiftType: 'day',
      reportStage: 'BOS',
      totalHC: 26,
      leaveAL: 1,
      leaveSL: 0,
      leaveUP: 1,
      leaveUPP: 0,
      leaveOther: 0,
      totalLeaveHC: 2,
      lateHC: 1,
      planHC: 24,
      planHCCS: 12,
      planHCUN: 12,
      routingHC: 24,
      routingHCCS: 12,
      routingHCUN: 12,
      presentHC: 24,
      diffHCText: '0 (Đủ)',
      attRate: 92.3,
      model: 'K550',
      jobCS: 'MP105550010-K5501CS-PC20',
      planOutputCS: 250,
      estimateOutputCS: 230,
      jobUN: 'MP105550010-K5501UN-PC20',
      planOutputUN: 250,
      estimateOutputUN: 230,
      uph: 25,
      stdHour: '220.8h',
      stdHourCS: '110.4h',
      stdHourUN: '110.4h',
      actualLine: '240.0h',
      planOutput: 500,
      estimateOutput: 460,
      estimateAtt: '92.0%',
      planHours: '10',
      actualHours: '10',
      effRate: 92.0,
      date: today,
      leader: 'Hoàng Văn Đức',
      note: 'Đầu ca: Sự cố máy dán nhãn 45 phút, dự kiến hụt 40 pcs.',
      remarkFailAtt: 'Vắng 2 HC (AL:1, UP:1) - ATT 92.3%',
      jobPending: 'MP105550010-K5501CS-PC20',
      reason: 'Sự cố máy dán nhãn 45p, thiếu linh kiện',
      dueDate: 'Bù 40 pcs vào ca ngày mai',
      createdAt: Date.now() - 3600000 * 8
    },
    {
      id: 'sample-4-eos',
      requestId: 'req-sample-4-eos',
      line: '1323D',
      shiftType: 'day',
      reportStage: 'EOS',
      totalHC: 26,
      leaveAL: 1,
      leaveSL: 0,
      leaveUP: 1,
      leaveUPP: 0,
      leaveOther: 0,
      totalLeaveHC: 2,
      lateHC: 1,
      planHC: 24,
      planHCCS: 12,
      planHCUN: 12,
      routingHC: 24,
      routingHCCS: 12,
      routingHCUN: 12,
      presentHC: 24,
      diffHCText: '0 (Đủ)',
      attRate: 92.3,
      model: 'K550',
      jobCS: 'MP105550010-K5501CS-PC20',
      planOutputCS: 250,
      estimateOutputCS: 245,
      jobUN: 'MP105550010-K5501UN-PC20',
      planOutputUN: 250,
      estimateOutputUN: 242,
      uph: 25,
      stdHour: '233.8h',
      stdHourCS: '117.6h',
      stdHourUN: '116.2h',
      actualLine: '240.0h',
      planOutput: 500,
      estimateOutput: 487,
      estimateAtt: '97.4%',
      planHours: '10',
      actualHours: '10',
      effRate: 97.4,
      date: today,
      leader: 'Hoàng Văn Đức',
      note: 'Cuối ca: Khắc phục sự cố dán nhãn, tăng tốc bù sản lượng đạt 487/500 pcs.',
      remarkFailAtt: 'Vắng 2 HC (AL:1, UP:1) - ATT 92.3%',
      jobPending: 'MP105550010-K5501CS-PC20',
      reason: 'Thiếu 13 pcs do sự cố máy dán nhãn đầu giờ',
      dueDate: 'Bù 13 pcs vào ca ngày mai',
      createdAt: Date.now() - 3600000 * 1
    }
  ];
}

export function generateDailyLineSummaries(
  reports: ShiftReport[],
  targetDate: string,
  shiftFilter: 'day' | 'night',
  factoryLines: string[],
  stageFilter: 'all' | 'BOS' | 'EOS' = 'all'
): DailyLineSummary[] {
  const getLineBase = (str: string) => {
    return str.replace(/^LINE\s*/i, '').replace(/[ND]$/i, '').trim().toUpperCase();
  };

  const dateReports = reports.filter((r) => {
    return !targetDate || r.date === targetDate;
  });

  // Strictly use factoryLines (6 lines: 1323 - 1328)
  const lineList =
    factoryLines && factoryLines.length > 0
      ? factoryLines
      : ['1323', '1324', '1325', '1326', '1327', '1328'];

  const sortedLineBases = Array.from(
    new Set(lineList.map((l) => getLineBase(l)))
  ).sort((a, b) => {
    const na = parseInt(a, 10);
    const nb = parseInt(b, 10);
    if (!isNaN(na) && !isNaN(nb)) return na - nb;
    return a.localeCompare(b);
  });

  const summaries: DailyLineSummary[] = [];

  sortedLineBases.forEach((lineBase) => {
    // Tìm các báo cáo của line này trong ca được chọn
    const lineReports = dateReports.filter((r) => {
      const base = getLineBase(r.line);
      return base === lineBase && r.shiftType === shiftFilter;
    });

    const shiftSuffix = shiftFilter === 'night' ? 'N' : 'D';

    // Xác định báo cáo áp dụng theo stageFilter:
    let repToUse: ShiftReport | null = null;
    let isEosPending = false;
    let bosReportId: string | number | undefined = undefined;

    if (stageFilter === 'BOS') {
      // Tab BOS (Đầu ca / Estimate): lấy báo cáo BOS (hoặc bản ghi đầu tiên nếu không có gán nhãn)
      repToUse = lineReports.find((r) => r.reportStage !== 'EOS') || lineReports[0] || null;
    } else if (stageFilter === 'EOS') {
      // Tab EOS (Cuối ca / Actual):
      // 1. Ưu tiên báo cáo EOS đã lưu trước đó
      const eosReport = lineReports.find((r) => r.reportStage === 'EOS');
      if (eosReport) {
        repToUse = eosReport;
        isEosPending = false;
      } else {
        // 2. Chưa có EOS: TỰ ĐỘNG NẠP DỮ LIỆU ĐẦU CA TỪ BÁO CÁO BOS
        const bosReport = lineReports.find((r) => r.reportStage !== 'EOS') || lineReports[0];
        if (bosReport) {
          repToUse = bosReport;
          isEosPending = true; // Dữ liệu đầu ca tự động fill, ô Actual chờ người dùng điền
          bosReportId = bosReport.id;
        }
      }
    } else {
      // 'all': ưu tiên EOS nếu có, ngược lại BOS
      repToUse = lineReports.find((r) => r.reportStage === 'EOS') || lineReports[0] || null;
    }

    if (!repToUse) {
      // Line không chạy trong ca này -> Các ô để trống, riêng Job Pending để dấu gạch ngang "—"
      summaries.push({
        line: `${lineBase}${shiftSuffix}`,
        hasPlan: false,
        shiftType: shiftFilter,
        reportStage: stageFilter !== 'all' ? stageFilter : undefined,
        jobType: 'ALL',
        jobTheoPlan: '',
        model: '',
        jobCS: '',
        jobUN: '',
        planOutput: 0,
        estimateOutput: 0,
        gap: 0,
        gapQty: 0,
        planHC: 0,
        routingHC: 0,
        presentHC: 0,
        totalHC: 0,
        attRate: 0,
        remarkFailAtt: '',
        effRate: 0,
        jobPending: '—',
        reason: '',
        dueDate: '',
        leader: '—',
        note: ''
      });
    } else {
      const rep = repToUse;
      const effectiveStage = stageFilter !== 'all' ? stageFilter : (rep.reportStage || 'BOS');

      const autoFailAtt =
        rep.attRate < 95
          ? `Vắng ${rep.totalLeaveHC || 0} HC - ATT ${rep.attRate}%`
          : 'Đạt ATT';

      const hasCS = Boolean(
        rep.jobCS ||
          (rep.planOutputCS !== undefined && rep.planOutputCS > 0) ||
          (rep.estimateOutputCS !== undefined && rep.estimateOutputCS > 0)
      );
      const hasUN = Boolean(
        rep.jobUN ||
          (rep.planOutputUN !== undefined && rep.planOutputUN > 0) ||
          (rep.estimateOutputUN !== undefined && rep.estimateOutputUN > 0)
      );

      if (hasCS && hasUN) {
        // CS 1 HÀNG
        const csPlan = rep.planOutputCS ?? (rep.planOutput ? Math.round(rep.planOutput / 2) : 0);
        // Trong tab EOS mà chưa nhập Actual thì để 0 (chờ điền), ngược lại lấy số liệu thực tế
        const csActual = isEosPending
          ? 0
          : (rep.estimateOutputCS ?? (rep.estimateOutput ? Math.round(rep.estimateOutput / 2) : 0));
        const csGap = isEosPending ? 0 - csPlan : csActual - csPlan;
        const csJob = rep.jobCS || 'Job CS';

        summaries.push({
          line: rep.line || `${lineBase}${shiftSuffix}`,
          hasPlan: true,
          shiftType: rep.shiftType,
          reportStage: effectiveStage,
          isEosPending,
          bosReportId,
          rawReport: rep,
          jobType: 'CS',
          jobTheoPlan: csJob,
          model: rep.model,
          jobCS: rep.jobCS,
          jobUN: rep.jobUN,
          planOutput: csPlan,
          estimateOutput: csActual,
          gap: csGap,
          gapQty: csGap,
          planHC: rep.planHCCS ?? Math.round(rep.planHC / 2),
          planHCCS: rep.planHCCS,
          planHCUN: rep.planHCUN,
          routingHC: rep.routingHCCS ?? Math.round(rep.routingHC / 2),
          routingHCCS: rep.routingHCCS,
          routingHCUN: rep.routingHCUN,
          presentHC: rep.presentHC,
          totalHC: rep.totalHC,
          attRate: rep.attRate,
          remarkFailAtt: rep.remarkFailAtt || autoFailAtt,
          effRate: rep.effRate,
          jobPending: csJob, // Lấy Job CS ở cột Job theo plan
          reason:
            rep.reason ||
            (csGap < 0 ? rep.note || 'Hụt sản lượng CS theo kế hoạch' : 'Vận hành ổn định'),
          dueDate: rep.dueDate || (csGap < 0 ? 'Trong ca tới' : 'Đúng tiến độ'),
          leader: rep.leader,
          note: rep.note,
          reportId: isEosPending ? undefined : rep.id
        });

        // UN 1 HÀNG
        const unPlan = rep.planOutputUN ?? (rep.planOutput ? rep.planOutput - csPlan : 0);
        const unActual = isEosPending
          ? 0
          : (rep.estimateOutputUN ?? (rep.estimateOutput ? rep.estimateOutput - csActual : 0));
        const unGap = isEosPending ? 0 - unPlan : unActual - unPlan;
        const unJob = rep.jobUN || 'Job UN';

        summaries.push({
          line: rep.line || `${lineBase}${shiftSuffix}`,
          hasPlan: true,
          shiftType: rep.shiftType,
          reportStage: effectiveStage,
          isEosPending,
          bosReportId,
          rawReport: rep,
          jobType: 'UN',
          jobTheoPlan: unJob,
          model: rep.model,
          jobCS: rep.jobCS,
          jobUN: rep.jobUN,
          planOutput: unPlan,
          estimateOutput: unActual,
          gap: unGap,
          gapQty: unGap,
          planHC: rep.planHCUN ?? (rep.planHC - (rep.planHCCS ?? Math.round(rep.planHC / 2))),
          planHCCS: rep.planHCCS,
          planHCUN: rep.planHCUN,
          routingHC: rep.routingHCUN ?? (rep.routingHC - (rep.routingHCCS ?? Math.round(rep.routingHC / 2))),
          routingHCCS: rep.routingHCCS,
          routingHCUN: rep.routingHCUN,
          presentHC: rep.presentHC,
          totalHC: rep.totalHC,
          attRate: rep.attRate,
          remarkFailAtt: rep.remarkFailAtt || autoFailAtt,
          effRate: rep.effRate,
          jobPending: unJob, // Lấy Job UN ở cột Job theo plan
          reason:
            rep.reason ||
            (unGap < 0 ? rep.note || 'Hụt sản lượng UN theo kế hoạch' : 'Vận hành ổn định'),
          dueDate: rep.dueDate || (unGap < 0 ? 'Trong ca tới' : 'Đúng tiến độ'),
          leader: rep.leader,
          note: rep.note,
          reportId: isEosPending ? undefined : rep.id
        });
      } else if (hasCS) {
        // Chỉ có CS
        const csPlan = rep.planOutputCS ?? rep.planOutput ?? 0;
        const csActual = isEosPending ? 0 : (rep.estimateOutputCS ?? rep.estimateOutput ?? 0);
        const csGap = isEosPending ? 0 - csPlan : csActual - csPlan;
        const csJob = rep.jobCS || 'Job CS';

        summaries.push({
          line: rep.line || `${lineBase}${shiftSuffix}`,
          hasPlan: true,
          shiftType: rep.shiftType,
          reportStage: effectiveStage,
          isEosPending,
          bosReportId,
          rawReport: rep,
          jobType: 'CS',
          jobTheoPlan: csJob,
          model: rep.model,
          jobCS: rep.jobCS,
          jobUN: rep.jobUN,
          planOutput: csPlan,
          estimateOutput: csActual,
          gap: csGap,
          gapQty: csGap,
          planHC: rep.planHCCS ?? rep.planHC ?? 0,
          planHCCS: rep.planHCCS,
          planHCUN: rep.planHCUN,
          routingHC: rep.routingHCCS ?? rep.routingHC ?? 0,
          routingHCCS: rep.routingHCCS,
          routingHCUN: rep.routingHCUN,
          presentHC: rep.presentHC,
          totalHC: rep.totalHC,
          attRate: rep.attRate,
          remarkFailAtt: rep.remarkFailAtt || autoFailAtt,
          effRate: rep.effRate,
          jobPending: csJob, // Lấy Job CS
          reason:
            rep.reason ||
            (csGap < 0 ? rep.note || 'Hụt sản lượng CS' : 'Vận hành ổn định'),
          dueDate: rep.dueDate || (csGap < 0 ? 'Trong ca tới' : 'Đúng tiến độ'),
          leader: rep.leader,
          note: rep.note,
          reportId: isEosPending ? undefined : rep.id
        });
      } else if (hasUN) {
        // Chỉ có UN
        const unPlan = rep.planOutputUN ?? rep.planOutput ?? 0;
        const unActual = isEosPending ? 0 : (rep.estimateOutputUN ?? rep.estimateOutput ?? 0);
        const unGap = isEosPending ? 0 - unPlan : unActual - unPlan;
        const unJob = rep.jobUN || 'Job UN';

        summaries.push({
          line: rep.line || `${lineBase}${shiftSuffix}`,
          hasPlan: true,
          shiftType: rep.shiftType,
          reportStage: effectiveStage,
          isEosPending,
          bosReportId,
          rawReport: rep,
          jobType: 'UN',
          jobTheoPlan: unJob,
          model: rep.model,
          jobCS: rep.jobCS,
          jobUN: rep.jobUN,
          planOutput: unPlan,
          estimateOutput: unActual,
          gap: unGap,
          gapQty: unGap,
          planHC: rep.planHCUN ?? rep.planHC ?? 0,
          planHCCS: rep.planHCCS,
          planHCUN: rep.planHCUN,
          routingHC: rep.routingHCUN ?? rep.routingHC ?? 0,
          routingHCCS: rep.routingHCCS,
          routingHCUN: rep.routingHCUN,
          presentHC: rep.presentHC,
          totalHC: rep.totalHC,
          attRate: rep.attRate,
          remarkFailAtt: rep.remarkFailAtt || autoFailAtt,
          effRate: rep.effRate,
          jobPending: unJob, // Lấy Job UN
          reason:
            rep.reason ||
            (unGap < 0 ? rep.note || 'Hụt sản lượng UN' : 'Vận hành ổn định'),
          dueDate: rep.dueDate || (unGap < 0 ? 'Trong ca tới' : 'Đúng tiến độ'),
          leader: rep.leader,
          note: rep.note,
          reportId: isEosPending ? undefined : rep.id
        });
      } else {
        // Không nhập CS/UN -> Dùng Model
        const gap = isEosPending ? 0 - rep.planOutput : rep.estimateOutput - rep.planOutput;
        const modelJob = rep.model || 'Job Chung';
        summaries.push({
          line: rep.line || `${lineBase}${shiftSuffix}`,
          hasPlan: true,
          shiftType: rep.shiftType,
          reportStage: effectiveStage,
          isEosPending,
          bosReportId,
          rawReport: rep,
          jobType: 'ALL',
          jobTheoPlan: modelJob,
          model: rep.model,
          jobCS: rep.jobCS,
          jobUN: rep.jobUN,
          planOutput: rep.planOutput,
          estimateOutput: isEosPending ? 0 : rep.estimateOutput,
          gap: gap,
          gapQty: gap,
          planHC: rep.planHC,
          routingHC: rep.routingHC,
          presentHC: rep.presentHC,
          totalHC: rep.totalHC,
          attRate: rep.attRate,
          remarkFailAtt: rep.remarkFailAtt || autoFailAtt,
          effRate: rep.effRate,
          jobPending: modelJob, // Lấy Job chung
          reason:
            rep.reason ||
            (gap < 0 ? rep.note || 'Hụt sản lượng theo kế hoạch' : 'Vận hành ổn định'),
          dueDate: rep.dueDate || (gap < 0 ? 'Trong ca tới' : 'Đúng tiến độ'),
          leader: rep.leader,
          note: rep.note,
          reportId: isEosPending ? undefined : rep.id
        });
      }
    }
  });

  return summaries;
}

/**
 * Xuất dữ liệu theo đúng chuẩn 10 cột:
 * Line, Job theo Plan, Plan, Actual, GAP, Remark fail ATT, Job Pending, Qty GAP tổng, Reason, Due date
 * (CS 1 hàng, UN 1 hàng, số lượng riêng từng Job)
 */
export function exportDailySummaryToExcel(
  summaries: DailyLineSummary[],
  targetDate: string,
  shiftFilter: 'day' | 'night',
  stageFilter: 'all' | 'BOS' | 'EOS' = 'all'
) {
  if (!summaries || summaries.length === 0) return false;

  const shiftLabel = shiftFilter === 'night' ? 'Ca Đêm (N)' : 'Ca Ngày (D)';
  const stageLabel =
    stageFilter === 'EOS'
      ? ' - EOS (CUỐI CA / ACTUAL)'
      : stageFilter === 'BOS'
      ? ' - BOS (ĐẦU CA / ESTIMATE)'
      : '';

  const actualHeader = stageFilter === 'BOS' ? 'Estimate' : 'Actual';

  // 10 Cột chuẩn (có cột GAP nằm giữa Actual và Remark fail ATT)
  const headers = [
    'Line',
    'Job theo Plan',
    'Plan',
    actualHeader,
    'GAP',
    'Remark fail ATT',
    'Job Pending',
    'Qty GAP tổng',
    'Reason',
    'Due date'
  ];

  const rows: (string | number)[][] = [
    [`BÁO CÁO SẢN XUẤT CÁC LINE${stageLabel} - ${shiftLabel.toUpperCase()} - NGÀY ${targetDate}`],
    [],
    headers
  ];

  let totalPlan = 0;
  let totalActual = 0;
  let totalGap = 0;
  let activeCount = 0;
  const activeLines = new Set<string>();

  summaries.forEach((s) => {
    if (s.hasPlan) {
      totalPlan += s.planOutput;
      totalActual += s.estimateOutput;
      totalGap += s.gap;
      activeCount++;
      activeLines.add(s.line);

      rows.push([
        s.line,
        s.jobTheoPlan,
        s.planOutput,
        s.estimateOutput,
        s.gap,
        s.remarkFailAtt,
        s.jobPending,
        s.gapQty,
        s.reason,
        s.dueDate
      ]);
    } else {
      // Các line không chạy trong ca này -> để trống, riêng Job Pending để dấu gạch ngang "—"
      rows.push([
        s.line,
        '',
        '',
        '',
        '',
        '',
        '—',
        '',
        '',
        ''
      ]);
    }
  });

  // Hàng tổng kết ở cuối (chỉ tính các line có chạy)
  if (activeCount > 0) {
    rows.push([
      'Tổng',
      `${activeCount} Job (${activeLines.size} Line chạy)`,
      totalPlan,
      totalActual,
      totalGap,
      '',
      '',
      totalGap,
      '',
      ''
    ]);
  }

  const wb = XLSX.utils.book_new();
  const ws = XLSX.utils.aoa_to_sheet(rows);

  // Cấu hình độ rộng các cột chuẩn
  ws['!cols'] = [
    { wch: 12 }, // Line
    { wch: 38 }, // Job theo Plan
    { wch: 14 }, // Plan
    { wch: 14 }, // Actual / Estimate
    { wch: 14 }, // GAP (nằm giữa Actual và Remark fail ATT)
    { wch: 32 }, // Remark fail ATT
    { wch: 28 }, // Job Pending
    { wch: 16 }, // Qty GAP tổng
    { wch: 38 }, // Reason
    { wch: 22 }  // Due date
  ];

  const stageFileTag = stageFilter === 'EOS' ? '_EOS' : stageFilter === 'BOS' ? '_BOS' : '';
  const sheetName = shiftFilter === 'night' ? 'Ca_Dem_N' : 'Ca_Ngay_D';
  XLSX.utils.book_append_sheet(wb, ws, `${sheetName}${stageFileTag}`);
  XLSX.writeFile(wb, `Bao_Cao${stageFileTag}_${sheetName}_${targetDate}.xlsx`);
  return true;
}

/**
 * Xuất dữ liệu ra chuỗi Tab-Separated (TSV) để paste thẳng vào Excel/Sheets
 */
export function formatDailySummaryTSV(
  summaries: DailyLineSummary[],
  stageFilter: 'all' | 'BOS' | 'EOS' = 'all'
): string {
  const actualHeader = stageFilter === 'BOS' ? 'Estimate' : 'Actual';
  const headers = [
    'Line',
    'Job theo Plan',
    'Plan',
    actualHeader,
    'GAP',
    'Remark fail ATT',
    'Job Pending',
    'Qty GAP tổng',
    'Reason',
    'Due date'
  ];

  const lines = [headers.join('\t')];

  summaries.forEach((s) => {
    if (s.hasPlan) {
      lines.push(
        [
          s.line,
          s.jobTheoPlan,
          s.planOutput,
          s.estimateOutput,
          s.gap,
          s.remarkFailAtt,
          s.jobPending,
          s.gapQty,
          s.reason,
          s.dueDate
        ].join('\t')
      );
    } else {
      lines.push(
        [s.line, '', '', '', '', '', '—', '', '', ''].join('\t')
      );
    }
  });

  return lines.join('\n');
}

/**
 * Format chuỗi tin nhắn Zalo/Teams
 */
export function formatDailySummaryMessage(
  summaries: DailyLineSummary[],
  targetDate: string,
  shiftFilter: 'day' | 'night',
  stageFilter: 'all' | 'BOS' | 'EOS' = 'all'
): string {
  const shiftText = shiftFilter === 'night' ? '🌙 Ca Đêm (Ca N)' : '☀️ Ca Ngày (Ca D)';
  const stageText =
    stageFilter === 'EOS'
      ? '🏁 BÁO CÁO EOS (CUỐI CA / ACTUAL)'
      : stageFilter === 'BOS'
      ? '☀️ BÁO CÁO BOS (ĐẦU CA / ESTIMATE)'
      : '📋 BÁO CÁO SẢN XUẤT CÁC LINE (1323 - 1328)';

  const activeRows = summaries.filter((s) => s.hasPlan);
  const activeLinesSet = new Set(activeRows.map((s) => s.line));
  const totalPlan = activeRows.reduce((sum, s) => sum + s.planOutput, 0);
  const totalActual = activeRows.reduce((sum, s) => sum + s.estimateOutput, 0);
  const totalGap = totalActual - totalPlan;
  const col4Label = stageFilter === 'BOS' ? 'Estimate' : 'Actual';

  let msg = `${stageText}
📅 Ngày: ${targetDate} | Ca: ${shiftText}
🏭 Tình trạng: ${activeLinesSet.size} Line chạy (${activeRows.length} Job)
---------------------------------------`;

  summaries.forEach((s) => {
    if (s.hasPlan) {
      const gapSign = s.gap >= 0 ? `+${s.gap}` : `${s.gap}`;
      const gapTotalSign = s.gapQty >= 0 ? `+${s.gapQty}` : `${s.gapQty}`;
      const jobTag = s.jobType && s.jobType !== 'ALL' ? `[${s.jobType}] ` : '';
      msg += `\n\n🔹 Line: ${s.line} (${jobTag}Job: ${s.jobTheoPlan})
• Plan: ${s.planOutput.toLocaleString()}
• ${col4Label}: ${s.estimateOutput.toLocaleString()}
• GAP: ${gapSign}
• Remark fail ATT: ${s.remarkFailAtt}
• Job Pending: ${s.jobPending}
• Qty GAP tổng: ${gapTotalSign}
• Reason: ${s.reason}
• Due date: ${s.dueDate}`;
    } else {
      msg += `\n\n🔸 Line: ${s.line} (Không có kế hoạch chạy)`;
    }
  });

  if (activeRows.length > 0) {
    const gapSign = totalGap >= 0 ? `+${totalGap}` : `${totalGap}`;
    msg += `\n\n---------------------------------------
📊 TỔNG KẾT:
• Tổng Kế Hoạch: ${totalPlan.toLocaleString()}
• Tổng ${col4Label}: ${totalActual.toLocaleString()}
• GAP Toàn Ca: ${gapSign}`;
  }

  return msg;
}

export function exportReportsToCSV(reports: ShiftReport[]) {
  if (!reports || reports.length === 0) return false;

  let csvContent = '\uFEFFLine,Ngày,Ca,Giai Đoạn,Leader,Model,Job CS,Kế Hoạch CS,Actual/Estimate CS,Job UN,Kế Hoạch UN,Actual/Estimate UN,Tổng Kế Hoạch,Tổng Thực Tế/Estimate,UPH,STD CS,STD UN,Tổng STD Hour,Actual Line,Tổng HC,Vắng (AL),Vắng (SL),Vắng (UP),Vắng (UPP),Vắng (Khác),Tổng Vắng,Vào Trễ,Plan CS,Plan UN,Tổng HC Plan,Routing CS,Routing UN,Tổng HC Routing,Hiện Diện,Thiếu/Đủ,Attendance (%),Estimate ATT (%),Giờ Plan,Giờ Thực Tế,Eff (%),Remark Fail ATT,Job Pending,Reason,Due Date,Ghi Chú\n';

  reports.forEach((r) => {
    const stageText = r.reportStage === 'EOS' ? 'EOS (Cuối Ca)' : 'BOS (Đầu Ca)';
    const cells = [
      r.line,
      r.date,
      r.shiftType === 'night' ? 'Ca Đêm' : 'Ca Ngày',
      stageText,
      r.leader,
      r.model,
      r.jobCS,
      r.planOutputCS !== undefined ? r.planOutputCS : '',
      r.estimateOutputCS !== undefined ? r.estimateOutputCS : '',
      r.jobUN,
      r.planOutputUN !== undefined ? r.planOutputUN : '',
      r.estimateOutputUN !== undefined ? r.estimateOutputUN : '',
      r.planOutput,
      r.estimateOutput,
      r.uph || 0,
      r.stdHourCS || '',
      r.stdHourUN || '',
      r.stdHour || '',
      r.actualLine || '',
      r.totalHC,
      r.leaveAL || 0,
      r.leaveSL || 0,
      r.leaveUP || 0,
      r.leaveUPP || 0,
      r.leaveOther || 0,
      r.totalLeaveHC || 0,
      r.lateHC || 0,
      r.planHCCS !== undefined ? r.planHCCS : '',
      r.planHCUN !== undefined ? r.planHCUN : '',
      r.planHC,
      r.routingHCCS !== undefined ? r.routingHCCS : '',
      r.routingHCUN !== undefined ? r.routingHCUN : '',
      r.routingHC,
      r.presentHC,
      r.diffHCText,
      r.attRate,
      r.estimateAtt || '0%',
      r.planHours,
      r.actualHours || '',
      r.effRate,
      r.remarkFailAtt || '',
      r.jobPending || '',
      r.reason || '',
      r.dueDate || '',
      r.note || ''
    ];

    csvContent +=
      cells
        .map((value) => {
          let text = String(value ?? '');
          // Anti-CSV formula injection prevention
          if (/^[\s]*[=+\-@]/.test(text)) text = "'" + text;
          return '"' + text.replace(/"/g, '""') + '"';
        })
        .join(',') + '\n';
  });

  const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = `Bao_Cao_San_Xuat_${getSmartShiftDate()}.csv`;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  URL.revokeObjectURL(url);
  return true;
}

export function formatZaloMessage(r: ShiftReport): string {
  const shiftText = r.shiftType === 'night' ? '🌙 CA ĐÊM (Night)' : '☀️ CA NGÀY (Day)';
  
  const csDetail = r.planOutputCS !== undefined || r.estimateOutputCS !== undefined
    ? ` [Kế hoạch: ${(r.planOutputCS || 0).toLocaleString()} | Estimate: ${(r.estimateOutputCS || 0).toLocaleString()}]`
    : '';

  const unDetail = r.planOutputUN !== undefined || r.estimateOutputUN !== undefined
    ? ` [Kế hoạch: ${(r.planOutputUN || 0).toLocaleString()} | Estimate: ${(r.estimateOutputUN || 0).toLocaleString()}]`
    : '';

  const planDetail = r.planHCCS !== undefined || r.planHCUN !== undefined
    ? ` (CS: ${r.planHCCS || 0}, UN: ${r.planHCUN || 0})`
    : '';

  const routingDetail = r.routingHCCS !== undefined || r.routingHCUN !== undefined
    ? ` (CS: ${r.routingHCCS || 0}, UN: ${r.routingHCUN || 0})`
    : '';

  const stdDetail = r.stdHourCS || r.stdHourUN
    ? ` (CS: ${r.stdHourCS || '0h'} + UN: ${r.stdHourUN || '0h'})`
    : '';

  return `📌 BÁO CÁO CA SẢN XUẤT (${r.date} - ${shiftText})
👤 Leader: ${r.leader}
🏭 Line: ${r.line} | Model: ${r.model}

📦 CHI TIẾT SẢN LƯỢNG THEO JOB:
- Job CS: ${r.jobCS}${csDetail}
- Job UN: ${r.jobUN}${unDetail}
-> TỔNG CA: Kế hoạch: ${r.planOutput.toLocaleString()} | Estimate: ${r.estimateOutput.toLocaleString()} (${r.estimateAtt})

👥 ĐIỂM DANH NHÂN SỰ (HC):
- Tổng HC: ${r.totalHC} | Hiện diện: ${r.presentHC}
- Vắng: ${r.totalLeaveHC} (AL:${r.leaveAL}, SL:${r.leaveSL}, UP:${r.leaveUP}, UPP:${r.leaveUPP}, Khác:${r.leaveOther})
- Vào trễ: ${r.lateHC}
- HC Plan: ${r.planHC}${planDetail} | Routing: ${r.routingHC}${routingDetail} -> So sánh: ${r.diffHCText}
- Attendance: ${r.attRate}%

📊 HIỆU SUẤT & THỜI GIAN:
- UPH: ${r.uph} | Giờ Plan: ${r.planHours}h ${r.actualHours ? `| Giờ TT: ${r.actualHours}h` : ''}
- STD Hour: ${r.stdHour}${stdDetail} | Actual Line: ${r.actualLine}
- EFF Đạt: ${r.effRate}% ${r.effRate >= 105 ? '✅ (Đạt chỉ tiêu)' : '⚠️ (Chưa đạt)'}

💬 Ghi chú: ${r.note || 'Không có ghi chú thêm.'}`;
}
