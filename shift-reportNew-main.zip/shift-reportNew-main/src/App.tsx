/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import {
  Shield,
  Trash2,
  CheckCircle2,
  AlertTriangle,
  PenSquare,
  FileSpreadsheet,
  History,
  Lock,
  KeyRound,
  LogOut,
  Database
} from 'lucide-react';
import { ShiftReport } from './types/report';
import {
  getStoredReports,
  saveStoredReports
} from './utils/storage';
import { getSmartShiftDate } from './utils/calculations';
import { DatabricksConfig } from './types/databricks';
import {
  getStoredDatabricksConfig,
  saveStoredDatabricksConfig,
  syncReportsToDatabricks
} from './utils/databricks';
import { ReportForm } from './components/ReportForm';
import { MainReportView } from './components/MainReportView';
import { ReportTable } from './components/ReportTable';
import { ZaloModal } from './components/ZaloModal';
import { PinModal } from './components/PinModal';
import { ChangePinModal } from './components/ChangePinModal';
import { DatabricksModal } from './components/DatabricksModal';
import milwaukeeLogo from './assets/milwaukee-logo.svg';

export default function App() {
  const [reports, setReports] = useState<ShiftReport[]>([]);
  const [selectedDate, setSelectedDate] = useState<string>(getSmartShiftDate());

  // 3 Tab điều hướng chính (Toàn màn hình, KHÔNG chia đôi nửa trên nửa dưới):
  // 1. 'form': Bản Nhập Dữ Liệu & Tính Toán Ca (BOS / EOS)
  // 2. 'summary': Báo Cáo Sản Xuất 6 Chuyền (Tab BOS & Tab EOS chuẩn 10 cột)
  // 3. 'history': Nhật Ký Báo Cáo Đã Lưu
  const [activeMainTab, setActiveMainTab] = useState<'form' | 'summary' | 'history'>('form');

  // Trạng thái Quản Trị Viên (Admin) - chỉ Admin mới thấy và đổi mã PIN
  const [isAdmin, setIsAdmin] = useState<boolean>(() => {
    try {
      return sessionStorage.getItem('shift_app_is_admin') === 'true';
    } catch {
      return false;
    }
  });

  // Quản lý line và stage được truyền vào Form khi bấm "Sửa / Bảng tính" từ bảng 6 chuyền hoặc nhật ký
  const [formInitialLine, setFormInitialLine] = useState<string | undefined>(undefined);
  const [formInitialStage, setFormInitialStage] = useState<'BOS' | 'EOS'>('BOS');

  // Modals state
  const [isPinModalOpen, setIsPinModalOpen] = useState(false);
  const [pinAction, setPinAction] = useState<(() => void) | null>(null);
  const [pinModalTitle, setPinModalTitle] = useState('Xác Nhận Quyền Admin');
  const [pinModalDesc, setPinModalDesc] = useState('Vui lòng nhập mã PIN quản trị để tiếp tục.');

  const [isChangePinOpen, setIsChangePinOpen] = useState(false);
  const [isDatabricksModalOpen, setIsDatabricksModalOpen] = useState(false);
  const [databricksConfig, setDatabricksConfig] = useState<DatabricksConfig>(() => getStoredDatabricksConfig());
  const [isDatabricksLoading, setIsDatabricksLoading] = useState(false);
  const [zaloReport, setZaloReport] = useState<ShiftReport | null>(null);

  // Toast state
  const [toast, setToast] = useState<{ message: string; isError?: boolean } | null>(null);

  const showToast = (message: string, isError = false) => {
    setToast({ message, isError });
    setTimeout(() => {
      setToast(null);
    }, 3500);
  };

  // Tải dữ liệu: Ưu tiên tải từ Databricks Database nếu cấu hình useDatabricksAsPrimaryStorage = true
  const loadReportsData = async (cfg: DatabricksConfig) => {
    const local = getStoredReports();
    setReports(local);

    if (
      cfg.useDatabricksAsPrimaryStorage &&
      cfg.workspaceUrl &&
      cfg.token &&
      cfg.warehouseId
    ) {
      setIsDatabricksLoading(true);
      try {
        const { fetchReportsFromDatabricks } = await import('./utils/databricks');
        const res = await fetchReportsFromDatabricks(cfg);
        if (res.success) {
          if (res.reports.length > 0) {
            setReports(res.reports);
            saveStoredReports(res.reports); // Cache local for offline resilience
            showToast(`[Databricks Cloud] Đã tải ${res.reports.length} báo cáo từ Delta Table!`);
          } else {
            showToast('[Databricks Cloud] Kết nối thành công (Bảng hiện chưa có dữ liệu).');
          }
        } else {
          showToast(`[Databricks] Không thể tải dữ liệu: ${res.message || 'Lỗi kết nối'}`, true);
        }
      } catch (err: any) {
        console.error('Error fetching Databricks reports:', err);
      } finally {
        setIsDatabricksLoading(false);
      }
    }
  };

  // Load on mount
  useEffect(() => {
    loadReportsData(databricksConfig);
  }, []);

  const handleSaveReport = (newReport: ShiftReport) => {
    // Nếu báo cáo cùng Line, ngày, ca và giai đoạn (BOS/EOS) đã tồn tại thì cập nhật đè lên, ngược lại thêm mới
    const existingIndex = reports.findIndex(
      (r) =>
        r.line.toUpperCase() === newReport.line.toUpperCase() &&
        r.date === newReport.date &&
        r.shiftType === newReport.shiftType &&
        (r.reportStage || 'BOS') === (newReport.reportStage || 'BOS')
    );

    let updated: ShiftReport[];
    if (existingIndex >= 0) {
      updated = [...reports];
      updated[existingIndex] = { ...updated[existingIndex], ...newReport };
    } else {
      updated = [newReport, ...reports];
    }

    setReports(updated);
    saveStoredReports(updated);

    // Auto-sync hoặc lưu trực tiếp lên Databricks Database
    if (
      (databricksConfig.autoSync || databricksConfig.useDatabricksAsPrimaryStorage) &&
      databricksConfig.workspaceUrl &&
      databricksConfig.token &&
      databricksConfig.warehouseId
    ) {
      syncReportsToDatabricks(databricksConfig, [newReport])
        .then((res) => {
          if (res.success) {
            showToast(`☁️ [Databricks Delta] Đã lưu Line ${newReport.line} (${newReport.reportStage || 'BOS'}) lên Database!`);
          } else {
            console.warn('[Databricks Sync Warning]', res.message);
          }
        })
        .catch((err) => {
          console.error('[Databricks Sync Error]', err);
        });
    }
  };

  const handleRequestDeleteSingle = (id: string | number) => {
    setPinModalTitle('Xác Nhận Xóa Báo Cáo');
    setPinModalDesc('Bạn có chắc chắn muốn xóa bản ghi báo cáo này khỏi hệ thống?');
    setPinAction(() => async () => {
      const targetReport = reports.find((r) => r.id === id);
      const updated = reports.filter((r) => r.id !== id);
      setReports(updated);
      saveStoredReports(updated);
      showToast('Đã xóa báo cáo khỏi hệ thống!');

      // Xóa đồng thời trên Databricks nếu đang dùng Cloud Storage
      if (
        targetReport &&
        databricksConfig.useDatabricksAsPrimaryStorage &&
        databricksConfig.workspaceUrl &&
        databricksConfig.token &&
        databricksConfig.warehouseId
      ) {
        const { deleteReportFromDatabricks } = await import('./utils/databricks');
        deleteReportFromDatabricks(databricksConfig, targetReport)
          .then((res) => {
            if (res.success) {
              showToast('[Databricks Cloud] Đã đồng bộ xóa trên Database.');
            }
          })
          .catch(console.error);
      }
    });
    setIsPinModalOpen(true);
  };

  const handleRequestClearAll = () => {
    if (reports.length === 0) {
      showToast('Hiện không có báo cáo nào để xóa!', true);
      return;
    }
    setPinModalTitle('Xóa Tất Cả Dữ Liệu Báo Cáo');
    setPinModalDesc('CẢNH BÁO: Thao tác này sẽ xóa toàn bộ các báo cáo ca trong hệ thống!');
    setPinAction(() => () => {
      setReports([]);
      saveStoredReports([]);
      showToast('Đã xóa toàn bộ báo cáo khỏi hệ thống!');
    });
    setIsPinModalOpen(true);
  };

  // Đăng nhập Admin
  const handleAdminLogin = () => {
    setPinModalTitle('Đăng Nhập Quản Trị Viên (Admin)');
    setPinModalDesc('Vui lòng nhập mã PIN quản trị để mở khóa các tính năng quản lý.');
    setPinAction(() => () => {
      setIsAdmin(true);
      try {
        sessionStorage.setItem('shift_app_is_admin', 'true');
      } catch {}
      showToast('Đã xác thực quyền Admin thành công!');
    });
    setIsPinModalOpen(true);
  };

  // Đăng xuất Admin
  const handleAdminLogout = () => {
    setIsAdmin(false);
    try {
      sessionStorage.removeItem('shift_app_is_admin');
    } catch {}
    showToast('Đã thoát chế độ Quản trị viên.');
  };

  // Mở Form tính toán cho 1 line cụ thể từ Bảng 6 chuyền
  const handleOpenCalculationForm = (targetLine: string, stage: 'BOS' | 'EOS') => {
    setFormInitialLine(targetLine);
    setFormInitialStage(stage);
    setActiveMainTab('form');
    showToast(`Đã mở Bản Nhập & Tính Toán cho Line ${targetLine} (${stage})`);
  };

  // Sửa báo cáo từ Nhật ký
  const handleEditReportFromHistory = (report: ShiftReport) => {
    setFormInitialLine(report.line);
    setFormInitialStage(report.reportStage === 'EOS' ? 'EOS' : 'BOS');
    setActiveMainTab('form');
    showToast(`Đang chỉnh sửa báo cáo Line ${report.line} trong Bản Tính Toán.`);
  };

  // Determine current system shift
  const hours = new Date().getHours();
  const isNightShift = hours >= 18 || hours < 6;
  const currentShiftLabel = isNightShift ? '🌙 Ca Đêm (Night)' : '☀️ Ca Ngày (Day)';

  return (
    <div className="bg-slate-100 min-h-screen text-slate-800 antialiased pb-12">
      {/* Toast Notification */}
      {toast && (
        <div
          className={`fixed top-5 right-5 z-50 transform transition-all duration-300 translate-y-0 opacity-100 px-5 py-3 rounded-xl shadow-xl flex items-center space-x-3 text-white ${
            toast.isError ? 'bg-rose-600' : 'bg-emerald-600'
          }`}
        >
          {toast.isError ? (
            <AlertTriangle className="w-5 h-5" />
          ) : (
            <CheckCircle2 className="w-5 h-5" />
          )}
          <span className="font-semibold text-xs sm:text-sm">{toast.message}</span>
        </div>
      )}

      {/* Header */}
      <header className="bg-gradient-to-r from-slate-900 via-sky-950 to-slate-900 text-white shadow-md sticky top-0 z-40">
        <div className="max-w-7xl mx-auto px-3 sm:px-6 lg:px-8 py-1.5 sm:py-2 flex flex-col md:flex-row justify-between items-center gap-2">
          <div className="flex items-center space-x-2.5">
            <div className="bg-white px-2 py-0.5 rounded-lg shadow-sm border border-red-500/30 flex items-center justify-center shrink-0">
              <img
                src={milwaukeeLogo}
                alt="Milwaukee Tool Logo"
                className="h-5 sm:h-6 w-auto object-contain"
              />
            </div>
            <div>
              <h1 className="text-sm sm:text-base font-extrabold tracking-tight text-white leading-tight">
                ESTIMATE AND ACTUAL LINE REPORT
              </h1>
              <div className="text-[11px] text-slate-300 flex items-center gap-1.5 flex-wrap">
                <span className="bg-indigo-500/30 text-indigo-200 border border-indigo-400/30 px-1.5 py-0.2 rounded text-[9px] font-bold">
                  {currentShiftLabel}
                </span>
              </div>
            </div>
          </div>

          {/* VÙNG ĐIỀU KHIỂN: ĐỔI MÃ PIN, DATABRICKS VÀ XÓA */}
          <div className="flex items-center space-x-1.5 text-xs no-print flex-wrap gap-y-1">
            {/* Nút Kết Nối Databricks */}
            <button
              type="button"
              onClick={() => setIsDatabricksModalOpen(true)}
              className={`px-2.5 py-1 rounded-md transition-all flex items-center gap-1 shadow-2xs cursor-pointer font-bold text-[11px] border ${
                databricksConfig.workspaceUrl && databricksConfig.token
                  ? databricksConfig.useDatabricksAsPrimaryStorage
                    ? 'bg-gradient-to-r from-red-600 via-rose-600 to-amber-600 hover:opacity-90 text-white border-amber-300 ring-1 ring-amber-400/40'
                    : 'bg-gradient-to-r from-red-600 to-rose-700 hover:from-red-500 hover:to-rose-600 text-white border-red-400'
                  : 'bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white border-slate-700'
              }`}
              title="Cấu hình kết nối Databricks REST API & Đồng bộ Delta Lake"
            >
              <Database className="w-3 h-3 text-red-300" />
              <span>{databricksConfig.useDatabricksAsPrimaryStorage ? 'Databricks Cloud' : 'Databricks'}</span>
              {isDatabricksLoading ? (
                <span className="w-2 h-2 rounded-full border-2 border-white border-t-transparent animate-spin ml-0.5"></span>
              ) : (
                databricksConfig.autoSync && (
                  <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse ml-0.5" title="Tự động đồng bộ đang bật"></span>
                )
              )}
            </button>

            {isAdmin ? (
              <div className="flex items-center space-x-1.5 flex-wrap gap-y-1">
                <span className="bg-amber-500/20 text-amber-300 border border-amber-400/30 px-2 py-0.5 rounded-md font-bold flex items-center gap-1 text-[11px]">
                  <Shield className="w-3 h-3 text-amber-400" /> Admin
                </span>
                <button
                  type="button"
                  onClick={() => setIsChangePinOpen(true)}
                  className="px-2.5 py-1 bg-amber-600 hover:bg-amber-500 text-white rounded-md transition-all flex items-center gap-1 shadow-2xs cursor-pointer font-bold text-[11px]"
                  title="Đổi mã PIN bảo mật quản trị (Chỉ Admin)"
                >
                  <KeyRound className="w-3 h-3" /> Đổi PIN
                </button>
                <button
                  type="button"
                  onClick={handleRequestClearAll}
                  className="px-2.5 py-1 bg-rose-950/70 hover:bg-rose-900 text-rose-200 border border-rose-800/60 rounded-md transition-all flex items-center gap-1 shadow-2xs cursor-pointer font-medium text-[11px]"
                  title="Xóa tất cả báo cáo trong hệ thống"
                >
                  <Trash2 className="w-3 h-3 text-rose-400" /> Xóa Tất Cả
                </button>
                <button
                  type="button"
                  onClick={handleAdminLogout}
                  className="px-2 py-1 bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white border border-slate-700 rounded-md transition-all flex items-center gap-1 text-[11px] cursor-pointer"
                  title="Thoát chế độ Quản trị viên"
                >
                  <LogOut className="w-3 h-3 text-slate-400" /> Thoát
                </button>
              </div>
            ) : (
              <button
                type="button"
                onClick={handleAdminLogin}
                className="px-2.5 py-1 bg-slate-800/80 hover:bg-slate-700 text-slate-300 hover:text-white border border-slate-700 rounded-md transition-all flex items-center gap-1 shadow-2xs cursor-pointer text-[11px] font-medium"
                title="Đăng nhập Quản trị viên để quản lý hệ thống"
              >
                <Lock className="w-3 h-3 text-slate-400" /> Quản Trị
              </button>
            )}
          </div>
        </div>

        {/* THANH ĐIỀU HƯỚNG 3 TAB CHÍNH */}
        <div className="bg-slate-950/90 border-t border-slate-800 px-3 sm:px-6 lg:px-8">
          <div className="max-w-7xl mx-auto flex items-center space-x-1 sm:space-x-2 overflow-x-auto py-1 sm:py-1.5 no-print">
            {/* Tab 1: Bản Nhập Dữ Liệu & Tính Toán */}
            <button
              type="button"
              onClick={() => setActiveMainTab('form')}
              className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all flex items-center gap-1.5 cursor-pointer border shrink-0 ${
                activeMainTab === 'form'
                  ? 'bg-gradient-to-r from-sky-600 to-blue-600 text-white border-sky-400 shadow-sm ring-1 ring-sky-400/30'
                  : 'bg-slate-900 text-slate-300 hover:text-white hover:bg-slate-800 border-slate-800'
              }`}
            >
              <PenSquare className="w-3.5 h-3.5 text-sky-300" />
              <span>1. Bản Nhập Liệu & Tính Toán Ca</span>
            </button>

            {/* Tab 2: Báo Cáo Sản Xuất 6 Chuyền */}
            <button
              type="button"
              onClick={() => setActiveMainTab('summary')}
              className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all flex items-center gap-1.5 cursor-pointer border shrink-0 ${
                activeMainTab === 'summary'
                  ? 'bg-gradient-to-r from-indigo-600 to-sky-700 text-white border-indigo-400 shadow-sm ring-1 ring-indigo-400/30'
                  : 'bg-slate-900 text-slate-300 hover:text-white hover:bg-slate-800 border-slate-800'
              }`}
            >
              <FileSpreadsheet className="w-3.5 h-3.5 text-indigo-300" />
              <span>2. Báo Cáo</span>
            </button>

            {/* Tab 3: Nhật Ký Báo Cáo Đã Lưu */}
            <button
              type="button"
              onClick={() => setActiveMainTab('history')}
              className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all flex items-center gap-1.5 cursor-pointer border shrink-0 ${
                activeMainTab === 'history'
                  ? 'bg-gradient-to-r from-amber-600 to-orange-600 text-white border-amber-400 shadow-sm ring-1 ring-amber-400/30'
                  : 'bg-slate-900 text-slate-300 hover:text-white hover:bg-slate-800 border-slate-800'
              }`}
            >
              <History className="w-3.5 h-3.5 text-amber-300" />
              <span>3. Nhật Ký Báo Cáo</span>
              <span className="text-[9px] bg-amber-400/20 text-amber-200 px-1.5 py-0.2 rounded-full font-bold">
                {reports.length}
              </span>
            </button>
          </div>
        </div>
      </header>

      {/* Main Container: Hiển thị ĐẦY ĐỦ màn hình theo từng Tab được chọn, KHÔNG chia đôi */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-5">
        {/* TAB 1: BẢN NHẬP DỮ LIỆU & TÍNH TOÁN CA (ĐẦU CA BOS & CUỐI CA EOS) */}
        {activeMainTab === 'form' && (
          <div className="space-y-4">
            <ReportForm
              onSaveReport={(rep) => {
                handleSaveReport(rep);
              }}
              onShowToast={showToast}
              reports={reports}
              initialLine={formInitialLine}
              initialStage={formInitialStage}
              onBackToReport={() => setActiveMainTab('summary')}
            />
          </div>
        )}

        {/* TAB 2: BẢNG BÁO CÁO SẢN XUẤT 6 CHUYỀN (FORMAT CHUẨN 10 CỘT, 2 TAB BOS & EOS) */}
        {activeMainTab === 'summary' && (
          <div className="space-y-4">
            <MainReportView
              reports={reports}
              selectedDate={selectedDate}
              onDateChange={setSelectedDate}
              onSaveReport={handleSaveReport}
              onShowToast={showToast}
              onOpenCalculationForm={handleOpenCalculationForm}
            />
          </div>
        )}

        {/* TAB 3: NHẬT KÝ & LỊCH SỬ BÁO CÁO ĐÃ LƯU */}
        {activeMainTab === 'history' && (
          <div className="space-y-4">
            <ReportTable
              reports={reports}
              selectedDate={selectedDate}
              onDateChange={setSelectedDate}
              onOpenZalo={(rep) => setZaloReport(rep)}
              onRequestDelete={handleRequestDeleteSingle}
              onShowToast={showToast}
              onOpenDailySummary={() => setActiveMainTab('summary')}
              onEditReport={handleEditReportFromHistory}
            />
          </div>
        )}
      </main>

      {/* Security PIN Modal */}
      <PinModal
        isOpen={isPinModalOpen}
        title={pinModalTitle}
        description={pinModalDesc}
        onClose={() => {
          setIsPinModalOpen(false);
          setPinAction(null);
        }}
        onSuccess={() => {
          if (pinAction) pinAction();
        }}
      />

      {/* Change PIN Modal */}
      <ChangePinModal
        isOpen={isChangePinOpen}
        onClose={() => setIsChangePinOpen(false)}
        onSuccess={(msg) => showToast(msg)}
      />

      {/* Zalo Modal */}
      <ZaloModal
        report={zaloReport}
        onClose={() => setZaloReport(null)}
        onCopied={(msg) => showToast(msg)}
      />

      {/* Databricks REST API Modal */}
      <DatabricksModal
        isOpen={isDatabricksModalOpen}
        onClose={() => setIsDatabricksModalOpen(false)}
        config={databricksConfig}
        onSaveConfig={(cfg) => {
          setDatabricksConfig(cfg);
          saveStoredDatabricksConfig(cfg);
          setIsDatabricksModalOpen(false);
          loadReportsData(cfg);
        }}
        reports={reports}
        onShowToast={showToast}
      />
    </div>
  );
}
